// CUDA field-program interpreter, not a renderer. Definition and expression fields
// are immutable within an evaluation launch. Publication occurs in a later launch.
#include <cuda_runtime.h>
#include "axis0/host.hpp"
#include <memory>
#include <utility>

namespace axis0::gpu {
constexpr unsigned THREADS=128;
inline void check(cudaError_t status,const char* where){if(status!=cudaSuccess)throw std::runtime_error(std::string(where)+": "+cudaGetErrorString(status));}
template<class T>class Buffer {
    T* pointer_=nullptr;std::size_t length_=0;
public:
    Buffer()=default;
    explicit Buffer(std::size_t n):length_(n){if(n>std::numeric_limits<std::size_t>::max()/sizeof(T))throw std::runtime_error("allocation overflow");if(n)check(cudaMalloc(reinterpret_cast<void**>(&pointer_),n*sizeof(T)),"cudaMalloc");}
    ~Buffer(){if(pointer_)cudaFree(pointer_);}
    Buffer(const Buffer&)=delete;Buffer& operator=(const Buffer&)=delete;
    T* get()const{return pointer_;}
    void from(const T* src,std::size_t n){if(n>length_)throw std::runtime_error("upload overflow");check(cudaMemcpy(pointer_,src,n*sizeof(T),cudaMemcpyHostToDevice),"upload");}
};
class Texture {
    cudaTextureObject_t object_=0;
public:
    Texture()=default;
    Texture(const Word* pointer,std::size_t words){
        cudaResourceDesc resource{};resource.resType=cudaResourceTypeLinear;
        resource.res.linear.devPtr=const_cast<Word*>(pointer);
        resource.res.linear.desc=cudaCreateChannelDesc<unsigned int>();
        resource.res.linear.sizeInBytes=words*sizeof(Word);
        cudaTextureDesc desc{};desc.readMode=cudaReadModeElementType;
        desc.normalizedCoords=0;desc.filterMode=cudaFilterModePoint;
        check(cudaCreateTextureObject(&object_,&resource,&desc,nullptr),"create integer texture");
    }
    ~Texture(){if(object_)cudaDestroyTextureObject(object_);}
    Texture(const Texture&)=delete;Texture& operator=(const Texture&)=delete;
    Texture(Texture&& b)noexcept:object_(std::exchange(b.object_,0)){}
    Texture& operator=(Texture&& b)noexcept{if(this!=&b){if(object_)cudaDestroyTextureObject(object_);object_=std::exchange(b.object_,0);}return *this;}
    cudaTextureObject_t get()const{return object_;}
};
struct TextureAtlas {cudaTextureObject_t texture;__device__ __forceinline__ Word get(Word i)const{return tex1Dfetch<unsigned int>(texture,static_cast<int>(i));}};
struct TexturePast {cudaTextureObject_t texture;__device__ __forceinline__ Word get(std::uint64_t i)const{return tex1Dfetch<unsigned int>(texture,static_cast<int>(i));}};

template<int Backend>
__global__ void execute_kernel(const Word* atlas,cudaTextureObject_t atlas_texture,
    const Word* past,cudaTextureObject_t past_texture,Word* now,Shape s) {
    extern __shared__ Word resident_atlas[];
    if constexpr(Backend==2){
        for(Word i=threadIdx.x;i<s.atlas_words;i+=blockDim.x)resident_atlas[i]=atlas[i];
        __syncthreads();
    }
    for(Word w=blockIdx.x*blockDim.x+threadIdx.x;w<s.words;w+=blockDim.x*gridDim.x){
        if constexpr(Backend==0){const PointerAtlas a{atlas};const PointerPast p{past};evaluate_lane_word(a,p,now,s,w);}
        else if constexpr(Backend==1){const TextureAtlas a{atlas_texture};const TexturePast p{past_texture};evaluate_lane_word(a,p,now,s,w);}
        else {const PointerAtlas a{resident_atlas};const PointerPast p{past};evaluate_lane_word(a,p,now,s,w);}
    }
}
// Seeds tagged input_bit obtain new assignments as VRAM batches grow. Explicit
// word patterns are repeated. Definition publication still has one control lane.
__global__ void initialize_kernel(const Word* seed,const Word* atlas,Word* state,
    Word nodes,Word original_words,Word words,Word desc_base,std::uint64_t global_word_base){
    const std::uint64_t total=std::uint64_t(nodes)*words;
    for(std::uint64_t i=std::uint64_t(blockIdx.x)*blockDim.x+threadIdx.x;i<total;i+=std::uint64_t(blockDim.x)*gridDim.x){
        const Word node=Word(i/words),w=Word(i%words),tag=atlas[desc_base+8*node+7];
        Word value=0;
        if(tag){const Word b=tag-1;const std::uint64_t base=(global_word_base+w)*32;
            for(Word lane=0;lane<32;++lane)value|=Word(((base+lane)>>b)&1ull)<<lane;
        }else value=seed[std::uint64_t(node)*original_words+(w&(original_words-1))];
        state[i]=value;
    }
}
__global__ void publish_kernel(const Word* old_atlas,Word* new_atlas,const Word* now,Shape s){
    for(Word i=blockIdx.x*blockDim.x+threadIdx.x;i<s.patches;i+=blockDim.x*gridDim.x){
        const Word b=s.patch_base+4*i,target=old_atlas[b],node=old_atlas[b+1],lane=old_atlas[b+2];
        const Word value=(now[std::uint64_t(node)*s.words+(lane>>5)]>>(lane&31))&1u;
        const Word mask=1u<<(target&31);
        // Distinct bits, potentially the same word: atomics preserve other writers.
        if(value)atomicOr(new_atlas+(target>>5),mask);else atomicAnd(new_atlas+(target>>5),~mask);
    }
}
struct Shard {
    Shape shape;std::uint64_t base;
    Buffer<Word> state[2];Texture tex[2];
    Shard(Shape s,std::uint64_t base_word,bool texture):shape(s),base(base_word),
      state{Buffer<Word>(std::size_t(s.nodes)*s.words),Buffer<Word>(std::size_t(s.nodes)*s.words)}{
        if(texture)for(int p=0;p<2;++p)tex[p]=Texture(state[p].get(),std::size_t(s.nodes)*s.words);
    }
};
inline unsigned blocks(std::uint64_t count,const cudaDeviceProp& prop){return static_cast<unsigned>(std::max<std::uint64_t>(1,std::min<std::uint64_t>((count+THREADS-1)/THREADS,std::uint64_t(std::max(1,prop.multiProcessorCount))*8)));}
std::string info(const cudaDeviceProp&p){std::size_t free=0,total=0;check(cudaMemGetInfo(&free,&total),"memory query");std::ostringstream o;o<<"{\"name\":\""<<escape(p.name)<<"\",\"compute_major\":"<<p.major<<",\"compute_minor\":"<<p.minor<<",\"total_bytes\":"<<total<<",\"free_bytes\":"<<free<<",\"l2_bytes\":"<<p.l2CacheSize<<",\"max_persisting_l2_bytes\":"<<p.persistingL2CacheMaxSize<<",\"max_access_window_bytes\":"<<p.accessPolicyMaxWindowSize<<",\"shared_per_block_bytes\":"<<p.sharedMemPerBlock<<",\"linear_texture_max_elements\":"<<p.maxTexture1DLinear<<"}";return o.str();}
struct Stream {
    cudaStream_t value=nullptr;
    Stream(){check(cudaStreamCreate(&value),"create stream");}
    ~Stream(){if(value)cudaStreamDestroy(value);}
};
}

int main(int argc,char**argv){using namespace axis0;using namespace axis0::gpu;try{
    auto opts=parse(argc,argv);if(opts.help){usage();return 0;}
    check(cudaSetDevice(static_cast<int>(opts.device)),"set device");check(cudaFree(nullptr),"initialize CUDA");
    cudaDeviceProp prop{};check(cudaGetDeviceProperties(&prop,static_cast<int>(opts.device)),"device properties");
    if(opts.info){emit(info(prop),opts.json);return 0;}
    if(opts.program.empty())throw std::runtime_error("--program required");
    Program initial=load(opts.program);const auto shape=initial.s;
    const std::size_t atlas_bytes=std::size_t(shape.atlas_words)*4;
    const int backend=opts.defs=="global"?0:opts.defs=="texture"?1:2;
    if(backend==2&&atlas_bytes>prop.sharedMemPerBlock)throw std::runtime_error("definition atlas does not fit shared memory; choose global or texture");
    if(backend==1&&(prop.maxTexture1DLinear<=0||std::uint64_t(shape.atlas_words)>std::uint64_t(prop.maxTexture1DLinear)))throw std::runtime_error("definition texture exceeds device limit");
    std::size_t free_before=0,total=0;check(cudaMemGetInfo(&free_before,&total),"memory budget");
    const std::uint64_t setup=2*atlas_bytes+initial.state.size()*4;
    const std::uint64_t unit_bytes=std::uint64_t(shape.nodes)*8; // Two state planes, one lane word per expression.
    std::uint64_t total_words=shape.words;
    if(opts.vram){const std::uint64_t budget=(free_before/100)*opts.vram;if(budget<=setup)throw std::runtime_error("budget too small");total_words=(budget-setup)/unit_bytes;total_words-=total_words%shape.words;if(total_words<shape.words)throw std::runtime_error("budget cannot fit base program");}
    if(total_words>(std::numeric_limits<std::uint64_t>::max()-setup)/unit_bytes||total_words*unit_bytes+setup>free_before)throw std::runtime_error("state allocation exceeds free memory");
    const std::uint64_t state_limit=backend==1?std::min<std::uint64_t>(std::uint64_t(prop.maxTexture1DLinear),1ull<<27):(1ull<<27);
    std::uint64_t shard_words=state_limit/shape.nodes;shard_words-=shard_words%shape.words;
    if(!shard_words)throw std::runtime_error("base state exceeds a shard's addressable capacity");
    Buffer<Word> atlas[2]{Buffer<Word>(shape.atlas_words),Buffer<Word>(shape.atlas_words)};
    atlas[0].from(initial.atlas.data(),shape.atlas_words);Texture definition_tex[2];
    if(backend==1)for(int p=0;p<2;++p)definition_tex[p]=Texture(atlas[p].get(),shape.atlas_words);
    Stream stream;
    std::size_t applied_persist=0,window=0;
    if(opts.persist_kib && prop.persistingL2CacheMaxSize>0 && prop.accessPolicyMaxWindowSize>0){
        applied_persist=std::min<std::size_t>(std::size_t(opts.persist_kib)*1024,prop.persistingL2CacheMaxSize);
        check(cudaDeviceSetLimit(cudaLimitPersistingL2CacheSize,applied_persist),"L2 set-aside request");
        check(cudaDeviceGetLimit(&applied_persist,cudaLimitPersistingL2CacheSize),"L2 set-aside query");
        window=std::min({atlas_bytes,applied_persist,std::size_t(prop.accessPolicyMaxWindowSize)});
    }
    std::vector<std::unique_ptr<Shard>> shards;
    {
        Buffer<Word> seed(initial.state.size());seed.from(initial.state.data(),initial.state.size());
        for(std::uint64_t base=0;base<total_words;){auto s=shape;s.words=Word(std::min(shard_words,total_words-base));auto sh=std::make_unique<Shard>(s,base,backend==1);
            initialize_kernel<<<blocks(std::uint64_t(s.nodes)*s.words,prop),THREADS,0,stream.value>>>(seed.get(),atlas[0].get(),sh->state[0].get(),s.nodes,shape.words,s.words,s.desc_base,base);
            check(cudaGetLastError(),"initialization launch");shards.push_back(std::move(sh));base+=s.words;}
        check(cudaStreamSynchronize(stream.value),"initialization completion");
    }
    int state_side=0,atlas_side=0;const auto begin=std::chrono::steady_clock::now();
    for(Word tick_index=0;tick_index<opts.ticks;++tick_index){
        if(window){cudaStreamAttrValue attribute{};attribute.accessPolicyWindow.base_ptr=atlas[atlas_side].get();attribute.accessPolicyWindow.num_bytes=window;
            // CUDA requires a float-typed host policy hint. This is metadata, not field arithmetic.
            attribute.accessPolicyWindow.hitRatio=1.0f;
            attribute.accessPolicyWindow.hitProp=cudaAccessPropertyPersisting;attribute.accessPolicyWindow.missProp=cudaAccessPropertyStreaming;
            check(cudaStreamSetAttribute(stream.value,cudaStreamAttributeAccessPolicyWindow,&attribute),"L2 access-policy hint");}
        for(auto& sh:shards){auto s=sh->shape;const auto b=blocks(s.words,prop);
            if(backend==0)execute_kernel<0><<<b,THREADS,0,stream.value>>>(atlas[atlas_side].get(),0,sh->state[state_side].get(),0,sh->state[1-state_side].get(),s);
            else if(backend==1)execute_kernel<1><<<b,THREADS,0,stream.value>>>(atlas[atlas_side].get(),definition_tex[atlas_side].get(),sh->state[state_side].get(),sh->tex[state_side].get(),sh->state[1-state_side].get(),s);
            else execute_kernel<2><<<b,THREADS,atlas_bytes,stream.value>>>(atlas[atlas_side].get(),0,sh->state[state_side].get(),0,sh->state[1-state_side].get(),s);
            check(cudaGetLastError(),"field evaluation launch");}
        state_side=1-state_side;
        if(shape.patches){check(cudaMemcpyAsync(atlas[1-atlas_side].get(),atlas[atlas_side].get(),atlas_bytes,cudaMemcpyDeviceToDevice,stream.value),"snapshot definitions");
            publish_kernel<<<blocks(shape.patches,prop),THREADS,0,stream.value>>>(atlas[atlas_side].get(),atlas[1-atlas_side].get(),shards[0]->state[state_side].get(),shards[0]->shape);
            check(cudaGetLastError(),"definition publication launch");atlas_side=1-atlas_side;}
    }
    check(cudaStreamSynchronize(stream.value),"calculation completion");const auto end=std::chrono::steady_clock::now();
    Program output=initial;check(cudaMemcpy(output.atlas.data(),atlas[atlas_side].get(),atlas_bytes,cudaMemcpyDeviceToHost),"read definitions");
    // Output ABI keeps the base set of cases. Additional batches are for on-device capacity/throughput assays.
    for(Word node=0;node<shape.nodes;++node)check(cudaMemcpy(output.state.data()+std::size_t(node)*shape.words,shards[0]->state[state_side].get()+std::size_t(node)*shards[0]->shape.words,std::size_t(shape.words)*4,cudaMemcpyDeviceToHost),"read output field");
    bool verified=false;if(opts.verify){auto ref=initial;std::vector<Word> scratch(ref.state.size());for(Word i=0;i<opts.ticks;++i)tick(ref,scratch);if(ref.atlas!=output.atlas||ref.state!=output.state)throw std::runtime_error("CPU/GPU state or definition mismatch");verified=true;}
    save_result(opts.out,output,opts.ticks);
    if(window){cudaStreamAttrValue reset{};reset.accessPolicyWindow.num_bytes=0;check(cudaStreamSetAttribute(stream.value,cudaStreamAttributeAccessPolicyWindow,&reset),"reset L2 window");check(cudaCtxResetPersistingL2Cache(),"reset persisting priority");}
    std::ostringstream report;report<<"{\"version\":\"5.0\",\"gpu_execution\":\"EXECUTED\",\"device\":"<<info(prop)<<",\"backend\":\""<<opts.defs<<"\",\"nodes\":"<<shape.nodes<<",\"lanes_executed\":"<<total_words*32<<",\"lanes_read_back\":"<<std::uint64_t(shape.words)*32<<",\"shards\":"<<shards.size()<<",\"ticks\":"<<opts.ticks<<",\"atlas_bytes\":"<<atlas_bytes<<",\"two_state_bytes\":"<<total_words*unit_bytes<<",\"persisting_set_aside_bytes\":"<<applied_persist<<",\"hinted_window_bytes\":"<<window<<",\"elapsed_ns\":"<<elapsed(begin,end)<<",\"digest_base_cases\":"<<digest(output)<<",\"base_cases_verified\":"<<(verified?"true":"false")<<",\"publication_scope\":\"explicit source lane per patch; one shared atlas\",\"timing_includes_setup\":false}";
    emit(report.str(),opts.json);return 0;
}catch(const std::exception&e){std::cerr<<"axis0_gpu: "<<e.what()<<'\n';return 1;}}
