#!/usr/bin/env python3
"""Show an operator/expression's exact SDF coding geometry and its anchor samples."""
import argparse,json
from pathlib import Path
from field_program import Program,distance_word
p=argparse.ArgumentParser(description=__doc__);p.add_argument('program',type=Path);p.add_argument('--manifest',required=True,type=Path)
g=p.add_mutually_exclusive_group(required=True);g.add_argument('--operator');g.add_argument('--expression')
p.add_argument('--json',type=Path);a=p.parse_args();program=Program.load(a.program);m=json.loads(a.manifest.read_text())
if a.operator:offset=m['operator_bit_addresses'][a.operator];length=8;label=a.operator
else:offset=(program.desc_base+8*m['node_ids'][a.expression])*32;length=256;label=a.expression
bits=[(program.atlas[(offset+i)>>5]>>((offset+i)&31))&1 for i in range(length)]
intervals=[[-5,-3]]+[[4*i-1,4*i+1] for i,b in enumerate(bits) if b]
r={'field':label,'atlas_bit_offset':offset,'logical_bits':length,'bits':bits,
   'coding_space':'one-dimensional Euclidean line, not physical log-polar positions',
   'definition_intervals':intervals,'anchor_signed_distances':[distance_word(bits,4*i) for i in range(length)],
   'reader_identity':'bit[j] == (D_field(4*j) < 0); distance magnitude is not calculated during execution'}
s=json.dumps(r,indent=2);print(s)
if a.json:a.json.write_text(s+'\n')
