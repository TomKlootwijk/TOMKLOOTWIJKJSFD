#!/usr/bin/env python3
"""Decode named result fields and current operator definitions; no renderer."""
import argparse,json
from pathlib import Path
from field_program import read_output
p=argparse.ArgumentParser(description=__doc__);p.add_argument('result',type=Path);p.add_argument('--manifest',required=True,type=Path);p.add_argument('--lanes',type=int,default=16);p.add_argument('--json',type=Path)
a=p.parse_args();atlas,state,ticks,nodes,words=read_output(a.result);meta=json.loads(a.manifest.read_text())
if nodes!=len(meta['node_ids']):raise ValueError('manifest/result disagreement')
count=min(max(0,a.lanes),words*32)
values={name:[(state[meta['node_ids'][name]*words+(i>>5)]>>(i&31))&1 for i in range(count)] for name in meta['outputs']}
custom=meta.get('program_description',{}).get('definitions',{})
truths={name:f"0x{(atlas[meta['operator_bit_addresses'][name]>>5]>>(meta['operator_bit_addresses'][name]&31))&255:02x}" for name in custom}
r={'ticks':ticks,'total_lanes':words*32,'shown_lanes':count,'output_bits':values,'current_custom_definitions':truths}
s=json.dumps(r,indent=2);print(s)
if a.json:a.json.write_text(s+'\n')
