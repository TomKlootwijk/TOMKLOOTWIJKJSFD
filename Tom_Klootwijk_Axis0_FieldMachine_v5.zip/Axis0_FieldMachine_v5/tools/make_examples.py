#!/usr/bin/env python3
"""Produce executable operator/expressions-as-fields demonstrations."""
from pathlib import Path
import json
from field_program import compile_program
ROOT=Path(__file__).resolve().parents[1]
def write(name,spec):
    (ROOT/'examples'/f'{name}.json').write_text(json.dumps(spec,indent=2)+'\n')
    p=compile_program(spec);p.save(ROOT/'examples'/f'{name}.a0f')
    (ROOT/'examples'/f'{name}.manifest.json').write_text(json.dumps(p.manifest,indent=2)+'\n')
def variable(name,bit):return {'id':name,'op':'T','inputs':[name],'seed':{'input_bit':bit}}
def main():
    nodes=[variable('x',0),variable('y',1),variable('z',2)]
    nodes += [{'id':f'f{i:02x}','op':f'LUT_{i:02X}','inputs':['x','y','z']} for i in range(256)]
    write('all_boolean_operators',{'title':'All 256 ternary operator fields','lanes':256,'nodes':nodes,'outputs':[f'f{i:02x}' for i in range(256)]})
    nodes=[variable(f'a{i}',i) for i in range(4)]+[variable(f'b{i}',i+4) for i in range(4)]
    carry=0
    for i in range(4):
        nodes.append({'id':f'sum{i}','op':'XOR3','inputs':[f'a{i}',f'b{i}',carry]})
        nodes.append({'id':f'carry{i}','op':'MAJ','inputs':[f'a{i}',f'b{i}',carry]});carry=f'carry{i}'
    write('adder4',{'title':'Bit-sliced 4-bit addition expressed as fields','lanes':256,'nodes':nodes,'outputs':[f'sum{i}' for i in range(4)]+['carry3']})
    nodes=[{'id':'q0','op':'NOT','inputs':[{'A':'q0'}],'seed':{'input_bit':0}},
           {'id':'q1','op':'XOR','inputs':[{'T':'q1'},{'T':'q0'}],'seed':{'input_bit':1}},
           {'id':'c2','op':'AND','inputs':[{'T':'q0'},{'T':'q1'}]},
           {'id':'q2','op':'XOR','inputs':[{'T':'q2'},'c2'],'seed':{'input_bit':2}},
           {'id':'c3','op':'AND','inputs':['c2',{'T':'q2'}]},
           {'id':'q3','op':'XOR','inputs':[{'T':'q3'},'c3'],'seed':{'input_bit':3}}]
    write('clocked_counter',{'title':'A = T: clocked self-referential 4-bit counters','lanes':256,'nodes':nodes,'outputs':['q0','q1','q2','q3']})
    nodes=[variable('x',0),{'id':'answer','op':'LIVE','inputs':['x']}]
    nodes += [{'id':f'rewrite{k}','op':'NOT','inputs':[{'quote':{'operator':'LIVE','bit':k}}]} for k in range(8)]
    nodes += [{'id':'own_descriptor','op':'ID','inputs':[{'quote':{'expression':'own_descriptor','bit':0}}]}]
    write('self_definition',{'title':'An operator reads and rewrites its own truth field','lanes':256,
            'definitions':{'LIVE':'0xaa'},'nodes':nodes,
            'publish':[{'operator':'LIVE','bit':k,'source':f'rewrite{k}','lane':0} for k in range(8)],
            'outputs':['answer','own_descriptor']})
    # The evaluator itself as a field expression: seven MUX fields, not an opcode switch.
    nodes=[variable('a',0),variable('b',1),variable('c',2)]+[variable(f't{k}',k+3) for k in range(8)]
    nodes += [{'id':f'q{k}','op':'MUX','inputs':[f't{2*k}',f't{2*k+1}','a']} for k in range(4)]
    nodes += [{'id':'p0','op':'MUX','inputs':['q0','q1','b']},
              {'id':'p1','op':'MUX','inputs':['q2','q3','b']},
              {'id':'evaluate','op':'MUX','inputs':['p0','p1','c']}]
    write('interpreter_in_fields',{'title':'The Boolean evaluator expressed in its own field language','lanes':2048,'nodes':nodes,'outputs':['evaluate']})
    # A Boolean acceptance predicate. All 16 assignments are enumerated in the lanes.
    nodes=[variable(f'x{i}',i) for i in range(4)]
    nodes += [{'id':'not_x0','op':'NOT','inputs':['x0']},
              {'id':'clause0','op':'OR','inputs':['x0','x1']},
              {'id':'clause1','op':'OR','inputs':['not_x0','x2']},
              {'id':'clause2','op':'XOR','inputs':['x2','x3']},
              {'id':'accept','op':'AND3','inputs':['clause0','clause1','clause2']}]
    write('constraint_filter',{'title':'Boolean constraint filtering over packed assignments','lanes':256,'nodes':nodes,'outputs':['accept']})
if __name__=='__main__':main()
