#!/usr/bin/env python3
"""On-device cache/batch comparison. Run gpu_check.py first. Measurements are post-hoc."""
import argparse,json,statistics,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--exe',required=True,type=Path);p.add_argument('--program',type=Path,default=ROOT/'examples/interpreter_in_fields.a0f')
    p.add_argument('--output',type=Path,default=Path('gpu_metrics.json'));p.add_argument('--percent',default='0,25,50,80');p.add_argument('--ticks',type=int,default=32);p.add_argument('--repeat',type=int,default=5);a=p.parse_args()
    if a.repeat<1 or a.ticks<1:p.error('repeat/ticks must be positive')
    exe=str(a.exe.resolve())
    def run(args):return json.loads(subprocess.run([exe,*args],check=True,capture_output=True,text=True).stdout)
    info=run(['--info']);report={'gpu_execution':'EXECUTED','device':info,'runs':[],'method':'same program; host launch+sync timing; setup and CPU verification excluded; case counts recorded, not assumed identical across free-memory changes'}
    for pct in map(int,a.percent.split(',')):
        if not 0<=pct<=100:p.error('percentage out of range')
        for backend,persist in (('global',0),('texture',0),('shared',0),('global',64),('texture',64)):
            base=['--program',str(a.program.resolve()),'--ticks',str(a.ticks),'--vram-percent',str(pct),'--defs',backend,'--persist-kib',str(persist),'--verify']
            run(base) # warm-up process
            samples=[run(base) for _ in range(a.repeat)]
            if any(not s['base_cases_verified'] for s in samples):raise RuntimeError('verification not performed')
            count_set={s['lanes_executed'] for s in samples}
            entry={'target_percent_free':pct,'backend':backend,'requested_persist_kib':persist,'samples':samples,
                   'equal_case_counts':len(count_set)==1,'median_ns':int(statistics.median(s['elapsed_ns'] for s in samples)),
                   'median_boolean_node_case_updates_per_second':statistics.median(s['nodes']*s['lanes_executed']*s['ticks']*1_000_000_000/s['elapsed_ns'] for s in samples)}
            report['runs'].append(entry);a.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'output':str(a.output),'configurations':len(report['runs'])}))
if __name__=='__main__':main()
