#!/usr/bin/env python3
"""Audit owned evaluator source and optionally real NVIDIA PTX, with explicit status."""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--ptx',action='store_true');p.add_argument('--output',type=Path,default=ROOT/'verification/integer_audit.json');a=p.parse_args()
    source=(ROOT/'include/axis0/core.hpp').read_text();code=re.sub(r'//[^\n]*|/\*.*?\*/','',source,flags=re.S)
    matches=re.findall(r'\b(?:float|double|__half)\b',code)
    report={'core_source_status':'PASS' if not matches else 'FAIL','core_floating_type_tokens':matches,
            'cuda_compile':'NOT_RUN','ptx_audit':'NOT_RUN','host_policy_float':'Optional CUDA L2 hitRatio=1.0f is API metadata, not field arithmetic',
            'meaning':'Source scan is not a machine-code proof; CPU tests do not validate texture hardware'}
    if a.ptx:
        nvcc=shutil.which('nvcc')
        if nvcc:
            output=ROOT/'verification/evaluator.ptx'
            command=[nvcc,'--ptx','-std=c++17','-arch=compute_120','-I',str(ROOT/'include'),str(ROOT/'cuda/evaluator.cu'),'-o',str(output)]
            done=subprocess.run(command,capture_output=True,text=True);report['cuda_compile']='PASS' if done.returncode==0 else 'FAIL';report['log']=done.stdout+done.stderr
            if done.returncode==0:
                lines=[line for line in output.read_text().splitlines() if re.search(r'\.(?:f16|f32|f64|bf16)\b',line) and not line.lstrip().startswith('//')]
                report['floating_ptx_lines']=lines;report['ptx_audit']='PASS' if not lines else 'REVIEW_REQUIRED'
        else:report['cuda_compile']='UNAVAILABLE: nvcc is not installed'
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
    if matches or report['cuda_compile']=='FAIL':raise SystemExit(1)
if __name__=='__main__':main()
