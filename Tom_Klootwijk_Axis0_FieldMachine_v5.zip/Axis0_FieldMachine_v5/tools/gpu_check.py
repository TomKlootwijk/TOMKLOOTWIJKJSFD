#!/usr/bin/env python3
"""Compile-free test harness: run on a built CUDA executable, never fabricate GPU results."""
from pathlib import Path
import argparse,json,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--exe',required=True,type=Path);p.add_argument('--json',type=Path,default=Path('gpu_tests.json'));a=p.parse_args();exe=str(a.exe.resolve())
    info=json.loads(subprocess.run([exe,'--info'],check=True,capture_output=True,text=True).stdout)
    reports=[]
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        for name in ('all_boolean_operators','adder4','clocked_counter','self_definition','interpreter_in_fields','constraint_filter'):
            expected=None
            for backend in ('global','texture','shared'):
                target=tmp/'output.a0o';command=[exe,'--program',str(ROOT/'examples'/f'{name}.a0f'),'--ticks','17','--defs',backend,'--verify','--out',str(target)]
                result=json.loads(subprocess.run(command,check=True,capture_output=True,text=True).stdout)
                if not result['base_cases_verified']:raise RuntimeError('CPU verification missing')
                actual=target.read_bytes()
                if expected is None:expected=actual
                if expected!=actual:raise RuntimeError('backend results differ')
                reports.append({'example':name,**result})
    output={'status':'PASS','gpu_execution':'EXECUTED','device':info,'backend_example_runs':len(reports),'runs':reports}
    a.json.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'status':'PASS','output':str(a.json),'runs':len(reports)}))
if __name__=='__main__':main()
