"""FieldMachine v5 program compiler, binary ABI and exact field-definition codec.

Every finite object is a packed bitword with an implicit signed-distance
realization as disjoint intervals. The evaluator reads anchor signs, not floats.
The interval geometry is the encoding carrier; log-polar indexing is the storage
chart. These are distinct spaces, deliberately not conflated.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json
import struct

MAGIC = b'A0FM5\0\0\0'
OUTPUT_MAGIC = b'A0FO5\0\0\0'
QUOTE = 1 << 31
MASK = (1 << 32) - 1
NAMES = {'ZERO':0x00, 'ONE':0xff, 'ID':0xaa, 'NOT':0x55, 'AND':0x88,
         'OR':0xee, 'XOR':0x66, 'NAND':0x77, 'NOR':0x11, 'MAJ':0xe8,
         'MUX':0xca, 'XOR3':0x96, 'OR3':0xfe, 'AND3':0x80, 'T':0xaa, 'A':0xaa}

@dataclass
class Program:
    nodes: int
    words: int
    atlas: list[int]
    seed: list[int]
    desc_base: int
    patch_base: int
    patches: int
    output_ids: list[int]
    manifest: dict

    def save(self, path: Path) -> None:
        header=[5,self.nodes,self.words,len(self.atlas),len(self.seed),self.desc_base,
                self.patch_base,self.patches,len(self.output_ids),0,0,0]
        payload=header+self.atlas+self.seed+self.output_ids
        path.write_bytes(MAGIC+struct.pack(f'<{len(payload)}I',*payload))

    @classmethod
    def load(cls,path:Path)->'Program':
        raw=path.read_bytes()
        if len(raw)<56 or raw[:8]!=MAGIC or (len(raw)-8)%4:raise ValueError('invalid A0FM5 file')
        values=list(struct.unpack(f'<{(len(raw)-8)//4}I',raw[8:]));h=values[:12]
        ver,n,w,na,ns,db,pb,np,no,*reserved=h
        if ver!=5 or any(reserved) or not n or not w or w&(w-1):raise ValueError('invalid header')
        if ns!=n*w or len(values)!=12+na+ns+no:raise ValueError('invalid lengths')
        atlas=values[12:12+na];seed=values[12+na:12+na+ns];outs=values[12+na+ns:]
        p=cls(n,w,atlas,seed,db,pb,np,outs,{})
        validate(p);return p

def validate(p:Program)->None:
    if len(p.atlas)*32>=QUOTE:raise ValueError('atlas exceeds quoted-address format')
    if p.desc_base+8*p.nodes>len(p.atlas) or p.patch_base+4*p.patches>len(p.atlas):raise ValueError('invalid field ranges')
    for node in range(p.nodes):
        tt,*rest=p.atlas[p.desc_base+node*8:p.desc_base+node*8+8]
        a,b,c,delays,logrho,tag,reserved=rest
        if tt%8 or tt+8>len(p.atlas)*32 or delays&~7 or reserved>63:raise ValueError('invalid expression field')
        for k,ref in enumerate((a,b,c)):
            if ref&QUOTE:
                if ref&~QUOTE>=len(p.atlas)*32 or delays&(1<<k):raise ValueError('invalid quote port')
            else:
                if ref>=p.nodes or not delays&(1<<k) and ref>=node:raise ValueError('unclocked cycle/forward reference')
    if p.atlas[10]>p.atlas[11] or p.atlas[10]<80*32 or p.atlas[11]>p.desc_base*32:raise ValueError('invalid custom-definition region')
    targets=set()
    for i in range(p.patches):
        target,source,lane,reserved=p.atlas[p.patch_base+i*4:p.patch_base+i*4+4]
        if target>=len(p.atlas)*32 or source>=p.nodes or lane>=p.words*32 or reserved or target in targets:raise ValueError('invalid publish field')
        # Mutations are confined to the user-definition truth field region.
        start,end=p.atlas[10],p.atlas[11]
        if not start<=target<end:raise ValueError('publication may change only custom truth coefficients')
        targets.add(target)
    if any(o>=p.nodes for o in p.output_ids):raise ValueError('invalid output field')

def pattern_word(spec:object,word:int)->int:
    if spec in (None,0,False):return 0
    if spec in (1,True):return MASK
    if isinstance(spec,dict) and 'input_bit' in spec:
        b=int(spec['input_bit'])
        if not 0<=b<63:raise ValueError('input_bit out of range')
        return sum((((word*32+i)>>b)&1)<<i for i in range(32))
    if isinstance(spec,dict) and 'words' in spec:
        values=spec['words']
        if not values:raise ValueError('empty seed pattern')
        v=values[word%len(values)]
        return (int(v,0) if isinstance(v,str) else int(v))&MASK
    raise ValueError(f'unknown seed pattern {spec!r}')

def compile_program(spec:dict)->Program:
    lanes=int(spec.get('lanes',256));bins=int(spec.get('bins_per_phi',64))
    if lanes<32 or lanes&(lanes-1):raise ValueError('lanes must be a power of two >=32')
    if bins<1 or bins>65536 or bins&(bins-1):raise ValueError('bins_per_phi must be a power of two <=65536')
    nodes=spec.get('nodes',[])
    if not nodes:raise ValueError('program has no expression fields')
    labels={node['id']:i for i,node in enumerate(nodes)}
    if len(labels)!=len(nodes):raise ValueError('duplicate expression id')
    # All 256 ternary Boolean functions, as 256 genuine 8-bit truth fields.
    atlas=[0]*16
    catalogue_base=len(atlas)
    for i in range(0,256,4):atlas.append(i|((i+1)<<8)|((i+2)<<16)|((i+3)<<24))
    definitions={name:catalogue_base*32+truth*8 for name,truth in NAMES.items()}
    definitions.update({f'LUT_{i:02X}':catalogue_base*32+i*8 for i in range(256)})
    custom_begin=len(atlas)*32
    for name,truth in spec.get('definitions',{}).items():
        if name in definitions:raise ValueError('custom name shadows catalogue alias')
        value=int(truth,0) if isinstance(truth,str) else int(truth)
        if not 0<=value<256:raise ValueError('truth table must fit eight bits')
        definitions[name]=len(atlas)*32;atlas.append(value)
    custom_end=len(atlas)*32
    while len(atlas)%8:atlas.append(0)
    desc_base=len(atlas);atlas += [0]*(8*len(nodes))
    zero=QUOTE|(catalogue_base*32) # Truth bit zero of LUT_00.
    def ref(value:object)->tuple[int,int]:
        if value is None or value==0:return zero,0
        if value==1:return QUOTE|(catalogue_base*32+255*8),0
        if isinstance(value,str):return labels[value],0
        if isinstance(value,dict) and ('T' in value or 'A' in value):return labels[value.get('T',value.get('A'))],1
        if isinstance(value,dict) and 'quote' in value:
            q=value['quote']
            if 'operator' in q:
                bit=int(q['bit'])
                if not 0<=bit<8:raise ValueError('truth coefficient must be 0..7')
                address=definitions[q['operator']]+bit
            elif 'expression' in q:
                bit=int(q['bit'])
                if not 0<=bit<256:raise ValueError('expression bit must be 0..255')
                address=(desc_base+8*labels[q['expression']])*32+bit
            else:raise ValueError('quote needs operator or expression')
            return QUOTE|address,0
        raise ValueError(f'unknown reference {value!r}')
    for i,node in enumerate(nodes):
        name=node.get('op','ID');inputs=list(node.get('inputs',[]))
        if name not in definitions:raise ValueError(f'undefined operator {name}')
        if len(inputs)>3:raise ValueError('a primitive field accepts <=3 ports; compose expressions for more')
        if name in ('T','A'):
            if len(inputs)!=1 or not isinstance(inputs[0],str):raise ValueError('T/A node needs one expression id')
            inputs=[{'T':inputs[0]}]
        inputs+= [None]*(3-len(inputs));ports=[ref(v) for v in inputs]
        seed_spec=node.get('seed',0)
        seed_tag=int(seed_spec['input_bit'])+1 if isinstance(seed_spec,dict) and 'input_bit' in seed_spec else 0
        record=[definitions[name],ports[0][0],ports[1][0],ports[2][0],sum(v[1]<<k for k,v in enumerate(ports)),(i<<16)//bins,i,seed_tag]
        atlas[desc_base+i*8:desc_base+i*8+8]=record
    patch_base=len(atlas)
    for patch in spec.get('publish',[]):
        name=patch['operator'];bit=int(patch['bit'])
        if name not in spec.get('definitions',{}) or not 0<=bit<8:raise ValueError('publish targets a custom operator coefficient')
        atlas.extend([definitions[name]+bit,labels[patch['source']],int(patch.get('lane',0)),0])
    atlas[:16]=[0xA005F1E1,5,len(nodes),lanes,desc_base,patch_base,len(spec.get('publish',[])),bins,catalogue_base,256,custom_begin,custom_end,0,0,0,0]
    state=[pattern_word(node.get('seed',0),w) for node in nodes for w in range(lanes//32)]
    outputs=[labels[x] for x in spec.get('outputs',[nodes[-1]['id']])]
    manifest={'version':'5.0','title':spec.get('title','Field program'),'alpha':'A = T; previous-snapshot edges',
              'lanes':lanes,'node_ids':labels,'operator_bit_addresses':definitions,'outputs':spec.get('outputs',[nodes[-1]['id']]),
              'atlas_words':len(atlas),'state_bits':len(nodes)*lanes,'two_state_bytes':len(state)*8,
              'expression_record_bytes':32,'program_description':spec,
              'codec':'Every finite field word denotes union of unit-radius intervals centered at 4*j for set bits, plus sentinel at -4.'}
    p=Program(len(nodes),lanes//32,atlas,state,desc_base,patch_base,len(spec.get('publish',[])),outputs,manifest)
    validate(p);return p

def lut_scalar(tt:int,a:int,b:int,c:int)->int:return (tt>>(a+2*b+4*c))&1

def eval_scalar(p:Program,ticks:int)->tuple[list[int],list[int]]:
    atlas=p.atlas.copy();previous=p.seed.copy();lanes=p.words*32
    for _ in range(ticks):
        current=[0]*len(previous)
        for n in range(p.nodes):
            rec=atlas[p.desc_base+8*n:p.desc_base+8*n+8];address=rec[0]
            tt=(atlas[address>>5]>>(address&31))&255
            for lane in range(lanes):
                values=[]
                for k,reference in enumerate(rec[1:4]):
                    if reference&QUOTE:
                        q=reference&~QUOTE;values.append((atlas[q>>5]>>(q&31))&1)
                    else:
                        data=previous if rec[4]&(1<<k) else current
                        values.append((data[reference*p.words+(lane>>5)]>>(lane&31))&1)
                current[n*p.words+(lane>>5)]|=lut_scalar(tt,*values)<<(lane&31)
        updated=atlas.copy()
        for k in range(p.patches):
            target,source,lane,_=atlas[p.patch_base+4*k:p.patch_base+4*k+4]
            value=(current[source*p.words+(lane>>5)]>>(lane&31))&1;mask=1<<(target&31)
            updated[target>>5]=(updated[target>>5]&~mask)|(value<<(target&31))
        atlas,previous=updated,current
    return atlas,previous

def read_output(path:Path)->tuple[list[int],list[int],int,int,int]:
    raw=path.read_bytes()
    if raw[:8]!=OUTPUT_MAGIC or len(raw)<32:raise ValueError('invalid result')
    ticks,nodes,words,na,ns,reserved=struct.unpack_from('<6I',raw,8)
    if reserved or ns!=nodes*words or len(raw)!=32+4*(na+ns):raise ValueError('result size mismatch')
    data=list(struct.unpack_from(f'<{na+ns}I',raw,32))
    return data[:na],data[na:],ticks,nodes,words

def distance_word(bits:list[int],q:int)->int:
    """Exact signed Euclidean distance to the word's disjoint closed intervals.
    q and every interval endpoint are integers: no real approximations required.
    This reference query is not performed during program execution.
    """
    centres=[-4]+[4*i for i,b in enumerate(bits) if b]
    return min(abs(q-c)-1 for c in centres)

def main()->None:
    import argparse
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('source',type=Path);parser.add_argument('output',type=Path);parser.add_argument('--lanes',type=int)
    args=parser.parse_args();spec=json.loads(args.source.read_text())
    if args.lanes is not None:spec['lanes']=args.lanes
    p=compile_program(spec)
    p.save(args.output);args.output.with_suffix('.manifest.json').write_text(json.dumps(p.manifest,indent=2)+'\n')
    print(json.dumps({'output':str(args.output),'nodes':p.nodes,'lanes':p.words*32,'atlas_bytes':len(p.atlas)*4,'patches':p.patches}))
if __name__=='__main__':main()
