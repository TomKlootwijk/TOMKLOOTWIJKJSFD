#!/usr/bin/env python3
"""Export integer/fixed-point log-polar storage labels; A is the T snapshot axis.
No Cartesian reconstruction or transcendental floating arithmetic is required.
The exact log labels define the layout. Optional radii are Q48 approximations.
"""
import argparse,json
from math import isqrt
from pathlib import Path
from field_program import Program
p=argparse.ArgumentParser(description=__doc__);p.add_argument('program',type=Path);p.add_argument('output',type=Path);a=p.parse_args();program=Program.load(a.program)
bins=program.atlas[7];unit=1<<48;multiplier=(unit+isqrt(5<<96))//2
for _ in range(bins.bit_length()-1):multiplier=isqrt(multiplier<<48)
mantissa=unit;exponent=0;rows=[]
for n in range(program.nodes):
    rows.append({'expression_row':n,'definition_descriptor_word':program.desc_base+8*n,'rho_log_phi_q16':program.atlas[program.desc_base+8*n+5],
                 'radius_mantissa_q31':mantissa>>17,'radius_binary_exponent':exponent})
    mantissa=(mantissa*multiplier)>>48
    while mantissa>=2*unit:mantissa>>=1;exponent+=1
r={'version':'5.0','R':'log_phi(r/r0)=node/bins_per_phi; r0=1','Theta':'(lane+1/2)/(32*words) turns, exact rational label',
   'A':'T snapshot index; two physical state pages reused, older history is not retained',
   'bins_per_phi':bins,'theta_lanes':program.words*32,'rows':rows,
   'runtime':'Only integer field addresses are used. Radii are decoding metadata, not required by Boolean evaluation.',
   'radius_formula':'radius ~ mantissa_q31 * 2**(radius_binary_exponent-31)'}
a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'rows':len(rows),'output':str(a.output)}))
