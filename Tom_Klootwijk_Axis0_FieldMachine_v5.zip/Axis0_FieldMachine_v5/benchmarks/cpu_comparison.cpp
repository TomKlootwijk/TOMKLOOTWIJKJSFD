// Added after the kernel freeze. The FP32 baseline is outside the field engine.
#include "axis0/host.hpp"
using namespace axis0;
struct Sample{std::uint64_t nanoseconds,hash;};
Sample packed(Program p,Word ticks){std::vector<Word>scratch(p.state.size());auto a=std::chrono::steady_clock::now();for(Word n=0;n<ticks;++n)tick(p,scratch);auto b=std::chrono::steady_clock::now();return {elapsed(a,b),digest(p)};}
template<class T>Sample unpacked(Program p,Word ticks){
    const std::size_t lanes=std::size_t(p.s.words)*32;
    std::vector<T>state(lanes*p.s.nodes),next(state.size());
    for(Word n=0;n<p.s.nodes;++n)for(std::size_t i=0;i<lanes;++i)state[n*lanes+i]=T((p.state[n*p.s.words+(i>>5)]>>(i&31))&1u);
    auto begin=std::chrono::steady_clock::now();
    for(Word t=0;t<ticks;++t){
        for(std::size_t i=0;i<lanes;++i)for(Word n=0;n<p.s.nodes;++n){
            Word b=p.s.desc_base+8*n,ptr=p.atlas[b],tt=(p.atlas[ptr>>5]>>(ptr&31))&255u,index=0;
            for(Word k=0;k<3;++k){Word ref=p.atlas[b+1+k],v;if(ref&QUOTE){Word at=ref&~QUOTE;v=(p.atlas[at>>5]>>(at&31))&1u;}else v=Word((p.atlas[b+4]&(1u<<k)?state:next)[std::size_t(ref)*lanes+i]!=T(0));index|=v<<k;}
            next[std::size_t(n)*lanes+i]=T((tt>>index)&1u);
        }state.swap(next);
    }
    auto end=std::chrono::steady_clock::now();std::fill(p.state.begin(),p.state.end(),0);
    for(Word n=0;n<p.s.nodes;++n)for(std::size_t i=0;i<lanes;++i)if(state[n*lanes+i]!=T(0))p.state[n*p.s.words+(i>>5)]|=1u<<(i&31);
    return {elapsed(begin,end),digest(p)};
}
int main(int argc,char**argv){try{if(argc<3)throw std::runtime_error("cpu_comparison program output.json");auto p=load(argv[1]);if(p.s.patches)throw std::runtime_error("benchmark uses a static-definition program");constexpr Word ticks=64,repetitions=7;std::array<std::vector<std::uint64_t>,3>times;std::uint64_t expected=packed(p,ticks).hash;
    for(Word r=0;r<repetitions;++r)for(Word j=0;j<3;++j){Word which=(r+j)%3;Sample s=which==0?packed(p,ticks):which==1?unpacked<unsigned char>(p,ticks):unpacked<float>(p,ticks);if(s.hash!=expected)throw std::runtime_error("representation outputs differ");times[which].push_back(s.nanoseconds);}
    std::ostringstream s;s<<"{\"version\":\"5.0\",\"phase\":\"post-hoc\",\"execution\":\"CPU only\",\"program_nodes\":"<<p.s.nodes<<",\"lanes\":"<<std::uint64_t(p.s.words)*32<<",\"ticks\":"<<ticks<<",\"repetitions\":"<<repetitions<<",\"all_final_bits_agree\":true,\"cases\":[";
    for(int i=0;i<3;++i){if(i)s<<',';auto sorted=times[i];std::sort(sorted.begin(),sorted.end());s<<"{\"representation\":\""<<(i==0?"packed bit fields":i==1?"uint8 Boolean fields":"FP32 Boolean fields")<<"\",\"median_ns\":"<<sorted[repetitions/2]<<",\"samples_ns\":[";for(std::size_t j=0;j<times[i].size();++j){if(j)s<<',';s<<times[i][j];}s<<"]}";}
    s<<"],\"method\":\"All three interpret the same static expression descriptors; buffers preallocated; timer excludes initial unpack/final repack, loading and output digest. Scalar baselines index the 8-bit truth table, packed version uses seven word-wide selections. These are reference loops, not production-tuned library or GPU baselines.\"}";emit(s.str(),argv[2]);return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
