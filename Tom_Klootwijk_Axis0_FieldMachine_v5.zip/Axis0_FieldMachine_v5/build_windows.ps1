$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DAXIS0_CUDA=ON -DAXIS0_ARCH=120
    if ($LASTEXITCODE -ne 0) { throw "Configure failed; check CUDA Toolkit and Visual Studio CUDA integration." }
    cmake --build build --config Release --parallel
    if ($LASTEXITCODE -ne 0) { throw "Build failed." }
    ctest --test-dir build -C Release --output-on-failure
    if ($LASTEXITCODE -ne 0) { throw "Core tests failed." }
    Write-Host "Run: python tools\gpu_check.py --exe .\build\Release\axis0_gpu.exe --json verification\laptop_tests.json"
} finally { Pop-Location }
