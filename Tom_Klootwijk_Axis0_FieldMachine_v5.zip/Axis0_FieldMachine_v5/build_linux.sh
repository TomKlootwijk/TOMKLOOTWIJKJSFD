#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cmake -S . -B build -DAXIS0_CUDA=ON -DAXIS0_ARCH=120 -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
printf '\nRun: python tools/gpu_check.py --exe ./build/axis0_gpu --json verification/laptop_tests.json\n'
