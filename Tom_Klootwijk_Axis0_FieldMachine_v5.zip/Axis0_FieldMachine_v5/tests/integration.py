#!/usr/bin/env python3
"""Independent scalar oracle vs executable field programs, codecs and clock laws."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from field_program import compile_program,Program,read_output,eval_scalar,distance_word,QUOTE

def bits(state,words,node,lanes):return [(state[node*words+(i>>5)]>>(i&31))&1 for i in range(lanes)]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--exe',required=True,type=Path);p.add_argument('--json',type=Path);a=p.parse_args()
    exe=str(a.exe.resolve());runs=0;comparisons=0;rng=random.Random(19900710)
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        def run(program,ticks):
            nonlocal runs,comparisons
            source=tmp/'p.a0f';result=tmp/'r.a0o';program.save(source)
            subprocess.run([exe,'--program',str(source),'--ticks',str(ticks),'--out',str(result)],check=True,capture_output=True)
            atlas,state,n,nn,w=read_output(result)
            expected_atlas,expected_state=eval_scalar(program,ticks)
            assert atlas==expected_atlas and state==expected_state
            assert nn==program.nodes and w==program.words and n==ticks
            runs+=1;comparisons+=len(state)*32
            return atlas,state
        allops=Program.load(ROOT/'examples/all_boolean_operators.a0f');_,state=run(allops,1)
        for tt in range(256):
            for lane,value in enumerate(bits(state,allops.words,3+tt,256)):
                assert value==(tt>>(lane&7))&1
        add=Program.load(ROOT/'examples/adder4.a0f');_,state=run(add,1)
        for lane in range(256):
            answer=sum(bits(state,add.words,n,256)[lane]<<k for k,n in enumerate(add.output_ids))
            assert answer==(lane&15)+(lane>>4)
        counter=Program.load(ROOT/'examples/clocked_counter.a0f')
        for ticks in (0,1,2,7,15,16,17,63):
            _,state=run(counter,ticks)
            for lane in range(256):
                answer=sum(((state[n*counter.words+(lane>>5)]>>(lane&31))&1)<<k for k,n in enumerate(counter.output_ids))
                assert answer==((lane+ticks)&15)
        meta=Program.load(ROOT/'examples/self_definition.a0f')
        live=json.loads((ROOT/'examples/self_definition.manifest.json').read_text())['operator_bit_addresses']['LIVE']
        trace=[]
        for ticks in range(1,9):
            atlas,state=run(meta,ticks)
            truth=(atlas[live>>5]>>(live&31))&255
            assert truth==(0x55 if ticks&1 else 0xaa)
            output=bits(state,meta.words,1,256)
            assert output==[(lane&1)^((ticks-1)&1) for lane in range(256)]
            trace.append({'tick':ticks,'definition_after_commit':f'0x{truth:02x}','first_8_output_bits':output[:8]})
        interpreter=Program.load(ROOT/'examples/interpreter_in_fields.a0f');_,state=run(interpreter,1)
        answer=bits(state,interpreter.words,interpreter.output_ids[0],2048)
        assert answer==[((lane>>3)>>(lane&7))&1 for lane in range(2048)]
        constraints=Program.load(ROOT/'examples/constraint_filter.a0f');_,state=run(constraints,1)
        accepted=[]
        for lane,value in enumerate(bits(state,constraints.words,constraints.output_ids[0],256)):
            x=[(lane>>i)&1 for i in range(4)];expected=(x[0]|x[1]) & ((1-x[0])|x[2]) & (x[2]^x[3])
            assert value==expected
            if lane<16 and value:accepted.append(lane)
        for case in range(100):
            n=rng.randrange(3,30);nodes=[]
            for i in range(n):
                args=[]
                for port in range(3):
                    kind=rng.randrange(5)
                    if kind==0:args.append({'T':f'n{rng.randrange(n)}'})
                    elif kind==1:args.append({'quote':{'operator':'LIVE','bit':rng.randrange(8)}})
                    elif kind==2 and i:args.append(f'n{rng.randrange(i)}')
                    else:args.append(rng.randrange(2))
                nodes.append({'id':f'n{i}','op':'LIVE' if rng.randrange(4)==0 else f'LUT_{rng.randrange(256):02X}',
                              'inputs':args,'seed':{'words':[rng.getrandbits(32),rng.getrandbits(32)]}})
            spec={'lanes':32<<rng.randrange(3),'definitions':{'LIVE':rng.randrange(256)},'nodes':nodes,
                  'publish':[{'operator':'LIVE','bit':k,'source':f'n{rng.randrange(n)}','lane':rng.randrange(32)} for k in rng.sample(range(8),rng.randrange(9))]}
            run(compile_program(spec),rng.randrange(5))
        rejected=0
        for spec in ({'nodes':[{'id':'x','inputs':['x']}]},
                     {'nodes':[{'id':'x','op':'MISSING'}]},
                     {'definitions':{'LIVE':0},'nodes':[{'id':'x'}],'publish':[{'operator':'LIVE','bit':0,'source':'x'},{'operator':'LIVE','bit':0,'source':'x'}]}):
            try:compile_program(spec)
            except (ValueError,KeyError):rejected+=1
        assert rejected==3
        (tmp/'bad.a0f').write_bytes(b'A0FM5\0\0\0')
        assert subprocess.run([exe,'--program',str(tmp/'bad.a0f')],capture_output=True).returncode!=0
    # Signed distance to generated *disjoint* intervals, checked at every anchor,
    # both boundary points, and the rest of an integer test lattice.
    codec_words=0;codec_queries=0
    for word in range(256):
        field=[(word>>i)&1 for i in range(8)]
        for i,b in enumerate(field):assert (distance_word(field,4*i)<0)==bool(b)
        intervals=[(-5,-3)]+[(4*i-1,4*i+1) for i,b in enumerate(field) if b]
        for q in range(-10,40):
            inside=any(lo<q<hi for lo,hi in intervals)
            magnitude=min(min(abs(q-lo),abs(q-hi)) for lo,hi in intervals)
            expected=-magnitude if inside else magnitude
            assert distance_word(field,q)==expected;codec_queries+=1
        codec_words+=1
    report={'status':'PASS','version':'5.0','executable_program_runs':runs,
            'scalar_state_bits_compared':comparisons,'random_programs':100,
            'all_ternary_operator_assignment_checks':2048,'adder_input_pairs':256,
            'counter_ticks_checked':[0,1,2,7,15,16,17,63],
            'meta_definition_trace':trace,'interpreter_in_own_fields_cases':2048,
            'constraint_satisfying_assignments_4vars':accepted,
            'exact_sdf_codec_words':codec_words,'exact_sdf_integer_queries':codec_queries,
            'rejected_invalid_programs':rejected,'rejected_truncated_files':1,'gpu_execution':'NOT_RUN'}
    text=json.dumps(report,indent=2);print(text)
    if a.json:a.json.write_text(text+'\n')
if __name__=='__main__':main()
