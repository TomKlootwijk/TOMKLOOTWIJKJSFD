#include "axis0/host.hpp"
#include <random>
int main(){using namespace axis0;try{std::uint64_t cases=0;std::mt19937 rng(19900710);
for(Word tt=0;tt<256;++tt){for(Word k=0;k<8;++k){Word a=broadcast(k),b=broadcast(k>>1),c=broadcast(k>>2);if(evaluate_truth(tt,a,b,c)!=broadcast(tt>>k))throw std::runtime_error("truth field mismatch");++cases;}
for(Word r=0;r<128;++r){Word a=Word(rng()),b=Word(rng()),c=Word(rng()),answer=0;for(Word bit=0;bit<32;++bit){Word k=((a>>bit)&1)|(((b>>bit)&1)<<1)|(((c>>bit)&1)<<2);answer|=((tt>>k)&1)<<bit;}if(answer!=evaluate_truth(tt,a,b,c))throw std::runtime_error("parallel truth mismatch");++cases;}}
std::cout<<"{\"status\":\"PASS\",\"all_truth_fields\":256,\"exhaustive_scalar_assignments\":2048,\"packed_random_cases\":32768,\"total_core_cases\":"<<cases<<"}\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
