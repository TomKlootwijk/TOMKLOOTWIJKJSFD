# Axis 0 FieldMachine — v5.0

**Tom Klootwijk · NL200678942 · date supplied 10-07-1990**

A calculating device, not a renderer: operator definitions, expression wiring,
state, quoted descriptions and updates to operator definitions are all represented
by packed fields. The operator's truth table is read from a field; it is not
selected by a C++ opcode switch. Expressions may refer to a previous snapshot
through **A = T**. A supplied example reads and changes its own operator definition.

## Delivery status

The C++ integer interpreter was compiled and tested on the available CPU. Its
Boolean primitive passed 34,816 core cases. A separate scalar oracle agreed on
120 executable program runs, including 100 generated programs. The SDF coding
identity, clocked recursion, arithmetic, reflection and rule publication were
also tested. Address/undefined-behavior sanitizer runs passed.

There is **no CUDA toolkit or NVIDIA GPU in the delivery environment**. Therefore
`cuda/evaluator.cu` is supplied **uncompiled and unexecuted here**. This is a source
package, not a precompiled laptop executable. `verification/` records actual
status, including the failed CUDA configure attempt. No GPU time or cache-hit
rate has been invented. Start with the GPU check harness on your laptop.

## What changed from a fixed bit-grid kernel

This release evaluates a **program stored as field definitions**:

* All 256 Boolean functions of three input bits are available as eight-bit truth
  fields. AND, OR, NOT, XOR, NAND, majority and selection are aliases for fields.
* Each expression is a 256-bit field describing its operator field, three ports,
  time-delay flags, radial label, identity and seed convention.
* State is one bit per expression per independent case. Thirty-two cases are
  processed together in each uint32 word.
* Quotation reads operator or expression bits as ordinary program inputs.
* A publication rule can write computed bits back to a custom operator field
  after the current tick. The next tick uses the new definition.
* `interpreter_in_fields` expresses the interpreter's Boolean evaluator as seven
  selection expressions in this very language. It was checked for all 2,048
  combinations of three arguments and an eight-bit truth table.

A small fixed substrate still loads fields, follows valid references, performs
Boolean selection and orders snapshots. A stored definition does not electrically
execute without such a reading rule. The field-form interpreter example makes
that rule inspectable; it does not remove the GPU instruction set.

## Exact SDF representation, without runtime coordinate arithmetic

For a finite bitword b of known length, define an implicit solid on the line:

```
Omega_b = [-5,-3] union { [4*j-1,4*j+1] for every j with b[j]=1 }
D_b(q) = min over interval centres c of (abs(q-c)-1)
```

The fixed sentinel interval is centred at -4. All intervals are disjoint, so this
is an exact signed Euclidean distance to their union boundary, with negative
interior. At anchor q=4*j, `b[j] == (D_b(4*j) < 0)`. Accordingly, the engine reads
that sign directly from the stored bit instead of calculating distances. This
is a *generative SDF definition* for every operator, expression and result word,
not a grid containing approximate numerical distance samples.

This **coding geometry is a new implementation construction**. It is distinct
from the log-polar storage labels and is not the source's Klein-bottle geometry.
It does not losslessly compress arbitrary user geometry/distance values into one
bit. It gives the finite field language an explicit, testable SDF interpretation.

Inspect it directly:

```bash
python tools/inspect_field.py examples/self_definition.a0f --manifest examples/self_definition.manifest.json --operator LIVE
```

The initial LIVE truth field has bits `01010101` in least-significant-bit-first
order. Its anchor distances alternate `3,-1,3,-1,...`, so the stored bits are
exactly the negative-distance tests. The tests cover all 256 eight-bit words and
12,800 integer distance queries.

## Build

CPU-only (C++17 compiler and CMake 3.24+):

```bash
cmake -S . -B build-cpu -DAXIS0_CUDA=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-cpu --config Release --parallel
ctest --test-dir build-cpu -C Release --output-on-failure
python tests/integration.py --exe ./build-cpu/axis0_cpu --json verification/local_cpu.json
```

On Windows, use `build-cpu\Release\axis0_cpu.exe` in the Python command.

RTX 5070 Ti Laptop target: CUDA **SM120**, supported by CUDA 12.8 and later. Use
an installed NVIDIA driver, compatible host compiler and CUDA Toolkit. On a
Visual Studio 2022 Developer PowerShell with CUDA integration:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DAXIS0_CUDA=ON -DAXIS0_ARCH=120
cmake --build build --config Release --parallel
.\build\Release\axis0_gpu.exe --info
python tools\gpu_check.py --exe .\build\Release\axis0_gpu.exe --json verification\laptop_tests.json
```

On Linux:

```bash
cmake -S . -B build -DAXIS0_CUDA=ON -DAXIS0_ARCH=120 -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
python tools/gpu_check.py --exe ./build/axis0_gpu --json verification/laptop_tests.json
```

Python tools require Python 3.10+ and the standard library only. No network,
account access, driver modification or clock/power manipulation is performed.

## Calculate, inspect and read out

The following examples use the CPU path that was executed here. Substitute the
GPU executable after building and passing `gpu_check.py`.

### Ordinary arithmetic expressed entirely as fields

```bash
./build-cpu/axis0_cpu --program examples/adder4.a0f --ticks 1 --out addition.a0o
python tools/readout.py addition.a0o --manifest examples/adder4.manifest.json --lanes 16
```

The input cases encode all 256 pairs of 4-bit numbers. Sum and carry are Boolean
expressions. The five returned bit fields represent the exact sum from 0 to 30.
No floating-point addition occurs; several one-bit fields represent each integer.

### A = T and actual delayed self-reference

```bash
./build-cpu/axis0_cpu --program examples/clocked_counter.a0f --ticks 17 --out counter.a0o
python tools/readout.py counter.a0o --manifest examples/clocked_counter.manifest.json
```

Each case holds a 4-bit state. Current edges reference an already evaluated
expression in the same tick. A/T edges reference the **previous snapshot** and
may point back to the expression itself. After n ticks, the output in case i is
`(i+n) mod 16`. The clock rule is explicitly implemented, not inferred from an
entropy or spacetime claim. A is the time/snapshot component, not an opacity value.

### A definition that changes its own future meaning

```bash
./build-cpu/axis0_cpu --program examples/self_definition.a0f --ticks 2 --out self.a0o
python tools/readout.py self.a0o --manifest examples/self_definition.manifest.json --lanes 8
```

LIVE starts as ID (`0xaa`). Its eight coefficients are quoted as field inputs,
complemented, and published back. The next tick sees NOT (`0x55`); the following
one sees ID again. Thus the program changes a definition, rather than only
changing a data operand. The supplied loop intentionally alternates; it does not
claim convergence or self-replication.

Publication is restricted to declared custom truth coefficients. It does not
rewrite the compiled CUDA kernel or unvalidated descriptor pointers. All
publications happen after evaluation against an immutable snapshot. Each target
bit has one writer; GPU atomics support disjoint bits in the same packed word.
The source lane is declared per publication record. One shared rule atlas is
used across all cases; independent rule evolution per case is not implemented.

### The evaluator as a field expression

```bash
./build-cpu/axis0_cpu --program examples/interpreter_in_fields.a0f --ticks 1 --out evaluator.a0o
```

The example takes 11 Boolean inputs: three operands and eight truth coefficients.
Seven MUX field expressions implement the same evaluation law as the small
interpreter substrate. Its output agrees on all 2,048 input combinations.

## Write your own program

Edit a JSON example and compile it:

```bash
python tools/field_program.py examples/clocked_counter.json large_counter.a0f --lanes 32768
```

The compiler stores every ternary truth function, then custom definitions and
expression fields. The binary compiler emits a readable manifest and typed
references. Undefined names and unclocked cycles are rejected instead of being
given invented meanings. See `docs/MODEL_AND_ABI.md` for the complete grammar.

`A(x)` and `T(x)` are aliases for the previous snapshot of x. They are not the
original source's undefined AT or circled-T symbols. Longer Boolean functions
are expressed by composing nodes; numbers are bit-sliced over multiple nodes.

## Log-encoded polar storage and A/T

State coordinates are `(R, Theta, A)`:

* `R`: expression row; `log_phi(r/r0)=row/bins_per_phi`, r0=1.
* `Theta`: independent case at rational angle `(case+1/2)/case_count` turns.
* `A=T`: current or previous temporal snapshot, implemented as two reused pages.

A descriptor stores the row's Q16 log label. A native flat integer address maps
this row/case layout into the texture. The calculation never needs to decode
radius, angle, sine, cosine or distance. The labels supply a layout, **not a
geometric optimization proof**. This release does not couple adjacent angular
cases; they are independent Boolean calculations, not a spatial fluid.

```bash
python tools/logpolar_layout.py examples/interpreter_in_fields.a0f layout.json
```

That utility optionally derives radius metadata using integer square roots and
fixed-point phi approximations. The kernel itself does not consume those radii.
It does not include an apex at r=0 or a Klein seam. Those source structures require
additional executable laws rather than merely renaming an address grid.

## Cache, low-level access and VRAM

Three GPU backends execute the same program:

```
--defs global
--defs texture
--defs shared
```

`texture` uses integer `tex1Dfetch<unsigned int>` for the definition atlas and the
previous state. There are no filtered float coordinates. New current-expression
values are global-memory stores and same-thread loads, never texture reads of a
value written during the same launch. Programs with large state are divided into
whole-case shards under device-reported texture limits.

`shared` explicitly stages the atlas in per-block shared memory for the duration
of the kernel. It is rejected when the complete atlas does not fit the queried
per-block capacity. Staging cost and occupancy effects are not assumed free.

`--persist-kib 64` requests an L2 persisting-access policy for the definition
window, capped at queried device limits. This is a priority hint, not a residency
promise or a texture-cache reservation. The driver requires one **float-typed
host metadata field** (`hitRatio=1.0f`) for that optional API. It is not numerical
field computation. Leave persistence at zero to omit the hint entirely.

Texture cache cannot be manually stuffed with permanently pinned definitions
through these CUDA APIs. Filling it with duplicate unused definitions would add
capacity pressure rather than new semantics. The prototype therefore keeps the
real hot program compact: all 256 primitive truth fields occupy only **256 bytes**.

Use remaining VRAM for more independent cases:

```bash
./build/axis0_gpu --program examples/interpreter_in_fields.a0f --ticks 32 --defs texture --vram-percent 80 --verify --json batch.json
```

The runtime queries currently free memory, subtracts known setup storage and
allocates two state pages. Seed fields marked `input_bit` are generated directly
on-device for the expanded case indices; explicit seed patterns repeat. Cases
also repeat once the declared input bits exhaust their distinct combinations.
The CLI reads back the base case set, while the report counts all executed cases.
This capacity experiment is not a larger connected expression graph and not
infinite storage or automatic graph growth. A 100% allocation may still fail due
to resource/allocator overhead or concurrent GPU use; that failure is reported.

## Metrics

Actual CPU reference benchmark, after the implementation was fixed:
32,768 cases, 64 counter ticks, seven repetitions, same interpreted expression
fields, all final bits equal. Packed: **3.726 ms**; uint8 Boolean: **67.345 ms**;
FP32 Boolean: **84.890 ms**. This is 18.1x and 22.8x relative to those reference
interpreters, not relative to optimized GPU libraries or numerical SDF software.

A purpose-built native counter was **7.5x faster than the field interpreter** on
its output-only task. The field representation buys inspectable, changeable
program definitions; it is not automatically the fastest way to do a fixed add.
Full methodology and raw samples are in `docs/METRICS.md` and `verification/`.

Run actual GPU experiments, including correctness checks:

```bash
python tools/gpu_check.py --exe ./build/axis0_gpu --json gpu_tests.json
python tools/gpu_metrics.py --exe ./build/axis0_gpu --output gpu_metrics.json
python tools/audit_integer.py --ptx
```

The PTX audit remains NOT_RUN in this delivery because nvcc is absent. A source
scan does not establish generated instruction types. Device timing includes
launches, definition publication and completion; it excludes loading, allocation,
initialization, result copying and CPU verification. No hardware cache-hit rate
is reported; a profiler is required for that metric.

See the PDF, `docs/MODEL_AND_ABI.md`, `docs/SOURCES.md`, and the exact test records.
