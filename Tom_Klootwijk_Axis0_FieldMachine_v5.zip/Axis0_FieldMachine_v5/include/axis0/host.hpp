#pragma once
#include "core.hpp"
#include <algorithm>
#include <array>
#include <chrono>
#include <charconv>
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
namespace axis0 {
inline Word read32(std::istream& in){std::array<unsigned char,4>b{};in.read(reinterpret_cast<char*>(b.data()),4);if(!in)throw std::runtime_error("truncated binary");return Word(b[0])|(Word(b[1])<<8)|(Word(b[2])<<16)|(Word(b[3])<<24);}
inline void write32(std::ostream& o,Word x){std::array<char,4>b{char(x&255),char((x>>8)&255),char((x>>16)&255),char(x>>24)};o.write(b.data(),4);}
struct Program {Shape s{};std::vector<Word> atlas,state,outputs;};
inline void validate(const Program& p) {
    const Shape&s=p.s;
    if(!s.nodes||!s.words||(s.words&(s.words-1))||s.atlas_words<16||s.atlas_words>=QUOTE/32)throw std::runtime_error("unsupported shape");
    if(std::uint64_t(s.desc_base)+8ull*s.nodes>s.atlas_words||std::uint64_t(s.patch_base)+4ull*s.patches>s.atlas_words)throw std::runtime_error("field range overflow");
    if(p.state.size()!=std::uint64_t(s.nodes)*s.words||p.atlas.size()!=s.atlas_words)throw std::runtime_error("state size mismatch");
    for(Word n=0;n<s.nodes;++n){Word b=s.desc_base+8*n,t=p.atlas[b],d=p.atlas[b+4];
        if(t%8||std::uint64_t(t)+8>32ull*s.atlas_words||d&~7u||p.atlas[b+7]>63)throw std::runtime_error("bad expression field");
        for(Word k=0;k<3;++k){Word ref=p.atlas[b+1+k];if(ref&QUOTE){if((ref&~QUOTE)>=32ull*s.atlas_words||(d&(1u<<k)))throw std::runtime_error("bad quote");}
            else if(ref>=s.nodes||(!(d&(1u<<k))&&ref>=n))throw std::runtime_error("unclocked cycle or forward reference");}}
    if(p.atlas[10]>p.atlas[11]||p.atlas[11]>32ull*s.desc_base||p.atlas[10]<80u*32u)throw std::runtime_error("bad custom definition region");
    std::vector<Word> targets;
    for(Word i=0;i<s.patches;++i){Word b=s.patch_base+4*i,target=p.atlas[b];
        if(target<p.atlas[10]||target>=p.atlas[11]||target>=32ull*s.atlas_words||p.atlas[b+1]>=s.nodes||p.atlas[b+2]>=std::uint64_t(s.words)*32||p.atlas[b+3])throw std::runtime_error("bad publication field");targets.push_back(target);}
    std::sort(targets.begin(),targets.end());if(std::adjacent_find(targets.begin(),targets.end())!=targets.end())throw std::runtime_error("duplicate publication target");
    for(Word id:p.outputs)if(id>=s.nodes)throw std::runtime_error("bad output reference");
}
inline Program load(const std::string& path){std::ifstream in(path,std::ios::binary);if(!in)throw std::runtime_error("cannot read program");std::array<char,8>m{};in.read(m.data(),8);if(m!=std::array<char,8>{'A','0','F','M','5','\0','\0','\0'})throw std::runtime_error("bad program magic");std::array<Word,12>h{};for(auto&x:h)x=read32(in);if(h[0]!=5||h[9]||h[10]||h[11])throw std::runtime_error("bad header");
    const std::uint64_t payload=std::uint64_t(h[3])+h[4]+h[8];auto start=in.tellg();in.seekg(0,std::ios::end);auto end=in.tellg();if(end-start!=std::streamoff(payload*4))throw std::runtime_error("file length mismatch");in.seekg(start);
    Program p;p.s={h[1],h[2],h[3],h[5],h[6],h[7]};p.atlas.resize(h[3]);p.state.resize(h[4]);p.outputs.resize(h[8]);for(auto*v:{&p.atlas,&p.state,&p.outputs})for(Word&x:*v)x=read32(in);validate(p);return p;}
inline void commit(Program&p,const std::vector<Word>&current){auto next=p.atlas;for(Word i=0;i<p.s.patches;++i){Word b=p.s.patch_base+4*i,bit=p.atlas[b],node=p.atlas[b+1],lane=p.atlas[b+2];Word v=(current[std::uint64_t(node)*p.s.words+(lane>>5)]>>(lane&31))&1u;next[bit>>5]=(next[bit>>5]&~(1u<<(bit&31)))|(v<<(bit&31));}p.atlas.swap(next);}
inline void tick(Program&p,std::vector<Word>& scratch){const PointerAtlas a{p.atlas.data()};const PointerPast past{p.state.data()};for(Word w=0;w<p.s.words;++w)evaluate_lane_word(a,past,scratch.data(),p.s,w);if(p.s.patches)commit(p,scratch);p.state.swap(scratch);}
inline void save_result(const std::string&path,const Program&p,Word ticks){if(path.empty())return;std::ofstream o(path,std::ios::binary);if(!o)throw std::runtime_error("cannot write result");o.write("A0FO5\0\0\0",8);for(Word x:std::array<Word,6>{ticks,p.s.nodes,p.s.words,p.s.atlas_words,Word(p.state.size()),0})write32(o,x);for(const auto*v:{&p.atlas,&p.state})for(Word x:*v)write32(o,x);if(!o)throw std::runtime_error("write failed");}
inline std::uint64_t digest(const Program&p){std::uint64_t h=1469598103934665603ull;for(const auto*v:{&p.atlas,&p.state})for(Word x:*v){h^=x;h*=1099511628211ull;}return h;}
inline std::uint64_t popcount(const std::vector<Word>&v){std::uint64_t n=0;for(Word w:v)while(w){w&=w-1;++n;}return n;}
inline std::uint64_t number(const std::string&s){std::uint64_t v=0;auto r=std::from_chars(s.data(),s.data()+s.size(),v);if(r.ec!=std::errc()||r.ptr!=s.data()+s.size())throw std::runtime_error("bad integer: "+s);return v;}
struct Options{std::string program,out,json,defs="texture";Word ticks=1,device=0,vram=0,persist_kib=0;bool help=false,info=false,verify=false;};
inline Options parse(int argc,char**argv){Options o;for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--help"){o.help=true;continue;}if(a=="--info"){o.info=true;continue;}if(a=="--verify"){o.verify=true;continue;}if(i+1>=argc)throw std::runtime_error("missing value");std::string v=argv[++i];if(a=="--program")o.program=v;else if(a=="--out")o.out=v;else if(a=="--json")o.json=v;else if(a=="--defs")o.defs=v;else {auto n=number(v);if(n>0xffffffffu)throw std::runtime_error("integer exceeds uint32");if(a=="--ticks")o.ticks=Word(n);else if(a=="--device")o.device=Word(n);else if(a=="--vram-percent")o.vram=Word(n);else if(a=="--persist-kib")o.persist_kib=Word(n);else throw std::runtime_error("unknown option: "+a);}}
    if(o.vram>100||o.device>2147483647u)throw std::runtime_error("invalid device or VRAM percentage");if(o.defs!="texture"&&o.defs!="global"&&o.defs!="shared")throw std::runtime_error("defs must be texture/global/shared");return o;}
inline void usage(){std::cout<<"Axis0 FieldMachine v5 | Tom Klootwijk NL200678942 10-07-1990\n--program FILE --ticks N --out FILE --json FILE\nCUDA: --defs texture|global|shared --persist-kib N --vram-percent P --device N --info --verify\n";}
inline std::uint64_t elapsed(std::chrono::steady_clock::time_point a,std::chrono::steady_clock::time_point b){return std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count());}
inline void emit(const std::string&s,const std::string&path){std::cout<<s<<'\n';if(!path.empty()){std::ofstream f(path);if(!f)throw std::runtime_error("cannot write report");f<<s<<'\n';}}
inline std::string escape(const std::string&s){std::string o;for(unsigned char c:s){if(c=='"'||c=='\\')o+='\\';if(c>=32)o+=char(c);}return o;}
}
