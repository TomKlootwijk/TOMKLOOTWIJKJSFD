#pragma once
// Concept attribution: Tom Klootwijk / NL200678942 / 10-07-1990.
// Fixed interpreter substrate; Boolean meanings and expression wiring are fields.
#include <cstdint>
#if defined(__CUDACC__)
#define A0_HD __host__ __device__ __forceinline__
#else
#define A0_HD inline
#endif
namespace axis0 {
using Word=std::uint32_t;
constexpr Word QUOTE=0x80000000u;
struct Shape {Word nodes,words,atlas_words,desc_base,patch_base,patches;};
A0_HD Word select_bits(Word lo,Word hi,Word test) {return (lo&~test)|(hi&test);}
A0_HD Word broadcast(Word b) {return Word{0}-(b&1u);}
// A 3-variable truth field is evaluated with seven Shannon selections.
// Every lane is independent; each Word evaluates 32 assignments simultaneously.
A0_HD Word evaluate_truth(Word tt,Word a,Word b,Word c) {
    Word q0=select_bits(broadcast(tt),broadcast(tt>>1),a);
    Word q1=select_bits(broadcast(tt>>2),broadcast(tt>>3),a);
    Word q2=select_bits(broadcast(tt>>4),broadcast(tt>>5),a);
    Word q3=select_bits(broadcast(tt>>6),broadcast(tt>>7),a);
    return select_bits(select_bits(q0,q1,b),select_bits(q2,q3,b),c);
}
struct PointerAtlas {const Word* data;A0_HD Word get(Word i)const{return data[i];}};
struct PointerPast {const Word* data;A0_HD Word get(std::uint64_t i)const{return data[i];}};
template<class Atlas>A0_HD Word sample_field(const Atlas& a,Word bit){return (a.get(bit>>5)>>(bit&31u))&1u;}
template<class Atlas,class Past>A0_HD Word port(const Atlas& atlas,const Past& previous,
    const Word* now,Word ref,Word delayed,Word words,Word lane_word) {
    if(ref&QUOTE)return broadcast(sample_field(atlas,ref&~QUOTE));
    const std::uint64_t at=std::uint64_t(ref)*words+lane_word;
    return delayed?previous.get(at):now[at];
}
template<class Atlas,class Past>A0_HD void evaluate_lane_word(const Atlas& atlas,const Past& previous,
    Word* current,const Shape& s,Word w) {
    for(Word n=0;n<s.nodes;++n) {
        const Word base=s.desc_base+8*n;
        const Word truth_address=atlas.get(base);
        const Word tt=(atlas.get(truth_address>>5)>>(truth_address&31u))&255u;
        const Word delays=atlas.get(base+4);
        const Word a=port(atlas,previous,current,atlas.get(base+1),delays&1u,s.words,w);
        const Word b=port(atlas,previous,current,atlas.get(base+2),delays&2u,s.words,w);
        const Word c=port(atlas,previous,current,atlas.get(base+3),delays&4u,s.words,w);
        current[std::uint64_t(n)*s.words+w]=evaluate_truth(tt,a,b,c);
    }
}
}
