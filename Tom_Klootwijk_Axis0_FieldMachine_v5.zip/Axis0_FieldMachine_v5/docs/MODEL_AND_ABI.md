# Model, semantic floor and binary ABI — version 5.0

## Scope and provenance

The source instruction is that Axis 0 contains all admitted operators and that
operators themselves are SDFs. The Boolean double UU source identifies two
one-bit fields. The current request additionally names A=T and asks for a
calculating GPU, with expressions and self-references stored as fields.

This version assigns a finite Boolean field-language realization of that goal.
It does not silently equate the source's opaque names (AT, B floppy P, Kindred,
circled T, kinematic vectors) with new opcodes. It does not claim to implement
all possible source intentions. It does implement every operator admitted by
its language as a truth field and every expression as a field descriptor.

## 1. A constructive SDF interpretation for every finite object

Let b=(b0,...,b[L-1]) be the bits of a known-length object. Its coding solid is
Omega_b=[-5,-3] union the closed intervals [4j-1,4j+1] for bj=1. The sentinel is
always included. The intervals are disjoint and separated by gaps. Thus
D_b(q)=min_c(|q-c|-1), c=-4 or 4j for active bits, is the exact signed distance to
the union boundary. Inside one interval, its own boundary is nearest; outside
all intervals, the minimum positive term is the nearest boundary distance.
At q=4j, the sign is negative exactly when bj=1. The decoded bit is therefore
1[D_b(4j)<0]. The compiler/runtime lower this test directly to a packed-bit read.

This construction applies to truth tables, expression records, publication
records, quoted code and live state. It is an exact generative geometry, not
continuous distance samples stored in one bit. The coding line is separate from
the storage chart R/Theta/A. Neither the distance evaluator nor a geometry
renderer runs in the production calculation loop.

Finite field words still require a length, address and interpretation. Code and
data share a representation, but an arbitrary distance at one point is not an
entire instruction. The fixed interpreter supplies reading/selection semantics.
The seven-selection law itself is supplied as an executable field program.

## 2. Boolean computation

An operator field has eight coefficients t0..t7. Its output on inputs a,b,c is
f(a,b,c)=t[a+2b+4c]. Truth-bit order is least-significant first. There are 2^8=256
such functions. Fewer-input functions ignore unused inputs, so two-input OR is
0xee and three-input OR is 0xfe. ID is 0xaa; NOT is 0x55; MUX is 0xca with c as
selector, a as its zero branch and b as its one branch.

For words of 32 independent inputs, select(lo,hi,s)=(lo & ~s) | (hi & s).
Seven such selections evaluate the entire truth field, bitwise. The coefficient
0/1 is broadcast by unsigned 0-bit. No floating-point calculation is needed.
The scalar oracle instead indexes the truth table one lane at a time; the
implementations agree on all tested fields and programs.

OR alone is not functionally complete. An OR-only network without complemented
inputs is monotone, while NOT is not. This implementation retains AND/complement
in its fixed selection floor; operators as fields can express all ternary
Boolean functions and finite circuits assembled from them. It does not identify
bitwise OR of numerical float encodings with SDF union.

## 3. Time, delayed recursion and current-tick order

Each node has three ports. A port is either a reference to a node field or a
quoted bit from the definition atlas. For node references, a delay flag chooses
previous state versus current state. Current-state references must point to
an earlier node in the evaluation order. Delayed references may point anywhere,
including the same node; their initial values come from the seed snapshot.

An expression with op T or A and one input is compiled to ID with that input's
delay flag set. The equation is T(x)[n+1]=x[n]. A and T are aliases in this
selected profile. Current dependencies are evaluated in node order inside one
GPU thread per group of 32 cases. Thread-owned current values are read normally
from global memory; there is no cross-thread same-tick dependence.

T is therefore an explicit one-snapshot delay/state-transition interpretation,
not physical elapsed time. The alpha storage component A uses two alternating
pages; longer history is not automatically retained. The source phrase SDF=T is
preserved as a naming/interpretation goal, but does not by itself derive this
particular clock law. The implementation law is introduced here and documented.

## 4. Reflection and mutation of definitions

Quoted references read a selected bit of an operator or expression descriptor.
The self-definition example includes a quote of its own expression. It also
quotes all coefficients of LIVE, complements them and publishes the result into
LIVE's next snapshot. Quotation uses the same field sampling identity as data.

Publications are declared quadruples (target_bit, source_node, source_lane,0).
They apply only after all expression nodes have been evaluated. Each target bit
has one publisher, and targets must lie in the custom-definition region. The
GPU copies the old atlas and applies disjoint atomic bit changes to the copy.
The next tick reads that new atlas. The compiled machine rule and validated
expression references are not rewritten.

All cases share one definition atlas. A source lane is specified per publication,
so it acts as the control case for that coefficient; this is not independent
per-case self-modification. Delayed self-reference and definition rewriting are
implemented; automatic self-replication and universal self-hosting are not
established by those mechanisms.

## 5. Log-polar storage and memory

State field F[node,case,A] stores one bit. Case indices form the angular
coordinate, and node indices form radial rows. The exact log label is
rho_q16=floor(node*65536/bins_per_phi); supported subdivisions are powers of two
up to 65536. The angle label is (case+1/2)/case_count turns. A is the temporal
snapshot. A flat address is node*words_per_row + floor(case/32), plus a bit index.
Expression records and truth fields are packed separately into the same-format
program atlas; descriptors carry the row labels.

This is a native address convention. Calculation follows explicit graph
references, not geometric distance queries. No Cartesian coordinates, polar
trigonometry or radial distances are needed during evaluation. Optional radius
metadata is generated using integer fixed-point phi and square roots, and is
not consumed by the Boolean evaluator. The chart has no r=0 apex, and this
version does not supply the original non-orientable geometric carrier.

Data-plane cost: two state snapshots use nodes*cases/4 bytes, compared with
8*nodes*cases bytes for two FP32 Boolean snapshots. The ratio is exactly 32.
This excludes program atlases, driver storage, allocation overhead, publication
copies and output. One truth table takes 8 bits; one descriptor takes 256 bits.

Texture mode uses integer-element linear texture objects. Shared mode stages the
atlas once per block per launch and uses ordinary memory for the previous state.
Global mode uses ordinary loads for both. An optional L2 window prioritizes the
actual used definition region; it is not a texture-cache allocation or a pin.
If no persistence capacity is reported, applied size is zero. The report exposes
actual applied set-aside/window sizes. No junk padding is added to fill caches.

## 6. File format

All integers are little-endian uint32. A0FM5 starts with the 8 bytes
`A0FM5\0\0\0`, followed by 12 uint32 header words:

```
version=5, nodes, words_per_node, atlas_words, seed_words,
descriptor_base_word, publication_base_word, publication_count,
output_count, 0, 0, 0
```

Then come atlas_words values, seed_words values, and output_count node IDs.
Seed words are node-major. words_per_node is a positive power of two. The compiler
uses lanes=32*words_per_node. See field_program.py for the exact validator.

Atlas header (16 words): magic, version, node_count, lanes, descriptor_base,
publication_base, publication_count, bins_per_phi, catalogue_base, 256,
custom_definition_begin_bit, custom_definition_end_bit, four reserved zeros.
The catalogue is all 256 truth fields in increasing truth-byte order. Custom
truth fields each occupy the low eight bits of one allocated word.

Each descriptor is eight words:

```
truth_field_bit_address, port_a, port_b, port_c, delayed_port_mask,
radial_log_phi_q16, node_id, seed_tag
```

A port with high bit set quotes atlas bit (port & 0x7fffffff); otherwise it is a
node ID. Delay flags 1,2,4 apply to the corresponding node ports. seed_tag=0
means use/repeat explicit seed words; seed_tag=k+1 means initialize from bit k
of the global case index. This permits new variable assignments in larger GPU
batches. Cases repeat beyond the available distinct declared input combinations.

The output file starts with `A0FO5\0\0\0` and six uint32 header words:
`tick_count,nodes,words_per_node,atlas_words,state_words,0`, followed by the final
atlas and node-major state. GPU large-batch runs serialize only the base case
set; they report the full executed lane count separately.

## 7. Correctness boundaries

This is a finite field-program calculator. Arbitrary floating-point numerical
analysis, physical spacetime, metric SDF reconstruction, automatic graph growth,
Klein-bottle calculus and a TSP optimizer are not silently assigned meanings.
Bit-sliced arithmetic and Boolean constraints are real demonstrated uses; they
do not imply removal of the combinatorial work needed by general optimization.
Every alleged performance benefit is either exact memory arithmetic, an actual
recorded CPU measurement, or an explicitly unmeasured GPU hypothesis.
