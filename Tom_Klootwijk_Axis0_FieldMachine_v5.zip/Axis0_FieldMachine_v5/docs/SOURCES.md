# Source record and verification basis

## Supplied documents and request

[S1] Original six-page `men T room ... signed distance field.pdf`: the author's
Axis 0=ALL admitted operators definition appears on page 5. The original operator
vocabulary is on pages 1–3. The accompanying exported explanations contain
additional universality/physical claims that are not treated as executable laws.

[S2] Eight-page hyphenated-name continuation: code/data/operator closure diagram,
pages 4–5; seed and readout, pages 6–7; SDF=T, Present and Now, pages 7–8. The
current A=T profile is an explicit implementation choice, not a physical law
proved by that document.

[S3] Six-page ladybug/Zaandam routing document: the author's packed-one-bit idea,
page 1; instruction to define Boolean double UU as field and operator, page 2;
the exported two-plane field/operator diagram and formula, page 3. Later claims
of instantaneous TSP, hardware security and physical simulation are not imported
as results of this implementation.

[R] Current request: a computational GPU, all operators/expressions represented
as fields, raw binary execution, log-polar texture LUTs, A=T, self-reference,
cache/VRAM use, ZIP and ELI5 PDF. Attribution retained: Tom Klootwijk,
NL200678942, 10-07-1990.

## External sources consulted 18 September 2026

[E1] User-linked educational source, *Applications of Boolean Algebra: Claude
Shannon and Circuit Design*. The accessible text covers the circuit/Boolean
correspondence and expansion from truth coefficients, especially its Sections
2–3. I did not locate the exact sentence beginning 'By keeping the system entirely
in raw binary logic' in that accessible text. It supports Boolean circuit
synthesis, not a benchmark of this GPU, a texture-cache theorem, or the elimination
of metric information. The quotation is treated as the user's implementation goal.
https://www.academia.edu/45308198/Applications_of_Boolean_Algebra_Claude_Shannon_and_Circuit_Design

[E2] Claude E. Shannon, *A Symbolic Analysis of Relay and Switching Circuits*,
Electrical Engineering 57(12), 713–723, December 1938.
DOI: 10.1109/EE.1938.6431064. The publisher/search record supports the foundational
relation to circuit analysis and synthesis. The selection construction in this
package is stated and checked independently rather than attributed verbatim.
https://doi.org/10.1109/EE.1938.6431064

[E3] NVIDIA CUDA C++ Programming Guide 12.8.1, Section 7.8.1.1, tex1Dfetch:
integer coordinates and unfiltered linear-resource access. Section 3.2.14.4:
texture reads of memory written in the same kernel call are not coherent.
https://docs.nvidia.com/cuda/archive/12.8.1/cuda-c-programming-guide/index.html

[E4] NVIDIA CUDA Programming Guide, L2 Cache Control: persisting accesses are
preferentially retained, not permanently pinned; the runtime exposes limits and
access-policy windows. Filling the set-aside beyond capacity can cause evictions.
https://docs.nvidia.com/cuda/cuda-programming-guide/04-special-topics/l2-cache-control.html

[E5] NVIDIA CUDA 12.8 Features: introduced compiler support for SM_120.
https://docs.nvidia.com/cuda/archive/12.8.0/cuda-features-archive/index.html

[E6] NVIDIA official RTX 50-series laptop specifications: RTX 5070 Ti Laptop,
12GB GDDR7, Blackwell. Actual free memory and resource limits are queried by the
executable rather than assumed from advertised capacity.
https://www.nvidia.com/en-gb/geforce/laptops/50-series/

## Implementation constructions, not source quotations

The disjoint-interval exact SDF codec; eight-coefficient field catalogue;
256-bit expression grammar; A/T previous-snapshot rule; quotation and publication
semantics; fused CUDA evaluation; cache modes; examples; tests; and benchmark
methodology were introduced for this release. They give a particular finite
realization, not a retrospective proof of every statement in the source PDFs.
