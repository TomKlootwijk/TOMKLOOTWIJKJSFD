# Executed metrics: FieldMachine v5.0

## Evidence boundary

CPU execution: compiled with GCC 14.2.0 and tested on Intel Xeon Platinum 8370C,
Linux x86-64. CUDA compiler and NVIDIA GPU: absent. CUDA compilation, GPU execution,
texture hit rate and laptop speed are therefore NOT_RUN, not inferred from CPU
results. The source hash manifest predates these comparisons and remained unchanged.

## Correctness

* 256 ternary Boolean operator fields; 2,048 exhaustive input combinations.
* 32,768 additional random packed-word cases for the seven-selection primitive.
* 120 complete executable program runs checked against an independent scalar
  evaluator, including 100 generated expression graphs with delayed references,
  quotation and optional definition publication. 276,224 state bits compared.
* All 256 4-bit addition input pairs produce the exact five-bit sum.
* The A/T counter agrees with (initial+n) mod 16 at n=0,1,2,7,15,16,17,63.
* The self-definition changes LIVE between 0xaa and 0x55 and changes its output
  accordingly, across eight inspected ticks.
* The interpreter expressed in seven MUX fields agrees on all 2,048 combinations
  of its argument/coefficient bits.
* The exact SDF word codec passes 12,800 integer distance queries on 256 words.
* The Boolean constraint example accepts exactly assignments 5,6,7,10 of 0..15.
* AddressSanitizer/UndefinedBehaviorSanitizer core and integration runs pass.

These are different, sometimes overlapping test suites, not a summed count of
independent applications. Raw results are in `verification/`.

## Same-program Boolean representation comparison

32,768 independent cases; six counter expressions; 64 ticks; seven repetitions.
All three final states match, including intermediate expression fields.
Initial conversion, final conversion, file loading and hashing are outside the
timer. Buffers are preallocated. Evaluation is single-threaded.

| Representation | Median | Ratio to packed |
|---|---:|---:|
| Packed one-bit fields | 3.726 ms | 1.00 |
| uint8 Boolean fields | 67.345 ms | 18.07x as long |
| FP32 Boolean fields | 84.890 ms | 22.78x as long |

The packed interpreter evaluates 32 cases per word with seven selections. The
scalar reference interpreters index the truth table case by case. No special
SIMD intrinsics or tuned external libraries are used. FP32 is only a storage
baseline for Boolean 0/1 values, not a metric-SDF computation. These ratios are
not predictions for the RTX laptop and not universal gains over existing software.

## Counterexample to 'fields must be fastest'

A specialized native byte counter returns the same four counter output bits.
It omits expression reflection, variable definitions and intermediate fields.
Measured over seven repetitions on the same CPU:

* Packed field interpreter: 3.782 ms.
* Specialized native modulo-16 counter: 0.503 ms.
* The specialized routine is 7.52x faster.

This is an output-equivalent, purpose-built algorithm, not another implementation
of the full field-machine interface. Its advantage shows the price of a general,
inspectable interpreter. Packing saves storage but does not guarantee the fastest
algorithm for a fixed problem. Usual compiler vectorization is permitted.

## Exact storage arithmetic

For one expression over 1,048,576 cases:

* One bit plane: 128 KiB.
* Two temporal snapshots: 256 KiB.
* Two FP32 Boolean snapshots: 8 MiB.

For 64 expressions over those cases, the two data snapshots total 16 MiB,
compared with 512 MiB for FP32 Boolean storage. Additional program-atlas copies,
publication metadata, input staging, resource overhead and result storage are
not included. The ternary catalogue payload is 256 bytes; each descriptor is
32 bytes. A program bit is not a lossless replacement for an arbitrary float
magnitude; the SDF codec encodes a specifically defined geometric object.

## Hardware measurements still to make

Run `tools/gpu_check.py` first. `tools/gpu_metrics.py` compares global, texture,
shared-atlas and optional L2-persistence configurations, reports executed cases
and time, and validates the base cases against CPU execution. Requested memory
fractions may produce different case counts if free memory changes; the report
normalizes by actual node/case/tick work instead of hiding that difference.

Cache residency/hit rate requires hardware profiling; it is not derived from
allocation size. The program reports the queried sizes and applied policy window,
not a fabricated number of resident definitions. A full VRAM allocation is a
capacity test; unused duplicate definitions are not treated as useful compute.

## Reproduce CPU comparisons

```
python tools/field_program.py examples/clocked_counter.json counter_big.a0f --lanes 32768
g++ -std=c++17 -O3 -DNDEBUG -Iinclude benchmarks/cpu_comparison.cpp -o cpu_comparison
./cpu_comparison counter_big.a0f comparison.json
g++ -std=c++17 -O3 -DNDEBUG -Iinclude benchmarks/native_counter.cpp -o native_counter
./native_counter counter_big.a0f native.json
```

Times will vary. The source package includes raw samples, environment and freeze
hashes; reproductions should report their own machine and toolchain.
