#!/usr/bin/env python3
"""Exact finite verification; no GPU/biological performance is inferred."""
from __future__ import annotations
from fractions import Fraction
from itertools import product, permutations
from math import comb
from pathlib import Path
import argparse,json,random,sys,time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from palace import *

def verify() -> dict:
    suites={};start=time.perf_counter_ns()
    # Exhaust all allowed/seed statuses; independent BFS and decoded paths.
    g=Grid(3,3);wave_cases=0;path_checks=0
    for states in product(range(3),repeat=g.n):
        allowed=sum((s>0)<<i for i,s in enumerate(states));seed=sum((s==2)<<i for i,s in enumerate(states))
        result=wave(g,allowed,seed);reference=queue_arrivals(g,allowed,seed)
        assert result['arrivals']==reference
        accum=0
        for layer in result['layers']:
            assert not accum&layer;assert not layer&~allowed;accum|=layer
        assert accum==result['visited']
        assert len(result['steps'])<=allowed.bit_count()
        for target,dist in enumerate(reference):
            path=decode_path(g,result['layers'],target)
            if dist is None:assert path==()
            else:
                assert len(path)==dist+1 and path[-1]==target and (seed>>path[0])&1
                assert all(v in g.adjacent(u) for u,v in zip(path,path[1:]))
                assert all((allowed>>v)&1 for v in path)
            path_checks+=1
        wave_cases+=1
    suites['exhaustive_3x3_wave_configurations']=wave_cases
    suites['decoded_target_results']=path_checks
    # Independent exact distances to every incident midpoint in the geometric graph.
    distance_fields=distance_vertices=0
    for grid in (Grid(3,3),Grid(4,3)):
        for f in range(1<<grid.n):
            interface=[(u,v) for u,v in grid.edges() if ((f>>u)^(f>>v))&1]
            actual=grid.signed_distance2(f)
            assert grid.boundary(f)==grid.boundary(grid.full^f)
            reverse=grid.signed_distance2(grid.full^f)
            for x,d in enumerate(actual):
                if not interface:assert d is None and reverse[x] is None
                else:
                    def manhattan(y):return abs(x%grid.width-y%grid.width)+abs(x//grid.width-y//grid.width)
                    expected=min(2*min(manhattan(u),manhattan(v))+1 for u,v in interface)
                    assert d==(-expected if (f>>x)&1 else expected)
                    assert reverse[x]==-d
                distance_vertices+=1
            for u,v in grid.edges():
                if actual[u] is not None:assert abs(actual[u]-actual[v])<=2
            distance_fields+=1
    suites['graph_sdf_fields']=distance_fields;suites['graph_sdf_vertex_checks']=distance_vertices
    # Raw proposal partition, before its admissible fresh projection.
    g=Grid(6,1);proposal_cases=0
    for states in product(range(3),repeat=g.n):
        m=sum((s>0)<<i for i,s in enumerate(states));f=sum((s==2)<<i for i,s in enumerate(states))
        for raw in range(1<<g.n):
            r=step(g,m,f,0,proposal=raw)
            assert r.proposal==(r.fresh|r.repeated|r.outside)
            assert not(r.fresh&r.repeated or r.fresh&r.outside or r.repeated&r.outside)
            assert r.fresh==(raw&m&~f)
            assert r.next_field==(f|r.fresh)==(f^r.fresh)
            assert (f^raw)!=r.next_field if r.repeated or r.outside else (f^raw)==r.next_field
            proposal_cases+=1
    suites['raw_proposal_partition_cases']=proposal_cases
    # T and A are one definition. Its next-state graph is actually interpreted.
    import copy
    assert TIME_NAMES['A'] is TIME_NAMES['T']
    paused=copy.deepcopy(TIME_DEFINITION);paused['next']={'F':'F','O':'O'}
    temporal_cases=0;g4=Grid(4,1)
    for statuses in product(range(3),repeat=4):
        allowed=sum((s>0)<<i for i,s in enumerate(statuses));f=sum((s==2)<<i for i,s in enumerate(statuses))
        for o in range(16):
            p=g4.neighbours(o);fresh=p&allowed&~f
            assert time_apply(g4,allowed,f,o)==(f|fresh,fresh)
            assert time_apply(g4,allowed,f,o,definition=paused)==(f,o)
            temporal_cases+=2
    assert encode_definition(TIME_DEFINITION)!=encode_definition(paused)
    suites['data_defined_time_evaluations']=temporal_cases

    # All Boolean operator tables at all eight input rows.
    gate_checks=0
    for table in range(256):
        a,b,c=0xAA,0xCC,0xF0
        assert truth_field(table,a,b,c,255)==table
        gate_checks+=8
    suites['truth_table_row_checks']=gate_checks
    # All canonical payload masks on an eight-node line and sample normal heights.
    sdf_checks=0
    for bits in range(256):
        payload=bytes([bits])
        for i in range(8):
            for z in range(-10,11):
                d=definition_sdf(payload,i,z)
                nearest=min(4*abs(i-j)+abs(z-(2*((bits>>j)&1)-1)) for j in range(8))
                assert abs(d)==nearest
                assert definition_sdf(payload,i,0)<0 if (bits>>i)&1 else definition_sdf(payload,i,0)>0
                sdf_checks+=1
    suites['canonical_definition_sdf_samples']=sdf_checks
    # Dense and integer-spatial palace addresses.
    ranks=0
    for dims in product(range(1,6),repeat=3):
        seen=set()
        for abc in product(*(range(d) for d in dims)):
            q=rank_room(*abc,dims);assert unrank_room(q,dims)==abc;seen.add(q);ranks+=1
        assert seen==set(range(dims[0]*dims[1]*dims[2]))
    suites['mixed_radix_room_roundtrips']=ranks
    morton_cases=0
    for depth in range(6):
        codes=set()
        for xyz in product(range(1<<depth),repeat=3):
            code=morton3(*xyz,depth);assert unmorton3(code,depth)==xyz;codes.add(code);morton_cases+=1
        assert len(codes)==1<<(3*depth)
    suites['octree_address_roundtrips']=morton_cases
    # Exact quantized concentration comparisons, not simulated ecology.
    threshold_cases=0
    for counts in product(range(8),repeat=4):
        planes=count_planes(list(counts),3)
        for cutoff in range(9):
            expected=sum((x>=cutoff)<<i for i,x in enumerate(counts))
            assert threshold(planes,cutoff,15)==expected;threshold_cases+=1
    suites['quantized_threshold_cases']=threshold_cases
    compositions=0
    for q in range(1,9):
        rows=[(a,b,q-a-b) for a in range(q+1) for b in range(q-a+1)]
        assert len(rows)==comb(q+2,2)
        for row in rows:assert sum(Fraction(n,q) for n in row)==1;compositions+=1
    suites['exact_three_component_compositions']=compositions
    rng=random.Random(20260918);pack_cases=0
    for width in (1,7,32,64,255):
        for _ in range(100):
            planes=[rng.getrandbits(width) for _ in range(3)]
            assert unpack_channels(packed_channels(planes,width),width,3)==planes;pack_cases+=1
    suites['three_layer_pack_roundtrips']=pack_cases
    label_cases=0
    for fields in product(range(16),repeat=3):
        union,multiple=overlapping_labels(fields)
        expected=sum((sum((f>>i)&1 for f in fields)>=2)<<i for i in range(4))
        assert union==(fields[0]|fields[1]|fields[2]) and multiple==expected;label_cases+=1
    suites['three_label_collision_patterns']=label_cases
    # Every conservative one-species adjacent-transfer allocation on a 3-cell chain.
    transfer_cases=0
    for counts in product(range(4),repeat=3):
        for j01 in range(counts[0]+1):
            for j10 in range(counts[1]+1):
                for j12 in range(counts[1]-j10+1):
                    for j21 in range(counts[2]+1):
                        result=transport_counts([list(counts)],[(0,0,1,j01),(0,1,0,j10),(0,1,2,j12),(0,2,1,j21)])
                        assert min(result[0])>=0 and sum(result[0])==sum(counts)
                        assert result[0]==[counts[0]-j01+j10, counts[1]+j01-j10-j12+j21, counts[2]+j12-j21]
                        transfer_cases+=1
    suites['conservative_integer_transport_cases']=transfer_cases

    # Ledger order/idempotence; differing assertions are retained, not overwritten.
    a={'namespace':'demo','object':'mu0','predicate':'coating_supported','context':'v1','value':True,'sources':['author-A']}
    b={**a,'sources':['author-B']};c={**a,'value':False,'sources':['author-C']}
    merged=merge_assertions([a,b,c]);assert merged[0]['has_differing_assertions']
    ledger_cases=0
    for order in permutations([a,b,c]):
        assert merge_assertions(order)==merged
        assert merge_assertions(order,order)==merged
        ledger_cases+=2
    suites['collaborative_ledger_checks']=ledger_cases
    evidence_checks=0
    for a,b,c in product((-1,0,1),repeat=3):
        assert kleene_and(a,b)==kleene_and(b,a)
        assert kleene_and(kleene_and(a,b),c)==kleene_and(a,kleene_and(b,c));evidence_checks+=1
    suites['partial_evidence_algebra_cases']=evidence_checks
    # Explicit counterexamples to claims in accompanying source explanation.
    counterexamples={
      'eikonal_does_not_check_addresses':{'field':'f(x)=x; |f_prime|=1','addresses':[0,0],'distinct_room_ids':[0,1]},
      'directional_zero_not_equilibrium':{'gradient':[1,0],'direction':[0,1],'dot':0,'gradient_is_zero':False},
      'max_is_not_exact_intersection_distance':{'point':[1,1],'max_of_halfspace_sdfs':1,'distance_squared_to_negative_quadrant':2},
      'union_internal_zero_seam':{'fields':['x','-x'],'occupied_union':'whole real line','min_field':'-|x|','internal_zero':0},
      'plus_delta_is_inward':{'field':'|x|-1','delta':'1/4','f_plus_delta_roots':['-3/4','3/4'],'outward_roots':['-5/4','5/4']}}
    assert Fraction(1)-Fraction(1,4)==Fraction(3,4)
    assert 1**2 < 1**2+1**2
    assert sum(a*b for a,b in zip((1,0),(0,1)))==0
    report=demo()
    assert report['candidate_rooms']==45 and report['passing_rooms']==19
    assert report['selected_room']['id']==2 and report['selected_room']['shared_zero_edge_count']==0
    assert report['selected_route']['hops']==10 and report['selected_route']['reached']==36
    assert report['raw_proposal_example']['repeated']==1 and report['raw_proposal_example']['outside']==8
    assert report['owner_meeting_example']['shared']==2
    return {'status':'PASS','version':'6.0','suites':suites,
            'counterexamples':counterexamples,'demo':{'rooms':45,'passing':19,'selected_id':2,'route_hops':10,'zero_confluence_edges':0},
            'arithmetic':'integer and Fraction; no floating point in profile calculations',
            'elapsed_host_ns':time.perf_counter_ns()-start,'gpu_execution':'NOT_PERFORMED',
            'biological_measurement':'NO_BIOLOGICAL_DATA_SUPPLIED','verification_scope':'finite reference semantics plus proofs in PDF'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--json',type=Path,default=ROOT/'verification/test_report.json');a=p.parse_args()
    report=verify();text=json.dumps(report,indent=2);a.json.write_text(text+'\n');print(text)
if __name__=='__main__':main()
