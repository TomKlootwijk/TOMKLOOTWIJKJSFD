# Axis 0 / Zero-Boundary Combinatorial Memory Palace — v6.0

**Tom Klootwijk · NL200678942 · date supplied 10-07-1990**

This package accompanies the 24-page enhanced formalization. It extends the
source's *zero-boundary biomimicry memory palace* with explicit microstructure,
chemical-geometry and bacterial-composition types, field-defined operators,
versioned room addressing, proposal witnesses and a provenance-preserving ledger.

## Controlling source interpretation

In the new source, the author explicitly redirects the opening chemical/software
interpretation toward biomimicry mechanisms at the SDF zero boundary (page 3).
The author specifies microstructures, chemical geometries and bacterial
compositions on page 6, and places the discussion back into the Axis 0 corpus on
page 8. These instructions are the basis of this version.

The source's room/corridor table, three-layer pipeline and final Profile R formula
are preserved in the PDF. New definitions, proofs and checked consequences are
identified separately from the exported explanatory claims. The current source
has nine content-bearing pages followed by a blank tenth page.

## Contents

- `Tom_Klootwijk_Axis0_Memory_Palace_v6.pdf`: the consolidated formalization.
- `src/palace.py`: exact integer/bit-field reference and synthetic 45-room example.
- `tests/verify.py`: reproducible independent-reference and exhaustive tests.
- `examples/demo_report.json`: all rooms, witness masks, operator definitions,
  exact A/T time definition, selected route and source-preserving ledger digest.
- `examples/time_definition.json`: readable temporal expression graph.
- `examples/operator_definitions.json`: truth fields with self-references.
- `docs/source_claims.json`: claim-by-claim source-to-formalization mapping.
- `docs/formalization.tex`: editable mathematical document source.
- `verification/`: executed test results, provenance and release checks.
- `MANIFEST.sha256`: checksums of the files in this package.

## Run

Python 3.10+; standard library only. No package installation is needed.
From the extracted package directory:

```bash
python src/palace.py --output examples/reproduced_demo.json
python tests/verify.py --json verification/reproduced_tests.json
```

Do not use Python's `-O` flag for the test command: it removes assertions.
Elapsed execution time varies across hosts; the exact mathematical results do
not depend on the timing field.

## Results actually executed

The synthetic catalogue contains 3 microstructure chambers, 3 annotation
footprints and 5 two-component composition records: 45 candidate rooms.
Exactly **19** satisfy the three declared example predicates. Those predicates
are explicit geometric/integer bookkeeping choices, not measured biological
compatibility or a model of particular organisms/chemicals.

The selected room `(mu0, chi0, beta2)` has room index **2**, composition `(2,2)/4`,
and **no shared triple-zero edge**, while passing its declared predicates. A
route from `(1,1)` to `(6,6)` uses **10 graph edges**. The wave reaches **36** cells
and its **11th update** produces an empty frontier.

The proposal witness example uses four cells:

```
allowed = 0111
field   = 0001
raw     = 1011
fresh   = 0010
repeat  = 0001
outside = 1000
```

All three parts of the raw proposal are retained. Two independently fresh waves
on the three-cell path can still meet at the middle cell; the multiple-label
observer reports that meeting separately from either wave's local invariants.

## The new executable pieces

### Rules and temporal expressions are data

`DEFAULT_RULES` stores eight-bit truth fields. The generic `truth_field` reader
uses row index `a + 2*b + 4*c`. `TIME_DEFINITION` stores its proposal and next-state
expression trees; `time_apply` actually reads those trees.

`TIME_NAMES['A'] is TIME_NAMES['T']` is true: both names identify the same object.
Its `self` field is `T`. The default next-state graph implements:

```
P  = NEIGHBOURS(O)
O' = FRESH(P, M, F) = P & M & ~F
F' = OR(F, O')
```

The tests replace the temporal next-state fields with the identity references
`{'F': 'F', 'O': 'O'}` and verify that both state roles pause, without changing
the expression evaluator. This is a finite stored-definition mechanism, not a
claim that all of the source's unassigned operators have implementations.

### Every finite record has an explicit canonical SDF

`encode_definition` gives a deterministic serialized bitword. For its bit `b[i]`,
`definition_sdf(payload, i, z)` evaluates `z + 1 - 2*b[i]`. Under the metric
`4*graph_distance(i,j) + abs(z-w)` this is an exact distance to the selected
normal-fiber boundary. The PDF proves that identity. It is an information carrier,
not an inferred Euclidean distance to an arbitrary physical shape.

### Spatial zero fields retain the source's midpoint notation

`Grid.boundary(F)` stores one bit per undirected graph edge whose endpoint phases
differ. `boundary_coordinates2` returns exact doubled midpoint coordinates.
`Grid.signed_distance2(F)` reconstructs twice the exact signed distance to that
interface on the geometric graph, using odd integers. Components with no boundary
return `None`; the implementation does not assign a fictitious finite distance.

### Integer composition fields

`count_planes` stores counts in explicit precision bitplanes; `threshold` evaluates
unsigned threshold queries without floating point. `transport_counts` implements
an optional conservative inventory transfer. Its coefficients are provided data;
no physical bacterial growth rate is inferred. The PDF states its nonnegativity
and conservation proof.

### Collaborative ledger

`merge_assertions` groups exact canonical assertion keys, unions matching source
sets, and retains different values as separate variants. A checksum is used for
file reproducibility; it is not used as a mathematical proof of unique room ids.
Mixed-radix room addressing and octree bit interleaving have separate inverse
proofs and tests.

## Verification boundaries stated as result types

The package's executed results concern the finite mathematical/reference profile.
The source supplies no empirical measurements of the named biological mechanisms;
those records remain source descriptions or explicit synthetic examples. There
is no new GPU benchmark or CUDA build in this revision. GPU field storage remains
a compatible implementation direction, while this package verifies the new
memory-palace formalization directly.

No organism engineering, chemical synthesis, biological interaction rate,
software-vulnerability exploit or automatic claim of scientific validity is
encoded by a zero-set query. In this corpus, “0 day” is the author's boundary-state
concept, and a “bug finder” returns typed model witnesses.

## Source and equation conventions

Bit index `i=y*width+x`; origin at the upper-left corner; zero-filled rectangle
edges. `F=1` is the declared phase/visited value. For an interior-negative SDF,
that phase gives negative signed distance. Cavity versus solid is a separate
role flag, never inferred from an untyped mask. Catalogue indices include their
version. All example density values have declared numerators/denominators.

The source's offset, gradient, CSG and no-overlap claims are examined through
explicit counterexamples in the PDF, with their valid mathematical meanings
retained. General geometric regularity does not replace address, ownership or
provenance rules.
