"""Axis 0 / Zero-Boundary Memory Palace, reference profile v6.0.

Concept attribution: Tom Klootwijk / NL200678942 / date supplied 10-07-1990.
Finite integer/bit-field construction introduced in the v6 specification.
This module records witnesses. It does not automatically suppress a supplied event.
The named mu/chi/beta demo records are synthetic bookkeeping examples.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from fractions import Fraction
import argparse
import hashlib
import json
from pathlib import Path
from typing import Iterable, Mapping

@dataclass(frozen=True)
class Grid:
    width: int
    height: int

    def __post_init__(self) -> None:
        if self.width < 1 or self.height < 1:
            raise ValueError('positive dimensions required')

    @property
    def n(self) -> int:
        return self.width * self.height

    @property
    def full(self) -> int:
        return (1 << self.n) - 1

    def bit(self, x: int, y: int) -> int:
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError('coordinate outside declared chart')
        return 1 << (y * self.width + x)

    def checked(self, field: int) -> int:
        if type(field) is not int or field < 0 or field & ~self.full:
            raise ValueError('field is not an in-domain unsigned bitplane')
        return field

    def adjacent(self, i: int) -> tuple[int, ...]:
        if not 0 <= i < self.n:
            raise ValueError('cell outside domain')
        x, y = i % self.width, i // self.width
        return tuple(yy * self.width + xx for xx, yy in
                     ((x-1,y),(x+1,y),(x,y-1),(x,y+1))
                     if 0 <= xx < self.width and 0 <= yy < self.height)

    def edges(self) -> tuple[tuple[int,int], ...]:
        return tuple((i,j) for i in range(self.n) for j in self.adjacent(i) if i < j)

    def shift(self, f: int, direction: str) -> int:
        self.checked(f)
        left = sum(1 << (y*self.width) for y in range(self.height))
        right = left << (self.width-1)
        if direction == 'E': return ((f & (self.full ^ right)) << 1) & self.full
        if direction == 'W': return (f & (self.full ^ left)) >> 1
        if direction == 'N': return f >> self.width
        if direction == 'S': return (f << self.width) & self.full
        raise ValueError('direction must be E/W/N/S')

    def neighbours(self, f: int) -> int:
        return self.shift(f,'E') | self.shift(f,'W') | self.shift(f,'N') | self.shift(f,'S')

    def boundary(self, f: int) -> int:
        """Edge-indexed midpoints. No imaginary exterior cells are added."""
        self.checked(f)
        return sum((((f>>i)^(f>>j)) & 1) << e for e,(i,j) in enumerate(self.edges()))

    def boundary_coordinates2(self, f: int) -> list[tuple[int,int]]:
        return [(i%self.width+j%self.width, i//self.width+j//self.width)
                for e,(i,j) in enumerate(self.edges()) if (self.boundary(f)>>e)&1]

    def signed_distance2(self, f: int) -> tuple[int|None, ...]:
        """Twice exact graph-geometric signed distance to the midpoint interface.

        A component with no boundary returns None. This is not a Euclidean SDF.
        One unit graph edge is two units in the returned integer coordinates.
        """
        boundary = self.boundary(f)
        distances: list[int|None] = [None] * self.n
        frontier = 0
        for e,(i,j) in enumerate(self.edges()):
            if (boundary>>e)&1:
                frontier |= (1<<i) | (1<<j)
        visited=0;d=1
        while frontier:
            for i in range(self.n):
                if (frontier>>i)&1: distances[i] = -d if (f>>i)&1 else d
            visited |= frontier
            frontier = self.neighbours(frontier) & (self.full ^ visited)
            d += 2
        return tuple(distances)

# Rules are data fields: all rows use a+2*b+4*c. The same interpreter reads any table.
DEFAULT_RULES = {'OR':0xEE, 'AND':0x88, 'XOR':0x66, 'AND_NOT':0x22,
                 'FRESH':0x08, 'NOT':0x55, 'ALL_THREE':0x80}

def truth_field(table: int, a: int, b: int, c: int, full: int) -> int:
    if not 0 <= table < 256:
        raise ValueError('three-input truth field needs eight bits')
    if any(x < 0 or x & ~full for x in (a,b,c)):
        raise ValueError('input outside field domain')
    out=0
    for row in range(8):
        if (table>>row)&1:
            out |= (a if row&1 else full^a) & (b if row&2 else full^b) & (c if row&4 else full^c)
    return out


TIME_DEFINITION = {'id':'T', 'aliases':['A'], 'self':'T', 'kind':'snapshot_transition',
                   'proposal':['NEIGHBOURS','O'],
                   'next':{'F':['OR','F',['FRESH','P','M','F']], 'O':['FRESH','P','M','F']},
                   'observations':['zero_edge_interface','proposal_witnesses','room_predicates']}
TIME_NAMES = {'T':TIME_DEFINITION, 'A':TIME_DEFINITION}


def evaluate_expression(grid: Grid, expression: str|list, environment: Mapping[str,int],
                        rules: Mapping[str,int] = DEFAULT_RULES) -> int:
    """Read a data-defined finite expression; NEIGHBOURS is the spatial primitive."""
    if isinstance(expression,str):return grid.checked(environment[expression])
    if not isinstance(expression,list) or not expression:raise ValueError('malformed field expression')
    operator,*operands=expression
    values=[evaluate_expression(grid,x,environment,rules) for x in operands]
    if operator=='NEIGHBOURS':
        if len(values)!=1:raise ValueError('NEIGHBOURS arity is one')
        return grid.neighbours(values[0])
    if len(values)>3:raise ValueError('truth field arity is at most three')
    return truth_field(rules[operator],*(values+[0]*(3-len(values))),grid.full)


def time_apply(grid: Grid, allowed: int, f: int, o: int, raw: int|None = None,
               definition: Mapping = TIME_DEFINITION, rules: Mapping[str,int] = DEFAULT_RULES) -> tuple[int,int]:
    environment={'M':allowed,'F':f,'O':o}
    environment['P'] = (evaluate_expression(grid,definition['proposal'],environment,rules)
                        if raw is None else grid.checked(raw))
    return tuple(evaluate_expression(grid,definition['next'][target],environment,rules) for target in ('F','O'))


@dataclass(frozen=True)
class StepRecord:
    proposal: int
    fresh: int
    repeated: int
    outside: int
    next_field: int
    next_operator: int


def step(grid: Grid, allowed: int, f: int, o: int,
         rules: Mapping[str,int] = DEFAULT_RULES, proposal: int|None = None) -> StepRecord:
    for x in (allowed,f,o): grid.checked(x)
    if f & ~allowed:
        raise ValueError('Profile R_bio state requires F subset of M')
    raw = grid.neighbours(o) if proposal is None else grid.checked(proposal)
    fresh=truth_field(rules['FRESH'],raw,allowed,f,grid.full)
    repeated=truth_field(rules['AND'],raw,f,0,grid.full)
    outside=truth_field(rules['AND_NOT'],raw,allowed,0,grid.full)
    updated,next_operator=time_apply(grid,allowed,f,o,raw,rules=rules)
    return StepRecord(raw,fresh,repeated,outside,updated,next_operator)


def wave(grid: Grid, allowed: int, seed: int) -> dict:
    if grid.checked(seed) & ~grid.checked(allowed):
        raise ValueError('seed must be in allowed field')
    f=o=seed;layers=[o] if o else [];steps=[]
    while o:
        record=step(grid,allowed,f,o);steps.append(record)
        f,o=record.next_field,record.next_operator
        if o: layers.append(o)
    arrivals=[None]*grid.n
    for n,layer in enumerate(layers):
        for i in range(grid.n):
            if (layer>>i)&1:arrivals[i]=n
    return {'visited':f,'layers':layers,'steps':steps,'arrivals':arrivals}


def queue_arrivals(grid: Grid, allowed: int, seed: int) -> list[int|None]:
    """Independent coordinate/queue reference, not the packed stencil."""
    distance=[None]*grid.n;q=deque()
    for i in range(grid.n):
        if (seed>>i)&1:distance[i]=0;q.append(i)
    while q:
        i=q.popleft()
        for j in grid.adjacent(i):
            if ((allowed>>j)&1) and distance[j] is None:
                distance[j]=distance[i]+1;q.append(j)
    return distance


def decode_path(grid: Grid, layers: list[int], target: int) -> tuple[int,...]:
    grid.adjacent(target)
    n=next((n for n,f in enumerate(layers) if (f>>target)&1),None)
    if n is None:return ()
    path=[target]
    for k in range(n,0,-1):
        predecessors=[i for i in grid.adjacent(path[-1]) if (layers[k-1]>>i)&1]
        if not predecessors:raise ValueError('invalid first-arrival history')
        path.append(min(predecessors))
    return tuple(reversed(path))


def overlapping_labels(fields: Iterable[int]) -> tuple[int,int]:
    seen=multiple=0
    for f in fields:
        multiple |= seen & f
        seen |= f
    return seen,multiple


def rank_room(a: int,c: int,b: int,dimensions: tuple[int,int,int]) -> int:
    nm,nc,nb=dimensions
    if min(dimensions)<1 or not (0<=a<nm and 0<=c<nc and 0<=b<nb):
        raise ValueError('room tuple outside versioned catalogue')
    return (a*nc+c)*nb+b


def unrank_room(q: int,dimensions: tuple[int,int,int]) -> tuple[int,int,int]:
    nm,nc,nb=dimensions
    if min(dimensions)<1 or not 0<=q<nm*nc*nb:raise ValueError('room id outside catalogue')
    ac,b=divmod(q,nb);a,c=divmod(ac,nc);return a,c,b


def morton3(x: int,y: int,z: int,depth: int) -> int:
    if depth<0 or any(not 0<=a<(1<<depth) for a in (x,y,z)):
        raise ValueError('octree coordinate outside declared depth')
    return sum(((x>>k)&1)<<(3*k) | ((y>>k)&1)<<(3*k+1) | ((z>>k)&1)<<(3*k+2) for k in range(depth))


def unmorton3(code: int,depth: int) -> tuple[int,int,int]:
    if depth<0 or not 0<=code<(1<<(3*depth)):raise ValueError('Morton code out of range')
    return tuple(sum(((code>>(3*k+axis))&1)<<k for k in range(depth)) for axis in range(3))


def packed_channels(channels: list[int],width: int) -> int:
    if width<1 or any(a<0 or a.bit_length()>width for a in channels):
        raise ValueError('channel width exceeded')
    return sum(a<<(k*width) for k,a in enumerate(channels))


def unpack_channels(value: int,width: int,count: int) -> list[int]:
    if value<0 or width<1 or count<0 or value.bit_length()>width*count:
        raise ValueError('channel atlas length mismatch')
    return [(value>>(k*width))&((1<<width)-1) for k in range(count)]


def count_planes(counts: list[int],bits: int) -> list[int]:
    if bits<1 or any(not 0<=n<(1<<bits) for n in counts):raise ValueError('count outside precision')
    return [sum(((n>>b)&1)<<i for i,n in enumerate(counts)) for b in range(bits)]


def threshold(planes: list[int],cutoff: int,full: int) -> int:
    """Exact unsigned >= comparison of bit-sliced counts with an integer cutoff."""
    if cutoff<0:return full
    if cutoff >= (1<<len(planes)):return 0
    equal=full;greater=0
    for b in range(len(planes)-1,-1,-1):
        p=planes[b]
        if p<0 or p&~full:raise ValueError('plane outside domain')
        if (cutoff>>b)&1:equal &= p
        else:
            greater |= equal & p
            equal &= full ^ p
    return greater | equal


def encode_definition(value: dict) -> bytes:
    """Deterministic serialization; a SHA checksum is metadata, not a proof of identity."""
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('ascii')


def definition_sdf(payload: bytes,index: int,z: int) -> int:
    if not 0<=index<len(payload)*8:raise ValueError('bit outside definition')
    bit=(payload[index>>3]>>(index&7))&1
    return z+1-2*bit


def kleene_and(a: int,b: int) -> int:
    # -1 unknown, 0 contradicted, 1 affirmed, for a declared predicate only.
    if a not in (-1,0,1) or b not in (-1,0,1):raise ValueError('invalid evidence state')
    if 0 in (a,b):return 0
    return 1 if a==b==1 else -1




def transport_counts(counts: list[list[int]], transfers: list[tuple[int,int,int,int]]) -> list[list[int]]:
    """Conservative integer transfers (species, source cell, target cell, amount).

    This is a chosen digital bookkeeping law. It assigns no biological rates.
    """
    if not counts or not counts[0] or any(len(row)!=len(counts[0]) for row in counts):
        raise ValueError('rectangular nonempty count table required')
    if any(n<0 for row in counts for n in row):raise ValueError('counts must be nonnegative')
    species,cells=len(counts),len(counts[0]);outgoing=[[0]*cells for _ in range(species)]
    result=[row.copy() for row in counts]
    for k,u,v,amount in transfers:
        if not (0<=k<species and 0<=u<cells and 0<=v<cells and amount>=0):raise ValueError('invalid transfer')
        outgoing[k][u]+=amount;result[k][u]-=amount;result[k][v]+=amount
    if any(outgoing[k][u]>counts[k][u] for k in range(species) for u in range(cells)):
        raise ValueError('transfer exceeds the previous snapshot inventory')
    return result


def merge_assertions(*batches: Iterable[dict]) -> list[dict]:
    """Union a collaborative ledger without overwriting differing assertions.

    Mathematical identity is the exact canonical key/value encoding. Hashes are
    optional checksums; no hash collision assumption is used for merge semantics.
    """
    groups: dict[bytes,dict] = {}
    for batch in batches:
        for item in batch:
            key = encode_definition({name:item[name] for name in ('namespace','object','predicate','context')})
            value = encode_definition({'value':item['value']})
            group = groups.setdefault(key, {'key':json.loads(key), 'variants':{}})
            variant = group['variants'].setdefault(value, {'value':item['value'], 'sources':set()})
            variant['sources'].update(item['sources'])
    output=[]
    for key in sorted(groups):
        group=groups[key]
        variants=[{'value':group['variants'][value]['value'], 'sources':sorted(group['variants'][value]['sources'])}
                  for value in sorted(group['variants'])]
        output.append({**group['key'], 'variants':variants, 'has_differing_assertions':len(variants)>1})
    return output


def rectangle(g: Grid,x0: int,y0: int,x1: int,y1: int) -> int:
    return sum(g.bit(x,y) for y in range(y0,y1+1) for x in range(x0,x1+1))


def demo() -> dict:
    g=Grid(8,8)
    mu=[rectangle(g,1,1,6,6),rectangle(g,2,1,5,6),
        rectangle(g,1,2,6,5)]
    chi=[rectangle(g,2,2,3,3),rectangle(g,1,1,4,4),rectangle(g,4,4,6,6)]
    beta=[(a,4-a) for a in range(5)]
    capacity=[4,2,3];annotation_min=[0,1,2]
    dimensions=(len(mu),len(chi),len(beta));rooms=[]
    for a in range(3):
        for c in range(3):
            for b in range(5):
                q=rank_room(a,c,b,dimensions);n1,n2=beta[b]
                witnesses={'annotation_outside_chamber':chi[c]&~mu[a],
                           'count_above_declared_limit':int(n1>capacity[a]),
                           'count_below_declared_annotation_minimum':int(n1<annotation_min[c])}
                passed=not any(witnesses.values())
                support=mu[a]&chi[c]
                records={'mu_boundary':g.boundary(mu[a]),'chi_boundary':g.boundary(chi[c]),
                         'beta_support_boundary':g.boundary(support)}
                shared=records['mu_boundary']&records['chi_boundary']&records['beta_support_boundary']
                rooms.append({'id':q,'tuple':[a,c,b],'mu_id':f'mu{a}','chi_id':f'chi{c}',
                              'beta_id':f'beta{b}','composition_numerators':[n1,n2],'denominator':4,
                              'passes_declared_predicates':passed,'witnesses':witnesses,
                              'shared_zero_edge_count':shared.bit_count()})
    constraint_planes=[sum((r['witnesses'][name]==0)<<r['id'] for r in rooms)
                       for name in ('annotation_outside_chamber','count_above_declared_limit','count_below_declared_annotation_minimum')]
    admitted=truth_field(DEFAULT_RULES['ALL_THREE'],*constraint_planes,(1<<len(rooms))-1)
    assert all(((admitted>>r['id'])&1)==r['passes_declared_predicates'] for r in rooms)
    selected=rooms[rank_room(0,0,2,dimensions)]
    # Exact, reproducible chamber route in the selected room; other layers remain metadata.
    route=wave(g,mu[0],g.bit(1,1));target=6+6*g.width;path=decode_path(g,route['layers'],target)
    rule_records=[{'id':name,'kind':'truth_field','table':table,'self':name} for name,table in DEFAULT_RULES.items()]
    time=TIME_DEFINITION
    # Deliberately unmasked raw proposal proves logger sees old/out-of-domain bits.
    small=Grid(4,1);bad=step(small,0b0111,0b0001,0b0001,proposal=0b1011)
    # Two independent fresh frontiers can meet despite each satisfying its own invariant.
    line=Grid(3,1);left=step(line,line.full,1,1);right=step(line,line.full,4,4)
    _,meet=overlapping_labels([left.fresh,right.fresh])
    ledger=[{'room':x['id'],'status':'model_predicates_passed' if x['passes_declared_predicates'] else 'model_predicate_witness',
             'record':encode_definition(x).decode('ascii')} for x in rooms]
    return {'version':'6.0','attribution':{'name':'Tom Klootwijk','identifier':'NL200678942','date_supplied':'10-07-1990'},
            'evidence':'synthetic integer bookkeeping profile, not measured biology',
            'catalogue_dimensions':list(dimensions),'candidate_rooms':len(rooms),
            'passing_rooms':admitted.bit_count(),'predicate_bitplanes':constraint_planes,'passing_bitplane':admitted,
            'catalogues':{'mu_cell_masks':mu,'chi_annotation_masks':chi,'beta_compositions':beta,
                         'synthetic_mu_limits':capacity,'synthetic_chi_minima':annotation_min},
            'rooms':rooms,'selected_room':selected,'selected_route':{'hops':len(path)-1,'cells':list(path),
                'coordinates':[[i%g.width,i//g.width] for i in path],'reached':route['visited'].bit_count(),
                'updates_to_empty':len(route['steps']),'layers_sizes':[x.bit_count() for x in route['layers']]},
            'raw_proposal_example':bad.__dict__,'owner_meeting_example':{'left_fresh':left.fresh,'right_fresh':right.fresh,'shared':meet},
            'operator_definitions':rule_records,'time_definition':time,
            'ledger_entry_count':len(ledger),'ledger_sha256':hashlib.sha256(encode_definition({'entries':ledger})).hexdigest()}


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path('demo_report.json'))
    args=parser.parse_args();report=demo()
    args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(args.output),'candidate_rooms':report['candidate_rooms'],
                      'passing_rooms':report['passing_rooms'],'selected_room':report['selected_room'],
                      'selected_route':report['selected_route'],'proposal':report['raw_proposal_example']},indent=2))

if __name__=='__main__':main()
