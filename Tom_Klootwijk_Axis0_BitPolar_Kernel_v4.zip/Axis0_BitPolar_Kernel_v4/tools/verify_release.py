#!/usr/bin/env python3
"""Verify frozen production files and all packaged SHA256SUMS entries."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    a = p.parse_args()
    root = a.root.resolve()
    freeze = json.loads((root / "verification/kernel_freeze.json").read_text(encoding="utf-8"))
    count = 0
    for relative, expected in freeze["sha256"].items():
        actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(f"Frozen implementation mismatch: {relative}")
        count += 1
    manifest = root / "SHA256SUMS.txt"
    total = 0
    if manifest.exists():
        for line in manifest.read_text(encoding="utf-8").splitlines():
            expected, relative = line.split("  ", 1)
            path = (root / relative).resolve()
            if root not in path.parents or not path.is_file():
                raise SystemExit(f"Bad manifest path: {relative}")
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise SystemExit(f"Release hash mismatch: {relative}")
            total += 1
    print(f"PASS: {count} frozen files unchanged; {total} packaged files match SHA-256 manifest.")


if __name__ == "__main__":
    main()
