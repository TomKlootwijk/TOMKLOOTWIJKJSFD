#!/usr/bin/env python3
"""Integer-only physical interpretation LUT for the native log-polar chart.

CUDA uses integer native indices and a 16-byte adjacency/log-coordinate row LUT.
This file is optional geometry/readout metadata, NOT a dense per-cell SDF.
phi and its roots are fixed-point approximations computed using integer isqrt.
Angles use integer CORDIC; no Python binary-float values are constructed.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
from math import isqrt
from pathlib import Path
import json

def atan_recip_q(q: int, precision: int = 120) -> int:
    if q < 2:
        raise ValueError("series requires denominator>=2")
    scale, power, k, total = 1 << precision, q, 0, 0
    while True:
        term = scale // ((2 * k + 1) * power)
        if not term:
            return total
        total = total + term if not k & 1 else total - term
        power *= q * q
        k += 1

def cordic_tables() -> tuple[list[int], int]:
    pi_q = 16 * atan_recip_q(5) - 4 * atan_recip_q(239)
    angles = [1 << 29] + [(atan_recip_q(1 << k) << 32) // (2 * pi_q) for k in range(1, 31)]
    gain_squared = Fraction(1)
    for k in range(31):
        gain_squared *= Fraction(1 << (2 * k), (1 << (2 * k)) + 1)
    gain = isqrt((gain_squared.numerator << 60) // gain_squared.denominator)
    return angles, gain

def sincos_turn_q30(turn: int, tables: tuple[list[int], int]) -> tuple[int, int]:
    angles, gain = tables
    z = ((turn + (1 << 31)) & 0xFFFFFFFF) - (1 << 31)
    sign = 1
    if z > (1 << 30):
        z -= 1 << 31
        sign = -1
    elif z < -(1 << 30):
        z += 1 << 31
        sign = -1
    x, y = gain, 0
    for k, a in enumerate(angles):
        direction = 1 if z >= 0 else -1
        x, y = x - direction * (y >> k), y + direction * (x >> k)
        z -= direction * a
    return sign * x, sign * y

def radial_bins(rings: int, bins: int) -> tuple[list[dict[str, int]], int]:
    if bins < 1 or bins & (bins - 1) or bins > 65536:
        raise ValueError("bins must be a power of two <=65536")
    scale = 1 << 48
    multiplier = (scale + isqrt(5 << 96)) // 2
    for _ in range(bins.bit_length() - 1):
        multiplier = isqrt(multiplier << 48)
    m, exponent = scale, 0
    out = []
    for rho in range(rings):
        out.append({"rho": rho, "log_phi_q16": (rho << 16) // bins,
                    "radius_mantissa_q31": m >> 17, "radius_exponent2": exponent})
        m = (m * multiplier) >> 48
        while m >= 2 * scale:
            m >>= 1
            exponent += 1
    return out, multiplier

def generate(theta: int, rings: int, bins: int) -> dict:
    if theta < 32 or theta & (theta - 1) or rings < 1 or rings & (rings - 1):
        raise ValueError("theta>=32 and rings must be powers of two")
    radial, multiplier = radial_bins(rings, bins)
    tables = cordic_tables()
    angular = [sincos_turn_q30(((2 * i + 1) << 31) // theta, tables) for i in range(theta)]
    return {"version": "4.0", "arithmetic": "integer_only_fixed_point",
            "theta": theta, "rings": rings, "bins_per_phi": bins,
            "radial_definition": "r[rho] approximately phi**(rho/bins), r0=1; r = mantissa_q31 * 2**(exponent2-31)",
            "angular_definition": "center angle in turns = (i+1/2)/theta; (cos,sin) in Q30",
            "root_multiplier_q48": multiplier, "radial": radial, "angular_cos_sin_q30": angular,
            "cuda_usage": "native bitplanes plus 16-byte row lookup; this file describes geometry for decoding, not metric signed distances"}

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("output", type=Path)
    p.add_argument("--theta", type=int, default=64)
    p.add_argument("--rings", type=int, default=16)
    p.add_argument("--bins-per-phi", type=int, default=64)
    a = p.parse_args()
    a.output.write_text(json.dumps(generate(a.theta, a.rings, a.bins_per_phi), indent=2) + "\n", encoding="utf-8")
    print(f"Wrote integer geometry LUT: {a.output}")

if __name__ == "__main__":
    main()
