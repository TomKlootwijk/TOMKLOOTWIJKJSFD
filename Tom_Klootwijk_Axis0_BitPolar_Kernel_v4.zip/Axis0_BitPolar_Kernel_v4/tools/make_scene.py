#!/usr/bin/env python3
"""Generate packed native chart examples or pair two masks for OR-union."""
from __future__ import annotations
import argparse
from pathlib import Path
from formats import U32, TOPOLOGY, blank, put, read_scene, write_scene

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("output", type=Path)
    p.add_argument("--example", choices=("polar-route", "rect-route", "union", "dense"), default="polar-route")
    p.add_argument("--theta", type=int, default=64)
    p.add_argument("--rings", type=int, default=16)
    p.add_argument("--topology", choices=TOPOLOGY, default="polar")
    p.add_argument("--bins-per-phi", type=int, default=64)
    p.add_argument("--left", type=Path)
    p.add_argument("--right", type=Path)
    a = p.parse_args()
    if a.left or a.right:
        if not (a.left and a.right):
            p.error("--left and --right must be supplied together")
        s, right = read_scene(a.left), read_scene(a.right)
        if (s.theta, s.rings, s.topology, s.bins) != (right.theta, right.rings, right.topology, right.bins):
            p.error("Masks must use the same layout")
        s.operator = right.field
        s.allowed = [U32] * s.words
    elif a.example == "rect-route":
        s = blank(32, 8, 0, a.bins_per_phi)
        s.allowed = [0] * s.words
        rows = ("S...#...", ".##.#.#.", "...#....", ".#...##.", "...#....", "...#...T")
        for y, row in enumerate(rows):
            for x, c in enumerate(row):
                if c != "#":
                    put(s.allowed, y * s.theta + x)
                if c == "S":
                    put(s.field, y * s.theta + x)
        s.operator = s.field.copy()
    else:
        s = blank(a.theta, a.rings, TOPOLOGY[a.topology], a.bins_per_phi)
        if a.example == "polar-route":
            if s.rings < 4:
                p.error("polar-route needs rings>=4")
            start, width = 3 * s.theta // 4, max(1, s.theta // 32)
            for x in range(s.theta):
                if not start <= x < start + width:
                    put(s.allowed, (s.rings // 2) * s.theta + x, 0)
            put(s.field, (s.rings // 8) * s.theta + s.theta // 16)
            s.operator = s.field.copy()
        elif a.example == "union":
            for y in range(s.rings):
                for x in range(s.theta):
                    i = y * s.theta + x
                    if s.rings // 4 <= y < 3 * s.rings // 4:
                        put(s.field, i)
                    if s.theta // 8 <= x < s.theta // 2:
                        put(s.operator, i)
        else:
            def mix(x: int) -> int:
                x = ((x ^ (x >> 16)) * 0x7FEB352D) & U32
                x = ((x ^ (x >> 15)) * 0x846CA68B) & U32
                return x ^ (x >> 16)
            s.field = [mix(i ^ 0x13579BD) for i in range(s.words)]
            s.operator = [mix(i ^ 0xA5A5A5A5) for i in range(s.words)]
    write_scene(a.output, s)
    print(f"Wrote {a.output}: {s.theta} x {s.rings}, {s.words} uint32 words/plane")

if __name__ == "__main__":
    main()
