"""AXIS0U4 scene and AXIS0H4 history formats. Integer-only native bitplanes."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import struct
U32 = 0xFFFFFFFF
TOPOLOGY = {"rect": 0, "polar": 1, "klein": 2}

@dataclass
class Scene:
    theta: int
    rings: int
    topology: int
    bins: int
    allowed: list[int]
    field: list[int]
    operator: list[int]

    @property
    def words(self) -> int:
        return self.theta * self.rings // 32

    @property
    def cells(self) -> int:
        return self.theta * self.rings

    def validate(self) -> None:
        if any(x < 1 or x & (x - 1) for x in (self.theta, self.rings, self.bins)):
            raise ValueError("Dimensions and bins-per-phi must be powers of two")
        if self.theta < 32 or self.words > (1 << 27) or self.bins > 65536:
            raise ValueError("Layout exceeds format limits")
        if ((self.rings - 1) << 16) // self.bins > U32:
            raise ValueError("Radial log-phi coordinate exceeds Q16 uint32")
        if self.topology not in (0, 1, 2):
            raise ValueError("Unknown topology")
        for plane in (self.allowed, self.field, self.operator):
            if len(plane) != self.words or any(not 0 <= w <= U32 for w in plane):
                raise ValueError("Invalid uint32 bitplane")

    def neighbours(self, i: int) -> list[int]:
        if not 0 <= i < self.cells:
            raise ValueError("Cell outside chart")
        x, y = i % self.theta, i // self.theta
        out = []
        if x:
            out.append(i - 1)
        elif self.topology:
            out.append(y * self.theta + self.theta - 1)
        if x + 1 < self.theta:
            out.append(i + 1)
        elif self.topology:
            out.append(y * self.theta)
        if y:
            out.append(i - self.theta)
        elif self.topology == 2:
            out.append((self.rings - 1) * self.theta + self.theta - 1 - x)
        if y + 1 < self.rings:
            out.append(i + self.theta)
        elif self.topology == 2:
            out.append(self.theta - 1 - x)
        return out

def bit(plane: list[int], i: int) -> int:
    return (plane[i >> 5] >> (i & 31)) & 1

def put(plane: list[int], i: int, value: int = 1) -> None:
    if value:
        plane[i >> 5] |= 1 << (i & 31)
    else:
        plane[i >> 5] &= U32 ^ (1 << (i & 31))

def blank(theta: int, rings: int, topo: int, bins: int = 64) -> Scene:
    words = theta * rings // 32
    s = Scene(theta, rings, topo, bins, [U32] * words, [0] * words, [0] * words)
    s.validate()
    return s

def write_scene(path: Path, s: Scene) -> None:
    s.validate()
    with path.open("wb") as f:
        f.write(b"AXIS0U4\0")
        f.write(struct.pack("<8I", 1, s.theta, s.rings, s.topology, s.bins, s.words, 3, 0))
        for plane in (s.allowed, s.field, s.operator):
            f.write(struct.pack(f"<{s.words}I", *plane))

def read_scene(path: Path) -> Scene:
    raw = path.read_bytes()
    if len(raw) < 40 or raw[:8] != b"AXIS0U4\0":
        raise ValueError("Bad AXIS0U4 magic")
    ver, t, r, topo, bins, words, planes, reserved = struct.unpack_from("<8I", raw, 8)
    if ver != 1 or planes != 3 or reserved or len(raw) != 40 + 12 * words:
        raise ValueError("Unsupported or inconsistent scene header")
    blocks = [list(struct.unpack_from(f"<{words}I", raw, 40 + k * 4 * words)) for k in range(3)]
    s = Scene(t, r, topo, bins, *blocks)
    s.validate()
    return s

def read_history(path: Path) -> tuple[Scene, list[list[int]]]:
    raw = path.read_bytes()
    if len(raw) < 40 or raw[:8] != b"AXIS0H4\0":
        raise ValueError("Bad AXIS0H4 magic")
    ver, t, r, topo, bins, words, res, res2 = struct.unpack_from("<8I", raw, 8)
    if ver != 1 or res or res2 or not words or (len(raw) - 40) % (4 * words):
        raise ValueError("Inconsistent history header")
    s = Scene(t, r, topo, bins, [0] * words, [0] * words, [0] * words)
    s.validate()
    frames = [list(struct.unpack_from(f"<{words}I", raw, i)) for i in range(40, len(raw), 4 * words)]
    if not frames:
        raise ValueError("No initial history frame")
    return s, frames
