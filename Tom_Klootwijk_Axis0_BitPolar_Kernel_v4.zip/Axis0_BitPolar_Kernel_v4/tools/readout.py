#!/usr/bin/env python3
"""Decode a shortest graph-hop route from retained wavefront history."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from formats import read_history, read_scene, bit

def decode(history: Path, x: int, y: int, initial: Path | None = None) -> dict:
    s, frames = read_history(history)
    if not (0 <= x < s.theta and 0 <= y < s.rings):
        raise ValueError("Target outside chart")
    target = y * s.theta + x
    n = next((k for k, f in enumerate(frames) if bit(f, target)), None)
    route = []
    if n is not None:
        i = target
        route = [i]
        for k in range(n, 0, -1):
            previous = [j for j in s.neighbours(i) if bit(frames[k - 1], j)]
            if not previous:
                raise ValueError("History is not a first-arrival wave for this topology")
            i = min(previous)
            route.append(i)
        route.reverse()
    if initial:
        source = read_scene(initial)
        if (source.theta, source.rings, source.topology) != (s.theta, s.rings, s.topology):
            raise ValueError("Source/history topology mismatch")
        if route and (not bit(source.field, route[0]) or any(not bit(source.allowed, i) for i in route)):
            raise ValueError("Route violates seed or allowed mask")
    return {"target": [x, y], "reached_in_recorded_history": n is not None,
            "shortest_graph_hops": n, "recorded_frames": len(frames),
            "coordinates_theta_rho": [[i % s.theta, i // s.theta] for i in route],
            "metric": "unit_cost_native_chart_edges_not_Euclidean_distance"}

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("history", type=Path)
    p.add_argument("--target", required=True, help="theta_index,rho_index")
    p.add_argument("--initial", type=Path)
    p.add_argument("--json", type=Path)
    a = p.parse_args()
    x, y = (int(v) for v in a.target.split(","))
    text = json.dumps(decode(a.history, x, y, a.initial), indent=2)
    print(text)
    if a.json:
        a.json.write_text(text + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
