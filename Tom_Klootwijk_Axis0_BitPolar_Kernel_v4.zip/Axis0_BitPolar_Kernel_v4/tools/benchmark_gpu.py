#!/usr/bin/env python3
"""Post-hoc texture/global comparison on the user's CUDA device.

Each recorded run is a fresh process. Its internal host timer excludes allocation
and initialization, and includes update dispatch plus final synchronization. This
is a whole-run comparison, not an isolated warm-cache instruction benchmark.
No performance record is supplied until this script actually runs on a GPU.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone


def execute(exe: Path, args: list[str]) -> dict:
    result = subprocess.run([str(exe.resolve()), *args], text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {' '.join(args)}\n{result.stderr}")
    return json.loads(result.stdout)


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--exe", required=True, type=Path)
    p.add_argument("--output", type=Path, default=Path("gpu_comparison.json"))
    p.add_argument("--theta", type=int, default=4096)
    p.add_argument("--rings", type=int, default=1024)
    p.add_argument("--charts", default="1,16,256", help="fixed equal workloads for both backends")
    p.add_argument("--vram-percent", type=int, help="add one chart count derived once from current free memory")
    p.add_argument("--steps", type=int, default=128)
    p.add_argument("--repeats", type=int, default=3)
    p.add_argument("--device", type=int, default=0)
    p.add_argument("--skip-self-test", action="store_true")
    a = p.parse_args()
    if a.repeats < 1 or a.repeats % 2 == 0 or a.steps < 1:
        p.error("positive steps and an odd positive repeat count are required")
    for d in (a.theta, a.rings):
        if d < 1 or d & (d - 1):
            p.error("dimensions must be powers of two")
    if a.theta < 32 or a.theta * a.rings // 32 > 1 << 27:
        p.error("chart outside supported range")
    device = ["--device", str(a.device)]
    info = execute(a.exe, [*device, "--info"])
    record: dict = {"version": "4.0", "utc": datetime.now(timezone.utc).isoformat(),
                    "status": "RUNNING", "gpu_execution": "EXECUTED",
                    "device_before": info, "mode": "exchange", "jitter": 1,
                    "timing_method": "fresh-process runs; program elapsed_host_ns; setup excluded; dispatch/sync included",
                    "not_measured": ["cache hit rate", "GPU-only event time", "power", "physical DRAM throughput"],
                    "cases": []}
    try:
        if not a.skip_self_test:
            record["self_test"] = execute(a.exe, [*device, "--self-test"])
        chart_counts = sorted(set(int(x) for x in a.charts.split(",") if x))
        if any(x < 1 for x in chart_counts):
            raise ValueError("chart counts must be positive")
        if a.vram_percent is not None:
            if not 1 <= a.vram_percent <= 100:
                raise ValueError("VRAM percentage must be 1..100")
            free = execute(a.exe, [*device, "--info"])["free_bytes"]
            plane = (a.theta * a.rings // 32) * 4
            overhead = a.rings * 16 + plane * 3 + 20
            count = ((free // 100) * a.vram_percent - overhead) // (plane * 5)
            if count < 1:
                raise ValueError("requested budget cannot fit one chart")
            chart_counts = sorted(set(chart_counts + [count]))
            record["vram_count_derivation"] = {"free_bytes": free, "percent": a.vram_percent,
                                                "charts": count, "same_count_for_both_backends": True}
        for charts in chart_counts:
            case: dict = {"charts": charts, "theta": a.theta, "rings": a.rings, "samples": {"texture": [], "global": []}}
            record["cases"].append(case)
            for repeat in range(a.repeats):
                # Alternate order; do not silently compare different chart counts or step counts.
                order = ("texture", "global") if repeat % 2 == 0 else ("global", "texture")
                for backend in order:
                    cmd = [*device, "--mode", "exchange", "--theta", str(a.theta), "--rings", str(a.rings),
                           "--topology", "polar", "--jitter", "1", "--charts", str(charts),
                           "--steps", str(a.steps), "--read", backend]
                    result = execute(a.exe, cmd)
                    case["samples"][backend].append(result)
            all_runs = case["samples"]["texture"] + case["samples"]["global"]
            for key in ("first_chart_digest_u64", "field_ones_all_charts", "operator_ones_all_charts", "charts", "executed_steps"):
                if len({run[key] for run in all_runs}) != 1:
                    raise RuntimeError(f"Backend/repeat result mismatch in {key}")
            medians = {b: sorted(run["elapsed_host_ns"] for run in case["samples"][b])[a.repeats // 2]
                       for b in ("texture", "global")}
            case["median_ns"] = medians
            case["global_over_texture_time_ratio"] = {"numerator": medians["global"], "denominator": medians["texture"]}
            case["logical_cell_updates_per_second"] = {
                b: charts * a.theta * a.rings * a.steps * 1_000_000_000 // medians[b] for b in medians}
            case["results_match"] = True
        record["status"] = "PASS"
    except Exception as exc:
        record["status"] = "FAILED_OR_INCOMPLETE"
        record["error"] = str(exc)
        raise
    finally:
        a.output.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        print(f"Recorded {a.output}: {record['status']}")


if __name__ == "__main__":
    main()
