#!/usr/bin/env python3
"""Reject floating-point operations in generated kernel PTX, not runtime libraries.
Usage after a real NVCC compile:
  nvcc -std=c++17 -ptx -arch=compute_120 -Iinclude cuda/kernels.cu -o build/kernels.ptx
  python tools/audit_ptx.py build/kernels.ptx --json verification/local_ptx_audit.json
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path

def audit(text: str) -> dict:
    source = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    lines = [line.split("//", 1)[0].strip() for line in source.splitlines()]
    fp = []
    instructions = 0
    for n, line in enumerate(lines, 1):
        line = re.sub(r"^@!?%\w+\s+", "", line)
        if not line or line.startswith((".", "{", "}")) or ";" not in line:
            continue
        opcode = line.split()[0]
        if re.match(r"[A-Za-z]", opcode):
            instructions += 1
            if re.search(r"\.(?:f16x2|f16|f32|f64|bf16x2|bf16|tf32|e4m3|e5m2)(?:\.|$)", opcode):
                fp.append({"line": n, "opcode": opcode})
    return {"status": "PASS" if instructions and not fp else "FAIL",
            "instruction_statements_checked": instructions, "floating_type_opcodes": fp,
            "scope": "generated PTX supplied by the caller; excludes driver/runtime internals"}

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("ptx", type=Path)
    p.add_argument("--json", type=Path)
    a = p.parse_args()
    result = audit(a.ptx.read_text(encoding="utf-8"))
    result["input"] = str(a.ptx)
    text = json.dumps(result, indent=2)
    print(text)
    if a.json:
        a.json.write_text(text + "\n", encoding="utf-8")
    if result["status"] != "PASS":
        raise SystemExit(1)

if __name__ == "__main__":
    main()
