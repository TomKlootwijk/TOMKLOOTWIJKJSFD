# Implemented mathematical contract

Concept attribution: **Tom Klootwijk / NL200678942 / 10-07-1990**.

## Source-derived basis and additions

The original six-page source defines Axis 0 as all admitted operators represented as fields. Its vocabulary includes lowercase phi, log-polar LUTs, one-bit jitter and Klein bifurcations. The newer ladybug/routing source explicitly requests Boolean double UU for the field and its expressed operator (page 2); its exported response gives paired bitplanes and a shift/XOR expression (pages 3–4).

The latest user request adds packed-bit CUDA execution, texture-cache reads, high-VRAM operation and OR. The four finite profiles in this package are **implementation constructions**. The sources do not supply an exact CUDA ABI, word layout, complete operator-update rule, weighted routing metric, device memory policy or cost model. The exported responses' claims about instantaneous TSP solutions, guaranteed universal computation, entropy forcing termination, and device security are not used as implementation facts.

The version-4 kernel is an operational subset, not an executable assignment for every retained source label. It does not assign meanings to AT, B floppy P, men T room, the source-specific plus or encircled T. Nor does it claim that the compiled instruction stream itself is stored as an SDF. Field and operator *states* share one representation and feed back through declared rules.

## State and address space

For one chart, X = {0,...,theta-1} × {0,...,rings-1}. A Boolean double-UU state is (F,O) in {0,1}^X × {0,1}^X. Allowed is an additional mask. Bits are packed by index `rho*theta+theta_index`, low bit first in an unsigned 32-bit word. There are exactly 32 addressed cells per word; no float represents a bit.

The dimensions are powers of two and theta>=32. Thus chart offsets, ring indices and columns use shifts and masks. There is no padding ambiguity. Multiple charts are independent; their word boundaries are explicit. The CPU atlas test uses heterogeneous data to check that a neighbor access cannot leak into another chart.

N_OR(V) is the OR of the four transported cardinal-neighbor masks. At angular word boundaries, one carry bit comes from the adjacent word; edge masks or periodic wrapping are applied before mixing. Radial lookups come from the compact LUT.

## Native log-polar interpretation

The physical interpretation is

```
log_phi(r[rho]/r0) = rho / bins_per_phi
angle turns(theta_index) = (theta_index + 1/2) / theta_bins
```

The engine operates on these discrete coordinates directly. Its row LUT contains exactly four uint32 components: previous ring word offset, next ring word offset, seam flags, and `log_phi_q16`. Each row is 16 bytes. The CUDA texture backend fetches this as uint4 and field words as unsigned int. The global backend reads the same data via pointers.

`tools/logpolar_lut.py` separately generates approximate physical radius/angle metadata using integers. It uses a Q48 approximation to phi and its power-of-two roots, normalized radius mantissas and exponents, and integer CORDIC. JSON geometry is a decoder/interpretation artifact: the executable builds its own small native row LUT from the scene header. It does not load that JSON as a dense distance table. Radius is not held in every Boolean cell.

Equal native hops are not equal Euclidean lengths: angular arc lengths vary with radius and log-radial intervals expand. The `wave` guarantee concerns the native unit-cost graph. Introducing physical edge weights requires a different cost-aware execution rule. A central r=0 apex is not represented by a finite logarithmic ring in this implementation.

## Topologies

`rect`: both angular and radial boundaries are open/zero filled. In this mode the same indices are rectangular coordinates; the log-polar metadata need not be physically interpreted.

`polar`: theta is periodic; radial edges are open. This is a sampled annular chart, not a disk with an implicit origin.

`klein`: theta is periodic; crossing either radial end maps angular cell i to theta-1-i. With theta samples at cell centers, this is angular reflection. A packed word's column is reversed and its bits are reversed. This defines discrete transport; a full continuous signed-distance metric and chart-dependent sign are not computed here. The fields are ordinary invariant masks, so no extra inside/outside sign-complement is silently applied at a seam. The seam bit is geometric metadata, distinct from optional update jitter.

## Profiles and proofs

### Wave

```
F[0] = O[0] = seed, with seed subset of Allowed
O[n+1] = Allowed & ~F[n] & N_OR(O[n])
F[n+1] = F[n] | O[n+1]
```

Complement is per unsigned word, and all word bits represent valid cells. Inductively O[n] contains exactly the vertices at graph distance n from the seed set: a newly admitted vertex has a neighbor at distance n-1 and was not admitted sooner; every shortest n-edge path supplies such a predecessor. F[n] is the union of layers 0 through n. OR preserves multiple possible arrivals instead of canceling even numbers of paths.

The new frontier is disjoint from F, so using OR for the final update gives the same state as XOR in that position. A nonempty frontier adds at least one previously unvisited vertex. Hence a finite graph exhausts after finitely many layers. `--until-empty` observes exactly this predicate; fixed `--steps` is a caller-chosen observation interval and may leave the solve unfinished. Jitter is not injected into this exact routing rule.

The runtime need not retain a numeric distance per cell. It also cannot return a full path from terminal F and empty O alone. Optional history stores every first-chart frontier; the readout script walks a predecessor in the preceding layer. That additional storage and transfer are explicit.

### Union

```
(F,O) -> (F | O, O)
```

At every cell, the result is true exactly when either operand is true. This supports Boolean mask union, including a fold over multiple input masks. A one-bit phase does not encode arbitrary metric distances. For example, exact one-dimensional distance fields x-1/4 and x-3/4 have identical signs at samples x=0 and x=1 but different magnitudes. Bitwise OR on a numeric fixed-point distance encoding is also not a minimum-distance operation.

### Exchange / inverse

Let G(O)=N_OR(O) XOR J, where J is a known mask for that step. Then

```
exchange(F,O) = (O, F XOR G(O))
inverse(F',O') = (O' XOR G(F'), F')
```

Substitution restores both original planes. G need not be invertible. The script retains the seed and step index, allowing inverse mode to use the same keys in reverse order. Jitter, when enabled, selects one flip bit per packed word by a fixed integer hash. This is a chosen deterministic profile, not a probabilistic or thermodynamic law from the source.

Feedback means the previous output becomes the next input, and the two roles exchange. It does not mean the compiled kernel rewrites its instructions, generates an unbounded program, or proves computational universality. Allocating replicated input charts is not autonomous self-reproduction.

## Time, distance and observability

The executable's n is an iteration counter. First-arrival n is graph-hop duration under an assigned unit-time edge convention. The earlier source's identity T=d would require a separately supplied geometric distance reading; the executable does not label the iteration number as a Euclidean signed distance. `--out` is a state snapshot and `--history` is discrete frontier history, not a continuous constant-T hypersurface renderer.

## Device synchronization and memory

Every launch reads an immutable current snapshot and writes different next buffers. Roles swap between launches in one stream. No state update relies on a write becoming visible through a texture in that same launch. NVIDIA's documented texture coherence rule motivates this layout [N3, Sources].

For N cells the resident dynamic/mask buffers require 5N bits: current F/O, next F/O and Allowed. Add 16*rings LUT bytes, reduction counters, texture/context/allocator overhead. Setup briefly holds three one-chart input templates too. Full retained frontier history for one chart requires (steps+1)*N bits plus its header, and runs with history include transfers/writes in their timer.

A uint32 thread processes 32 cells' Boolean positions at once. It still performs several loads, shifts, masks and stores. Neither one logical update nor one arbitrarily large bitset operation is asserted to be one hardware cycle.
