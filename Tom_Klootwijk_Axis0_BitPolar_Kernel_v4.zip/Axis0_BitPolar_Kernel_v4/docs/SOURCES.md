# Provenance and technical references

Prepared 18 September 2026. The concept attribution and identifiers are supplied by the user, not inferred from external records.

## User-supplied material

**S1.** Six-page original document beginning "men T room a circle a sphere a cone an apex legenda a side view of the pyramid lower case phi log encoded polar LUT binary search tree klein bottle signed distance field". Page 5 contains the author's controlling Axis0=ALL-admitted-operators definition. Pages 1–3 contain geometry, LUT, one-bit jitter and Klein vocabulary. The accompanying exported explanations are not executable laws.

**S2.** Eight-page continuation, hyphenated filename beginning "men-T-room-a-circle-a-sphere" and ending "klein-bottl.pdf". Its exported material introduces seed, grounding, readout, SDF=T, Present and Now (pages 6–8). This package does not claim a physical time model from those descriptions.

**S3.** Six-page document beginning "ladybug-anti-violence-tile-in-zaandam-at-the-train-station" and ending "NP-hard-problem-where-humans-try-to-solv.pdf". Page 1 proposes one-bit packing; page 2 explicitly asks for Boolean double UU; pages 3–4 give the exported field/operator expression. Assertions about immediate TSP solutions and other applications do not include algorithms or evidence sufficient to implement those properties.

**S4.** Current request: packed one-bit CUDA kernel, integer-only computation, log-polar LUT textures, optional high-VRAM workload, feedback, OR union, RTX 5070 Ti Laptop with 12 GB, ZIP delivery and post-implementation comparisons.

Implementation choices introduced in this release: the exact word ABI, row LUT, topology seams, four mode equations, scene/history encodings, optional per-word jitter, atlas replication/sharding, termination/readout protocol, CPU/GPU tests and all benchmark code.

## Primary technical references

**N1. NVIDIA GeForce RTX 50 Series Laptops.** Official specifications identify the RTX 5070 Ti Laptop GPU's 12GB GDDR7 configuration. No local device was available to measure its performance.

https://www.nvidia.com/en-us/geforce/laptops/50-series/

**N2. NVIDIA CUDA GPU Compute Capability.** Lists RTX 5070 Ti under 12.0. The executable additionally queries the user's actual device.

https://developer.nvidia.com/cuda/gpus

**N3. NVIDIA CUDA C++ Programming Guide 12.8.1.** Sections7.8.1.1,3.2.14.4 and5.3.2 document integer tex1Dfetch, texture write/read coherence, and cache-locality behavior. These support API choices, not measured speed claims for this program.

https://docs.nvidia.com/cuda/archive/12.8.1/cuda-c-programming-guide/index.html

**N4. NVIDIA CUDA Compiler Driver 12.8.** The supported targets include compute_120 and sm_120. This is the build target, not a claim that CUDA compilation was performed in the preparation environment.

https://docs.nvidia.com/cuda/archive/12.8.1/cuda-compiler-driver-nvcc/index.html

The wave correctness proof, exchange inverse and storage ratios follow directly from the equations in MODEL.md. The comparative timings come from the delivered benchmark source and raw JSON, not from a hardware vendor's marketing result.

**A1. Sedgewick and Wayne, Princeton Algorithms, BreadthFirstPaths.java.** Official reference for the existing unweighted queue-based shortest-path method. The benchmark here is a separate C++ implementation, not a timing measurement of Princeton's Java code.

https://algs4.cs.princeton.edu/41graph/BreadthFirstPaths.java.html
