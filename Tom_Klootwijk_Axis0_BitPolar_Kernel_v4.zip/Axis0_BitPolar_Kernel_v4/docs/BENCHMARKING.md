# Reproduce the comparisons

The frozen production implementation is identified by `verification/kernel_freeze.json`. CPU comparison code was added afterward and can be built separately. Its floating-point Boolean baseline is not linked into the production kernel or utilities.

## CPU

```sh
cmake -S . -B build-compare -DAXIS0_ENABLE_CUDA=OFF -DAXIS0_BUILD_BENCHMARKS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-compare --config Release --target axis0_compare --parallel
./build-compare/axis0_compare --repeats 5 --json local_cpu_comparison.json
```

For a Visual Studio multi-configuration build, the last executable is `build-compare/Release/axis0_compare.exe`.

The benchmark checks every result against an independent BFS. It compares the frozen packed-word transition, byte and FP32 Boolean sweeps, and an ordinary queue. It measures a complete reachability query, not an arbitrary short interval that omits work from one backend. Buffers are preallocated and reset outside the timer. Input graph, seed, edge costs and completion predicate are held fixed. The FP32 values are only zero or one; no comparison with arbitrary real-valued distance information is implied.

Raw per-repeat nanoseconds are recorded. CPU frequency, virtualization, caches and competing tasks can affect results; five repetitions are not a general performance proof. The provided report identifies the preparation host and records that no affinity or fixed-clock policy was applied.

## GPU

Build and run `axis0_cuda --self-test` before relying on the CUDA backend. This local self-test is the place where shader compilation/runtime and texture-coherence behavior can be checked on the actual device; the preparation environment had neither CUDA nor a GPU.

```sh
python tools/benchmark_gpu.py --exe build/axis0_cuda --charts 1,16,256 --steps 128 --repeats 3 --output local_gpu_comparison.json
```

To add a workload near a requested fraction of current free VRAM, add `--vram-percent 90`. The script determines the chart count once, then passes exactly that count to both read backends. A percentage is not independently recomputed for each backend, which would risk comparing unequal amounts of work. Allocation failure is reported rather than silently dropping charts.

Each run is a fresh process. Its internal host timer begins after allocation/initialization and ends after the last update and synchronization. It includes launch/dispatch overhead and may include first dispatch effects; it is not an isolated warm-cache GPU-event benchmark. Alternating backend order reduces, but does not eliminate, temperature/order effects. Counts and the first-chart digest must match across backends and repetitions. The script saves partial results on a failed or incomplete run.

The reported logical cell-update rate counts all addressed cells times all steps, including cells whose state does not change. It is not a visited-cell rate, instruction throughput, DRAM bandwidth or real-world routing requests per second. The script does not measure cache hits or power. Atlas chart replication creates independent workloads, not a larger globally connected problem.

To inspect actual instructions separately:

```sh
nvcc -std=c++17 -arch=compute_120 -I include -I cuda --ptx cuda/kernels.cu -o build/kernels.ptx
python tools/audit_ptx.py build/kernels.ptx
```

The audit utility rejects floating-point-typed instruction tokens and requires a nonempty instruction stream. PTX is compiler output, not final GPU machine code; an instruction audit is also not a runtime correctness test.
