# Binary scene and history formats

All integers are unsigned 32-bit little-endian unless stated. A word's bit 0 is the lowest theta index in that word. A chart is theta-major within each radial row. No float or native-endian struct serialization is used.

## AXIS0U4 scene

Eight magic bytes: `41 58 49 53 30 55 34 00` (`AXIS0U4\0`).

Eight uint32 header values, in order:

| Index | Value |
|---|---|
| 0 | version 1 |
| 1 | theta bins, power of two >=32 |
| 2 | radial rings, power of two >=1 |
| 3 | topology: 0 rect, 1 polar, 2 klein |
| 4 | bins_per_phi, power of two <=65536 |
| 5 | words_per_plane = theta*rings/32 |
| 6 | plane count = 3 |
| 7 | reserved = 0 |

After the 40-byte header: Allowed, F, O, each with words_per_plane words. Exact file length is `40 + 12*words_per_plane` bytes. A scene contains one chart. The atlas runner replicates it when charts>1. Final state writes the first chart only. A fresh wave solve requires F=O and seed bits contained in Allowed.

## AXIS0H4 history

Eight magic bytes: `AXIS0H4\0`. Header layout is the same except entries 6 and 7 are both zero. Every following fixed-size frame is one O plane of the first chart. Frame 0 is the initial O; each executed transition appends one frame. The number of frames follows from file length. When a wave exhausts, its final empty frontier is also present.

The reader checks the header, length and coordinate domain. Path decoding is valid for history produced by the wave profile, not arbitrary exchange/union history. With `--initial`, it also checks source membership and the allowed cells of the reconstructed path. It does not authenticate untrusted history or prove that arbitrary external frames are a complete shortest-path computation.

## Coordinate and code examples

The included rectangular maze is embedded in a 32x8 zero-filled layout; unused cells are blocked. Its target is `(7,5)`, and the shortest route is 12 edges.

The included polar map is 64x16. Its seed is `(4,2)` and the demonstrated target is `(4,13)`. Theta wraps from 0 to 63. A barrier at ring 8 leaves a gate at theta 48–49. Its shortest native route is 49 edges.

Example creation and readout use Python standard-library utilities:

```sh
python tools/make_scene.py custom.a0 --theta 256 --rings 64 --example polar-route
python tools/logpolar_lut.py custom_geometry.json --theta 256 --rings 64
```

For arbitrary application input, construct a `formats.Scene`, set the bitplanes, and call `write_scene`. Geometry creation is separate from running the kernel. There is no automatic mesh, image, geographic-coordinate or arbitrary SDF importer in this release.
