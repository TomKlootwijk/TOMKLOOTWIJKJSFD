#!/usr/bin/env python3
"""Cross-language file, route, inverse, fixed-point and audit-tool checks."""
from __future__ import annotations
import argparse
import ast
from collections import deque
from decimal import Decimal, localcontext
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from formats import blank, read_scene, write_scene, read_history, bit  # noqa: E402
from logpolar_lut import generate  # noqa: E402
from readout import decode  # noqa: E402
from audit_ptx import audit  # noqa: E402

def require(ok: bool, message: str) -> None:
    if not ok:
        raise AssertionError(message)

def decimal_pi() -> Decimal:
    def atan(x: Decimal) -> Decimal:
        term = x
        result = x
        k = 1
        while abs(term) > Decimal("1e-75"):
            term *= -(x * x)
            result += term / (2 * k + 1)
            k += 1
        return result
    return 16 * atan(Decimal(1) / 5) - 4 * atan(Decimal(1) / 239)

def trig(x: Decimal) -> tuple[Decimal, Decimal]:
    s = st = x
    c = ct = Decimal(1)
    for k in range(1, 100):
        st *= -x * x / ((2 * k) * (2 * k + 1))
        ct *= -x * x / ((2 * k - 1) * (2 * k))
        s += st
        c += ct
    return c, s

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--exe", type=Path, required=True)
    p.add_argument("--json", type=Path, required=True)
    a = p.parse_args()
    exe = str(a.exe.resolve())
    report: dict = {"status": "PASS", "version": "4.0", "gpu_execution": "NOT_RUN"}
    with tempfile.TemporaryDirectory(prefix="axis0_test_") as td:
        tmp = Path(td)
        def run(*args: str) -> dict:
            return json.loads(subprocess.check_output([exe, *args], text=True))
        for fname, target, expected in (("rect_route.a0", (7, 5), 12), ("polar_route.a0", (4, 13), 49)):
            src = ROOT / "examples" / fname
            hist = tmp / (fname + "h")
            out = tmp / (fname + ".out")
            r = run("--scene", str(src), "--until-empty", "--verify", "--out", str(out), "--history", str(hist))
            require(r["oracle_verified"] and r["exhausted"], "route verification/exhaustion")
            decoded = decode(hist, *target, src)
            require(decoded["shortest_graph_hops"] == expected, "route length mismatch")
            scene, frames = read_history(hist)
            source = read_scene(src)
            d = [-1] * source.cells
            q: deque[int] = deque()
            for i in range(source.cells):
                if bit(source.field, i):
                    d[i] = 0
                    q.append(i)
            while q:
                i = q.popleft()
                for j in source.neighbours(i):
                    if bit(source.allowed, j) and d[j] < 0:
                        d[j] = d[i] + 1
                        q.append(j)
            got = [-1] * source.cells
            for k, frame in enumerate(frames):
                for i in range(source.cells):
                    if bit(frame, i):
                        require(got[i] == -1, "duplicate arrival")
                        got[i] = k
            require(got == d, "Python queue all-cell arrivals mismatch")
            report[fname] = {"distance": expected, "steps": r["executed_steps"], "reached": r["field_ones"]}
        src = ROOT / "examples" / "exchange.a0"
        fwd, rev = tmp / "fwd.a0", tmp / "rev.a0"
        for jitter in (0, 1):
            run("--scene", str(src), "--mode", "exchange", "--steps", "37", "--jitter", str(jitter), "--out", str(fwd), "--verify")
            run("--scene", str(fwd), "--mode", "inverse", "--steps", "37", "--jitter", str(jitter), "--out", str(rev), "--verify")
            require(src.read_bytes() == rev.read_bytes(), "full feedback reversal mismatch")
        report["37_step_file_exact_roundtrip_cases"] = 2
        union_src = ROOT / "examples" / "phase_union.a0"
        out = tmp / "union.a0"
        run("--scene", str(union_src), "--mode", "union", "--steps", "1", "--out", str(out), "--verify")
        us, uo = read_scene(union_src), read_scene(out)
        require(uo.field == [f | o for f, o in zip(us.field, us.operator)], "OR union mismatch")
        empty = blank(32, 4, 1)
        write_scene(tmp / "empty.a0", empty)
        r = run("--scene", str(tmp / "empty.a0"), "--until-empty", "--verify")
        require(r["executed_steps"] == 0 and r["exhausted"], "empty seed failed")
        bad = subprocess.run([exe, "--mode", "wave", "--jitter", "1"], capture_output=True)
        require(bad.returncode != 0, "undefined routing jitter accepted")
        malformed = tmp / "bad.a0"
        malformed.write_bytes(b"bad")
        bad = subprocess.run([exe, "--scene", str(malformed)], capture_output=True)
        require(bad.returncode != 0, "malformed input accepted")
        report["union_empty_and_error_cases"] = 4
    max_radius_error = Decimal(0)
    max_angle_error = Decimal(0)
    with localcontext() as ctx:
        ctx.prec = 85
        phi = (Decimal(1) + Decimal(5).sqrt()) / 2
        pi = decimal_pi()
        for bins in (1, 2, 64, 1024):
            lut = generate(64, 256, bins)
            for radial in lut["radial"]:
                rho = radial["rho"]
                want = (phi.ln() * Decimal(rho) / bins).exp()
                got = Decimal(radial["radius_mantissa_q31"]) * (Decimal(2) ** (radial["radius_exponent2"] - 31))
                max_radius_error = max(max_radius_error, abs(got / want - 1))
                require(radial["log_phi_q16"] == (rho << 16) // bins, "log coordinate mismatch")
            for i, (cq, sq) in enumerate(lut["angular_cos_sin_q30"]):
                angle = pi * Decimal(2 * i + 1) / 64
                if angle > pi:
                    angle -= 2 * pi
                c, s = trig(angle)
                max_angle_error = max(max_angle_error, abs(Decimal(cq) / (1 << 30) - c), abs(Decimal(sq) / (1 << 30) - s))
        require(max_radius_error < Decimal("1e-8"), "fixed-point radius error")
        require(max_angle_error < Decimal("1e-7"), "CORDIC direction error")
    report["geometry_checks"] = {"radial_samples": 1024, "angular_samples": 256,
                                  "max_relative_radius_error_decimal": str(max_radius_error),
                                  "max_absolute_direction_error_decimal": str(max_angle_error),
                                  "reference": "85-digit Decimal; finite tested samples only"}
    # A source audit is NOT a generated-machine-code audit.
    cpp_files = list((ROOT / "include").rglob("*.hpp")) + list((ROOT / "cuda").glob("*")) + list((ROOT / "src").glob("*.cpp"))
    for path in cpp_files:
        text = path.read_text()
        text = re.sub(r"/\*.*?\*/|//[^\n]*", "", text, flags=re.S)
        text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
        require(not re.search(r"\b(?:float|double)\b", text), f"explicit floating type in {path.name}")
    tree = ast.parse((ROOT / "tools" / "logpolar_lut.py").read_text())
    require(not any(isinstance(n, ast.Constant) and isinstance(n.value, float) for n in ast.walk(tree)), "binary-float LUT literal")
    require(not any(isinstance(n, ast.BinOp) and isinstance(n.op, ast.Div) for n in ast.walk(tree)), "binary-float LUT division")
    require(audit("add.u32 %r1, %r2, %r3;\n")["status"] == "PASS", "PTX audit integer fixture")
    require(audit("add.f32 %f1, %f2, %f3;\n")["status"] == "FAIL", "PTX audit float fixture")
    report["production_source_explicit_float_type_audit"] = "PASS"
    report["ptx_audit_fixture_cases"] = 2
    report["actual_cuda_ptx_audit"] = "NOT_RUN_NO_CUDA_TOOLKIT"
    a.json.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
