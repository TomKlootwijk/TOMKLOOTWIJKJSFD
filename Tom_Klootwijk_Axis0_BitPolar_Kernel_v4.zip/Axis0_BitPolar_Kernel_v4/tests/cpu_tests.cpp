#include "axis0/cli.hpp"
#include "axis0/oracle.hpp"
#include <cstdio>
#include <random>
namespace { void require(bool ok,const char* s){if(!ok)throw std::runtime_error(s);} }
int main(int argc,char** argv) {
    using namespace axis0;
    try {
        const auto begin=std::chrono::steady_clock::now();
        std::uint64_t exhaustive=0,stencil=0,transitions=0,inverse=0,atlas=0,extra=0;
        for(Word code=0;code<19683u;++code) {
            Scene s=blank_scene(32,4,Topology::Rect);std::fill(s.allowed.begin(),s.allowed.end(),0);Word v=code;
            for(Word y=0;y<3;++y)for(Word x=0;x<3;++x){Word status=v%3;v/=3;
                if(status)put(s.allowed,y*32+x);if(status==2)put(s.field,y*32+x);}
            s.op=s.field;require(bfs(s)==packed_arrivals(s),"exhaustive arrival mismatch");++exhaustive;
        }
        std::mt19937 rng(20260918u);
        for(Topology topo:{Topology::Rect,Topology::Polar,Topology::Klein})
          for(Word theta:{32u,64u,128u,256u})for(Word rings:{1u,2u,4u,16u}) {
            Scene s=blank_scene(theta,rings,topo);
            for(Word trial=0;trial<24;++trial) {
                for(Word i=0;i<s.layout.chart_words;++i){s.op[i]=trial==0?0:trial==1?INVALID:Word(rng());s.field[i]=Word(rng());s.allowed[i]=Word(rng());}
                PointerReader rd{s.field.data(),s.op.data(),s.allowed.data(),s.rows.data()};auto ref=scalar_neighbours(s,s.op);
                for(Word i=0;i<s.layout.chart_words;++i)require(neighbours_or(rd,i,s.layout,Plane::Operator)==ref[i],"stencil mismatch");++stencil;
                for(Mode mode:{Mode::Wave,Mode::Union,Mode::Exchange,Mode::Inverse})
                  for(Word jitter=0;jitter<=(mode==Mode::Exchange||mode==Mode::Inverse?1u:0u);++jitter) {
                    Scene a=s,b=s;Word key=Word(rng());step_cpu(a,mode,key,jitter);step_scalar(b,mode,key,jitter);
                    require(a.field==b.field&&a.op==b.op,"scalar transition mismatch");++transitions;
                  }
                for(Word jitter:{0u,1u}) {Scene a=s;Word key=Word(rng());
                    step_cpu(a,Mode::Exchange,key,jitter);step_cpu(a,Mode::Inverse,key,jitter);
                    require(a.field==s.field&&a.op==s.op,"inverse mismatch");++inverse;}
            }
            const Word words=s.layout.chart_words,charts=3;
            std::vector<Word> f(charts*words),o(f.size()),a(f.size());
            for(Word i=0;i<f.size();++i){f[i]=Word(rng());o[i]=Word(rng());a[i]=Word(rng());}
            PointerReader r{f.data(),o.data(),a.data(),s.rows.data()};
            for(Word c=0;c<charts;++c) {
                Scene local=s;local.field.assign(f.begin()+c*words,f.begin()+(c+1)*words);
                local.op.assign(o.begin()+c*words,o.begin()+(c+1)*words);local.allowed.assign(a.begin()+c*words,a.begin()+(c+1)*words);
                step_scalar(local,Mode::Wave);
                for(Word i=0;i<words;++i){Pair p=step_word<Mode::Wave>(r,c*words+i,s.layout);
                    require(p.field==local.field[i]&&p.op==local.op[i],"chart cross-talk");}++atlas;
            }
          }
        for(unsigned i=0;i<240;++i) {
            Scene s=blank_scene(32u<<(i%3),1u<<(i%5),Topology(i%3));
            for(Word j=0;j<s.layout.chart_words;++j){s.allowed[j]=Word(rng());s.field[j]=Word(rng())&s.allowed[j];}
            s.op=s.field;require(bfs(s)==packed_arrivals(s),"additional arrival mismatch");++extra;
        }
        Scene s=seeded_scene(64,8,Topology::Klein,32,true);write_scene("axis0_roundtrip_test.a0",s);
        Scene b=read_scene("axis0_roundtrip_test.a0");std::remove("axis0_roundtrip_test.a0");
        require(s.field==b.field&&s.op==b.op&&s.allowed==b.allowed&&s.topology==b.topology,"file roundtrip mismatch");
        const auto end=std::chrono::steady_clock::now();std::ostringstream r;
        r<<"{\n  \"version\": \"4.0\", \"status\": \"PASS\",\n"
         <<"  \"exhaustive_embedded_3x3_wave_cases\": "<<exhaustive<<",\n"
         <<"  \"additional_wave_cases\": "<<extra<<",\n"
         <<"  \"stencil_pattern_cases\": "<<stencil<<",\n"
         <<"  \"scalar_transition_cases\": "<<transitions<<",\n"
         <<"  \"exchange_inverse_cases\": "<<inverse<<",\n"
         <<"  \"heterogeneous_atlas_chart_cases\": "<<atlas<<",\n"
         <<"  \"scene_roundtrip_cases\": 1,\n"
         <<"  \"elapsed_host_ns\": "<<nanos(begin,end)<<",\n"
         <<"  \"gpu_execution\": \"NOT_RUN\"\n}";
        emit(r.str(),argc==3&&std::string(argv[1])=="--json"?argv[2]:"");return 0;
    }catch(const std::exception& e){std::cerr<<"CPU TEST FAILURE: "<<e.what()<<'\n';return 1;}
}
