param([switch]$CpuOnly)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$Build = if ($CpuOnly) { "build-cpu" } else { "build" }
$Cuda = if ($CpuOnly) { "OFF" } else { "ON" }
& cmake -S . -B $Build -G "Visual Studio 17 2022" -A x64 "-DAXIS0_ENABLE_CUDA=$Cuda" -DAXIS0_CUDA_ARCH=120
if ($LASTEXITCODE -ne 0) { throw "CMake configuration failed. Check CUDA and Visual Studio C++ installation." }
& cmake --build $Build --config Release --parallel
if ($LASTEXITCODE -ne 0) { throw "Build failed." }
& ctest --test-dir $Build -C Release --output-on-failure
if ($LASTEXITCODE -ne 0) { throw "CPU conformance tests failed." }
if (-not $CpuOnly) {
    Write-Host "Next: .\build\Release\axis0_cuda.exe --info"
    Write-Host "Then: .\build\Release\axis0_cuda.exe --self-test --json verification\local_gpu_tests.json"
}
