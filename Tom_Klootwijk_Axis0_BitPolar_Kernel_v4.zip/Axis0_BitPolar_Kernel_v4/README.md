# Axis 0 — BitPolar packed-bit kernel, v4.0

**Tom Klootwijk · NL200678942 · 10-07-1990 (date as supplied)**

A concrete execution profile of the supplied Axis 0 / Boolean double UU definition: two one-bit field/operator layers, packed into unsigned words, addressed on native log-polar charts, with CUDA integer texture reads and feedback.

**Delivery status:** this is a source distribution, not a precompiled Windows executable. The shared integer core was compiled, executed and checked on the CPU. CUDA compilation and execution were **not available in the preparation environment**. GPU self-tests, source, CMake targets and measurement tools are included; GPU throughput is not represented as a measured result.

## What is in the kernel

Each `uint32_t` holds **32 logical one-bit cells**. The field engine, coordinate indexing, state updates and supplied geometry-LUT generator use integer arithmetic. Texture reads use unsigned elements and integer `tex1Dfetch` coordinates, not filtered or normalized floating-point samples. The optional post-hoc benchmark is separate and includes an FP32 Boolean-storage baseline.

| Mode | Update | Meaning |
|---|---|---|
| `wave` | `O_next = Allowed & ~F & neighbours_OR(O)`; `F_next = F | O_next` | Exact first-arrival reachability on the declared unit-cost graph. |
| `union` | `F_next = F | O`; `O_next = O` | Union of occupancy/phase masks on a common chart. |
| `exchange` | `(F_next,O_next) = (O, F ^ neighbours_OR(O) ^ jitter)` | Field/operator feedback with an explicit reversible rule. |
| `inverse` | `(F_next,O_next) = (O ^ neighbours_OR(F) ^ jitter, F)` | Reverses exchange when the key schedule is reversed too. |

`rect`, `polar` and `klein` choose boundary/address rules. Polar charts wrap around theta and are open radially. The discrete Klein seam reflects theta at radial wrap. This implementation does not evaluate a continuous Klein-bottle metric or a signed-distance magnitude.

OR is the union operator for the stored binary fields. AND and complement enforce the allowed/unvisited set in routing. XOR remains necessary for an actual flip or reversible feedback. Replacing all of these operations with OR changes the stated mathematics.

## Build on the RTX 5070 Ti laptop

The default CUDA target is **SM120**. NVIDIA lists the RTX 5070 Ti family under compute capability 12.0, and the laptop specification has 12 GB GDDR7. Device identity, free VRAM and texture limits are queried by the executable rather than hardcoded. Sources are in `docs/SOURCES.md`.

Requirements: CMake 3.24+, a CUDA toolkit supporting `sm_120` (12.8 or later), a CUDA-supported C++ host compiler, and an NVIDIA driver compatible with that toolkit/GPU. The Windows shortcut expects Visual Studio 2022 with C++ tools and CUDA's build integration. Python 3.10+ is needed only for utilities and their tests; they have no third-party dependencies.

From a Visual Studio Developer PowerShell, in this directory:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DAXIS0_CUDA_ARCH=120
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
.\build\Release\axis0_cuda.exe --info
.\build\Release\axis0_cuda.exe --self-test --json verification\local_gpu_tests.json
```

The convenience script `build_windows.ps1` performs the build and CPU tests. `build_linux.sh` performs a Release build on Linux. Linux executables are in `build/`, not `build/Release/`.

A GPU-independent build is also available:

```sh
cmake -S . -B build-cpu -DAXIS0_ENABLE_CUDA=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-cpu --config Release --parallel
ctest --test-dir build-cpu -C Release --output-on-failure
```

## Run the included path example

```powershell
.\build\Release\axis0_cuda.exe --scene examples\polar_route.a0 --mode wave --until-empty --read texture --verify --history polar.a0h --out final.a0 --json local_route.json
python tools\readout.py polar.a0h --target 4,13 --initial examples\polar_route.a0 --json route.json
```

The CPU reference found a **49-hop** route from `(theta=4,rho=2)` to `(4,13)`, reached **962** allowed cells and detected an empty frontier after **65 updates**. The gate in the middle ring forces a detour. The history contains the initial frontier and every subsequent frontier; the route decoder selects predecessors from consecutive layers. These are chart-edge hop counts, not Euclidean lengths in the physical polar plane.

Replace the executable with `axis0_cpu` to reproduce this without CUDA. `--verify` checks the first chart against CPU execution after the timed GPU work. `--self-test` additionally compares GPU transitions with an independent scalar-coordinate oracle.

## OR-union and reversible feedback

Union two scenes' field masks, preserving their common layout:

```powershell
python tools\make_scene.py pair.a0 --left first.a0 --right second.a0
.\build\Release\axis0_cuda.exe --scene pair.a0 --mode union --steps 1 --out merged.a0
```

For the supplied union example, use `examples\phase_union.a0` directly. Repeated pairwise unions produce the union of any finite collection. This does not produce numeric metric distances from sign bits.

Run and undo 37 feedback steps:

```powershell
.\build\Release\axis0_cuda.exe --scene examples\exchange.a0 --mode exchange --jitter 1 --seed 19900710 --steps 37 --out forward.a0 --verify
.\build\Release\axis0_cuda.exe --scene forward.a0 --mode inverse --jitter 1 --seed 19900710 --steps 37 --out restored.a0 --verify
```

The corresponding CPU test restores the **complete scene file byte-for-byte**, both with and without jitter. A restored field is not evidence of universal computation: the transition rule is a fixed compiled rule, and the output state is fed into its next application.

## Use more VRAM deliberately

```powershell
.\build\Release\axis0_cuda.exe --mode exchange --theta 4096 --rings 1024 --jitter 1 --read texture --vram-percent 90 --steps 128 --json large_texture_run.json
```

This chooses a number of **independent replicated input charts** from 90% of the currently free memory budget. It does not connect those copies into a larger global map. The state buffers are divided into shards that respect the device's linear texture size limit. Reported memory covers current/next F and O plus the allowed mask; the LUT and other overhead are reported separately.

`--vram-percent 100` is accepted, but CUDA/context/allocator overhead and other applications can make the allocation fail. There is no silent reduction of the requested workload. Default operation uses one chart, not all VRAM. Holding a large allocation is not a measurement of maximum memory bandwidth, cache residency, or a speed improvement.

Compare the two actual read backends on your device:

```powershell
python tools\benchmark_gpu.py --exe build\Release\axis0_cuda.exe --charts 1,16,256 --vram-percent 90 --steps 128 --repeats 3 --output gpu_comparison.json
```

The comparison uses the same fixed chart count for texture and global reads, alternates their order, and checks output agreement. It records fresh-process whole-run timings, not a claimed cache hit rate. The PDF-derived phrase "in texture cache" is implemented as texture-backed reads; no code promises permanent residency of the VRAM contents in that cache.

## No floating-point field arithmetic: what is checked

`tests/tools_tests.py` audits explicit production float types and tests the integer geometry tables against a separate high-precision Decimal oracle. `tools/audit_ptx.py` checks actual PTX generated on your machine:

```powershell
nvcc -std=c++17 -arch=compute_120 -I include -I cuda --ptx cuda/kernels.cu -o build\kernels.ptx
python tools\audit_ptx.py build\kernels.ptx
```

PTX compilation/auditing has **not** been executed in the preparation environment. The source uses integer field math; this does not assert anything about unrelated internal arithmetic in NVIDIA's driver or operating system. Some CUDA descriptor structures contain API-defined floating members, zero-initialized during configuration; they are not field samples or kernel calculations.

## Evidence and exact scope

Read `verification/RESULTS.md` for executed test counts and the post-hoc CPU comparison. The larger comparison found the packed sweep about **31.18x faster than the included FP32 Boolean sweep**, but an ordinary queue BFS was about **14.98x faster than the packed sweep** on that same single-seed query. Neither ratio is a laptop-GPU result or a comparison with an optimized commercial SDF renderer.

`docs/MODEL.md` gives equations, storage, geometry, source mapping and missing/unimplemented contracts. `docs/FORMAT.md` documents the binary scene/history ABI. The package contains no TSP optimizer, real-valued distance reconstructor, fluid equations, universal evaluator, autonomous code replication, or hidden online service.
