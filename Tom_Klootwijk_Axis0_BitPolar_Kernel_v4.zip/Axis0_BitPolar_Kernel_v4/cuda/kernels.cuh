#pragma once
#include <cuda_runtime.h>
#include "axis0/bitcore.hpp"
namespace axis0::gpu {
struct View {
    const Word *field,*op,*allowed;const Row* rows;
    cudaTextureObject_t field_tex,op_tex,allowed_tex,row_tex;
};
// Input snapshots and output buffers MUST be disjoint. Launch boundaries order feedback.
cudaError_t update(View v,Word* next_field,Word* next_op,Word words,Layout l,
                   Mode mode,bool texture,Word key,Word jitter,Word* any_operator,
                   unsigned blocks,cudaStream_t stream=nullptr);
cudaError_t initialize(Word* f,Word* o,Word* a,const Word* sf,const Word* so,
                       const Word* sa,Word words,Word chart_mask,unsigned blocks,
                       cudaStream_t stream=nullptr);
cudaError_t statistics(const Word* f,const Word* o,Word words,unsigned long long* counts,
                       unsigned blocks,cudaStream_t stream=nullptr);
}
