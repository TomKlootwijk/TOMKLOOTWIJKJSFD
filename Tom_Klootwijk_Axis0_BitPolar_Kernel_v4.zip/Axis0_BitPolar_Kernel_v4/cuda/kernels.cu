#include "kernels.cuh"
namespace axis0::gpu {
constexpr unsigned THREADS=256;
struct TextureReader {
    View v;
    A0_HD Word load(Plane p,Word i)const {
#if defined(__CUDA_ARCH__)
        const auto t=p==Plane::Field?v.field_tex:p==Plane::Operator?v.op_tex:v.allowed_tex;
        return tex1Dfetch<unsigned int>(t,static_cast<int>(i));
#else
        // Host instantiation only; device instantiation uses the integer texture instruction.
        return p==Plane::Field?v.field[i]:p==Plane::Operator?v.op[i]:v.allowed[i];
#endif
    }
    A0_HD Row row(Word rho)const {
#if defined(__CUDA_ARCH__)
        const uint4 x=tex1Dfetch<uint4>(v.row_tex,static_cast<int>(rho));return {x.x,x.y,x.z,x.w};
#else
        return v.rows[rho];
#endif
    }
};
template<Mode M,bool TEXTURE>
__global__ void step_kernel(View v,Word* f,Word* o,Word n,Layout l,Word key,Word jitter,Word* any) {
    const Word stride=blockDim.x*gridDim.x;Word active=0;
    for(Word i=blockIdx.x*blockDim.x+threadIdx.x;i<n;i+=stride) {
        Pair p;
        if constexpr(TEXTURE)p=step_word<M>(TextureReader{v},i,l,key,jitter);
        else p=step_word<M>(PointerReader{v.field,v.op,v.allowed,v.rows},i,l,key,jitter);
        f[i]=p.field;o[i]=p.op;active|=p.op;
    }
    if(any) {
        __shared__ Word flags[THREADS];flags[threadIdx.x]=active;__syncthreads();
        for(unsigned d=THREADS/2;d;d>>=1){if(threadIdx.x<d)flags[threadIdx.x]|=flags[threadIdx.x+d];__syncthreads();}
        if(threadIdx.x==0&&flags[0])atomicOr(any,1u);
    }
}
__global__ void initialize_kernel(Word* f,Word* o,Word* a,const Word* sf,const Word* so,
                                  const Word* sa,Word n,Word mask) {
    for(Word i=blockIdx.x*blockDim.x+threadIdx.x;i<n;i+=blockDim.x*gridDim.x) {
        const Word j=i&mask;f[i]=sf[j];o[i]=so[j];a[i]=sa[j];
    }
}
__global__ void statistics_kernel(const Word* f,const Word* o,Word n,unsigned long long* counts) {
    unsigned long long nf=0,no=0;
    for(Word i=blockIdx.x*blockDim.x+threadIdx.x;i<n;i+=blockDim.x*gridDim.x){nf+=__popc(f[i]);no+=__popc(o[i]);}
    __shared__ unsigned long long af[THREADS],ao[THREADS];af[threadIdx.x]=nf;ao[threadIdx.x]=no;__syncthreads();
    for(unsigned d=THREADS/2;d;d>>=1){if(threadIdx.x<d){af[threadIdx.x]+=af[threadIdx.x+d];ao[threadIdx.x]+=ao[threadIdx.x+d];}__syncthreads();}
    if(threadIdx.x==0){atomicAdd(counts,af[0]);atomicAdd(counts+1,ao[0]);}
}
template<Mode M>
void launch(View v,Word* f,Word* o,Word n,Layout l,bool texture,Word key,Word jitter,
            Word* any,unsigned blocks,cudaStream_t stream) {
    if(texture)step_kernel<M,true><<<blocks,THREADS,0,stream>>>(v,f,o,n,l,key,jitter,any);
    else step_kernel<M,false><<<blocks,THREADS,0,stream>>>(v,f,o,n,l,key,jitter,any);
}
cudaError_t update(View v,Word* f,Word* o,Word n,Layout l,Mode m,bool texture,Word key,
                   Word jitter,Word* any,unsigned blocks,cudaStream_t stream) {
    if(!n||!blocks)return cudaErrorInvalidValue;
    switch(m) {
    case Mode::Wave:launch<Mode::Wave>(v,f,o,n,l,texture,key,jitter,any,blocks,stream);break;
    case Mode::Union:launch<Mode::Union>(v,f,o,n,l,texture,key,jitter,any,blocks,stream);break;
    case Mode::Exchange:launch<Mode::Exchange>(v,f,o,n,l,texture,key,jitter,any,blocks,stream);break;
    case Mode::Inverse:launch<Mode::Inverse>(v,f,o,n,l,texture,key,jitter,any,blocks,stream);break;
    default:return cudaErrorInvalidValue;
    }return cudaGetLastError();
}
cudaError_t initialize(Word* f,Word* o,Word* a,const Word* sf,const Word* so,const Word* sa,
                       Word n,Word mask,unsigned blocks,cudaStream_t stream) {
    if(!n||!blocks)return cudaErrorInvalidValue;
    initialize_kernel<<<blocks,THREADS,0,stream>>>(f,o,a,sf,so,sa,n,mask);return cudaGetLastError();
}
cudaError_t statistics(const Word* f,const Word* o,Word n,unsigned long long* counts,
                       unsigned blocks,cudaStream_t stream) {
    if(!n||!blocks)return cudaErrorInvalidValue;
    statistics_kernel<<<blocks,THREADS,0,stream>>>(f,o,n,counts);return cudaGetLastError();
}
} // namespace axis0::gpu
