#pragma once
#include "kernels.cuh"
#include "axis0/model.hpp"
#include <memory>
#include <utility>
namespace axis0::gpu {
inline void check(cudaError_t e,const char* op) {
    if(e!=cudaSuccess)throw std::runtime_error(std::string(op)+": "+cudaGetErrorString(e));
}
template<class T>class Buffer {
    T* p_=nullptr;std::size_t n_=0;
public:
    Buffer()=default;
    explicit Buffer(std::size_t n):n_(n) {
        if(n>std::numeric_limits<std::size_t>::max()/sizeof(T))throw std::overflow_error("device allocation overflow");
        if(n)check(cudaMalloc(reinterpret_cast<void**>(&p_),n*sizeof(T)),"cudaMalloc");
    }
    ~Buffer(){if(p_)cudaFree(p_);}
    Buffer(const Buffer&)=delete;Buffer& operator=(const Buffer&)=delete;
    Buffer(Buffer&& b)noexcept:p_(std::exchange(b.p_,nullptr)),n_(std::exchange(b.n_,0)){}
    Buffer& operator=(Buffer&& b)noexcept{if(this!=&b){if(p_)cudaFree(p_);p_=std::exchange(b.p_,nullptr);n_=std::exchange(b.n_,0);}return *this;}
    T* get()const{return p_;}std::size_t size()const{return n_;}
    void from(const T* p,std::size_t n){if(n>n_)throw std::out_of_range("device copy overflow");check(cudaMemcpy(p_,p,n*sizeof(T),cudaMemcpyHostToDevice),"copy to device");}
    void to(T* p,std::size_t n)const{if(n>n_)throw std::out_of_range("device copy overflow");check(cudaMemcpy(p,p_,n*sizeof(T),cudaMemcpyDeviceToHost),"copy from device");}
};
class Texture {
    cudaTextureObject_t handle_=0;
public:
    Texture()=default;
    Texture(const void* p,std::size_t bytes,bool row) {
        cudaResourceDesc resource{};resource.resType=cudaResourceTypeLinear;
        resource.res.linear.devPtr=const_cast<void*>(p);
        resource.res.linear.desc=row?cudaCreateChannelDesc<uint4>():cudaCreateChannelDesc<unsigned int>();
        resource.res.linear.sizeInBytes=bytes;
        cudaTextureDesc desc{};desc.addressMode[0]=cudaAddressModeClamp;desc.filterMode=cudaFilterModePoint;
        desc.readMode=cudaReadModeElementType;desc.normalizedCoords=0;
        check(cudaCreateTextureObject(&handle_,&resource,&desc,nullptr),"cudaCreateTextureObject");
    }
    ~Texture(){if(handle_)cudaDestroyTextureObject(handle_);}
    Texture(const Texture&)=delete;Texture& operator=(const Texture&)=delete;
    Texture(Texture&& b)noexcept:handle_(std::exchange(b.handle_,0)){}
    Texture& operator=(Texture&& b)noexcept{if(this!=&b){if(handle_)cudaDestroyTextureObject(handle_);handle_=std::exchange(b.handle_,0);}return *this;}
    cudaTextureObject_t get()const{return handle_;}
};
struct Shard {
    Word words;std::uint64_t charts;
    Buffer<Word> field[2],op[2],allowed;
    Texture field_tex[2],op_tex[2],allowed_tex;
    Shard(Word n,std::uint64_t c,bool textures):words(n),charts(c),
      field{Buffer<Word>(n),Buffer<Word>(n)},op{Buffer<Word>(n),Buffer<Word>(n)},allowed(n) {
        if(textures){for(int k=0;k<2;++k){field_tex[k]=Texture(field[k].get(),std::size_t(n)*4,false);op_tex[k]=Texture(op[k].get(),std::size_t(n)*4,false);}
            allowed_tex=Texture(allowed.get(),std::size_t(n)*4,false);}
    }
    View view(int p,const Row* r,cudaTextureObject_t rt)const {
        return {field[p].get(),op[p].get(),allowed.get(),r,field_tex[p].get(),op_tex[p].get(),allowed_tex.get(),rt};
    }
};
inline unsigned blocks_for(Word words,const cudaDeviceProp& p) {
    return std::max(1u,std::min((words+255u)>>8,unsigned(std::max(p.multiProcessorCount,1))*8u));
}
} // namespace axis0::gpu
