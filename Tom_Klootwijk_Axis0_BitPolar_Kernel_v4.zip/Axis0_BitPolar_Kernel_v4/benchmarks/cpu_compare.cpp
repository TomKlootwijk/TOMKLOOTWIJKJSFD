// POST-HOC comparison only. This file is not linked into either production runner.
// Implementations share the same Boolean reachability problem, NOT a real-valued SDF.
#include "axis0/cli.hpp"
#include "axis0/oracle.hpp"
#include <cstdint>
#include <numeric>
#include <type_traits>

namespace {
using namespace axis0;
using Clock=std::chrono::steady_clock;
struct Result { std::uint64_t ns,steps,visited; };

class Packed {
    const Scene& initial;
    std::vector<Word> f,o,nf,no;
public:
    explicit Packed(const Scene& s):initial(s),f(s.field),o(s.op),nf(f.size()),no(o.size()){}
    Result run() {
        f=initial.field;o=initial.op;std::uint64_t steps=0;Word alive=1;
        auto begin=Clock::now();
        while(alive) {
            const PointerReader r{f.data(),o.data(),initial.allowed.data(),initial.rows.data()};
            alive=0;
            for(Word i=0;i<initial.layout.chart_words;++i) {
                const Pair p=step_word<Mode::Wave>(r,i,initial.layout);
                nf[i]=p.field;no[i]=p.op;alive|=p.op;
            }
            f.swap(nf);o.swap(no);++steps;
        }
        const auto end=Clock::now();
        return {nanos(begin,end),steps,popcount(f)};
    }
    bool equals(const std::vector<std::int64_t>& d)const {
        for(std::size_t i=0;i<d.size();++i)if(bit(f,i)!=(d[i]>=0))return false;
        return popcount(o)==0;
    }
};

template<class T>class Dense {
    const Scene& initial;
    std::vector<T> a,seed,f,o,nf,no;
public:
    explicit Dense(const Scene& s):initial(s) {
        const std::size_t n=std::size_t(s.layout.theta)*s.layout.rings;
        a.resize(n);seed.resize(n);f.resize(n);o.resize(n);nf.resize(n);no.resize(n);
        for(std::size_t i=0;i<n;++i){a[i]=T(bit(s.allowed,i));seed[i]=T(bit(s.field,i));}
    }
    Result run() {
        f=seed;o=seed;std::uint64_t steps=0;bool alive=true;
        const std::size_t width=initial.layout.theta,height=initial.layout.rings;
        auto begin=Clock::now();
        while(alive) {
            alive=false;
            for(std::size_t y=0;y<height;++y) {
                const std::size_t row=y*width;
                for(std::size_t x=0;x<width;++x) {
                    const std::size_t i=row+x;
                    const bool horizontal=o[row+(x?x-1:width-1)]!=T{0} ||
                                          o[row+(x+1<width?x+1:0)]!=T{0};
                    const bool vertical=(y && o[i-width]!=T{0}) || (y+1<height && o[i+width]!=T{0});
                    const bool next=a[i]!=T{0} && f[i]==T{0} && (horizontal || vertical);
                    no[i]=T(next);nf[i]=T(f[i]!=T{0} || next);alive|=next;
                }
            }
            f.swap(nf);o.swap(no);++steps;
        }
        const auto end=Clock::now();std::uint64_t reached=0;
        for(T v:f)reached+=(v!=T{0});
        return {nanos(begin,end),steps,reached};
    }
    bool equals(const std::vector<std::int64_t>& d)const {
        for(std::size_t i=0;i<d.size();++i)if((f[i]!=T{0})!=(d[i]>=0)||o[i]!=T{0})return false;
        return true;
    }
};

class Queue {
    const Scene& initial;
    std::vector<std::uint8_t> allowed;
    std::vector<std::uint32_t> queue;
    std::vector<std::int64_t> d;
public:
    explicit Queue(const Scene& s):initial(s) {
        const std::size_t n=std::size_t(s.layout.theta)*s.layout.rings;
        allowed.resize(n);queue.resize(n);d.resize(n);
        for(std::size_t i=0;i<n;++i)allowed[i]=std::uint8_t(bit(s.allowed,i));
    }
    Result run() {
        std::fill(d.begin(),d.end(),-1);std::size_t head=0,tail=0;
        for(std::size_t i=0;i<d.size();++i)if(bit(initial.field,i)){d[i]=0;queue[tail++]=std::uint32_t(i);}
        const std::uint32_t width=initial.layout.theta,height=initial.layout.rings;
        std::int64_t maxd=0;auto begin=Clock::now();
        while(head<tail) {
            const auto i=queue[head++],x=i%width,y=i/width;
            const auto add=[&](std::uint32_t j) {
                if(allowed[j] && d[j]<0){d[j]=d[i]+1;maxd=std::max(maxd,d[j]);queue[tail++]=j;}
            };
            add(x?i-1:i+width-1);add(x+1<width?i+1:i-width+1);
            if(y)add(i-width);if(y+1<height)add(i+width);
        }
        const auto end=Clock::now();
        return {nanos(begin,end),std::uint64_t(maxd+1),tail};
    }
    bool equals(const std::vector<std::int64_t>& expected)const {return d==expected;}
};

template<class Solver>
std::vector<Result> measure(Solver& solver,const std::vector<std::int64_t>& reference,unsigned repeats) {
    (void)solver.run(); // one unrecorded warm-up of this backend
    if(!solver.equals(reference))throw std::runtime_error("baseline correctness failed in warm-up");
    std::vector<Result> samples;
    for(unsigned i=0;i<repeats;++i) {
        samples.push_back(solver.run());
        if(!solver.equals(reference))throw std::runtime_error("baseline result differs from independent BFS");
    }
    return samples;
}
void write_series(std::ostream& out,const char* name,const std::vector<Result>& s,bool comma) {
    std::vector<std::uint64_t> t;for(auto r:s)t.push_back(r.ns);std::sort(t.begin(),t.end());
    out<<"      \""<<name<<"\": {\"median_ns\":"<<t[t.size()/2]<<",\"samples_ns\":[";
    for(std::size_t i=0;i<s.size();++i){if(i)out<<',';out<<s[i].ns;}
    out<<"],\"steps_to_frontier_exhaustion\":"<<s[0].steps<<",\"visited\":"<<s[0].visited
       <<",\"correct\":true}"<<(comma?",":"")<<'\n';
}
} // namespace
int main(int argc,char** argv) {
    try {
        std::string path;unsigned repeats=5;
        for(int i=1;i<argc;++i) {
            std::string a=argv[i];if(i+1>=argc)throw std::invalid_argument("missing benchmark option value");
            if(a=="--json")path=argv[++i];else if(a=="--repeats")repeats=axis0::number32(argv[++i]);
            else throw std::invalid_argument("expected --json or --repeats");
        }
        if(repeats<1 || repeats%2==0)throw std::invalid_argument("use a positive odd repeat count");
        std::ostringstream out;
        out<<"{\n  \"version\":\"4.0\",\"phase\":\"post_hoc_after_core_freeze\",\"backend\":\"CPU_ONLY\",\n"
           <<"  \"problem\":\"Boolean reachability; polar angular wrap and open radial edges; one seed; open domain\",\n"
           <<"  \"method\":\"single thread; preallocated buffers; per-run reset and allocations excluded; stop detection included; one warm-up per backend; sequential backend groups\",\n"
           <<"  \"fp32_baseline\":\"32-bit float cells containing only 0 or 1; not a metric SDF, ray marcher, or optimized library\",\n"
           <<"  \"queue_baseline\":\"coordinate queue BFS; also computes 64-bit distances; allocations and initialization excluded\",\n"
           <<"  \"repeats\":"<<repeats<<",\"cases\":[\n";
        unsigned index=0;
        for(auto dims:{std::pair<axis0::Word,axis0::Word>{512,64},{1024,256}}) {
            Scene s=seeded_scene(dims.first,dims.second,Topology::Polar);
            const auto reference=bfs(s);
            Packed packed(s);Dense<std::uint8_t> byte(s);Dense<float> fp32(s);Queue queue(s);
            auto a=measure(packed,reference,repeats),b=measure(byte,reference,repeats),c=measure(fp32,reference,repeats),d=measure(queue,reference,repeats);
            out<<(index++?",\n":"")<<"    {\"theta\":"<<dims.first<<",\"rings\":"<<dims.second<<",\"cells\":"<<reference.size()<<",\"timings\":{\n";
            write_series(out,"packed_core",a,true);write_series(out,"byte_dense",b,true);
            write_series(out,"fp32_boolean_dense",c,true);write_series(out,"queue_bfs",d,false);out<<"    }}";
        }
        out<<"\n  ],\n  \"GPU_measurement\":\"NOT_RUN\"\n}";
        axis0::emit(out.str(),path);return 0;
    }catch(const std::exception& e){std::cerr<<"comparison failed: "<<e.what()<<'\n';return 1;}
}
