#include "axis0/cli.hpp"
#include "axis0/oracle.hpp"
int main(int argc,char** argv) {
    using namespace axis0;
    try {
        const Options o=parse(argc,argv);if(o.help){usage(std::cout,false);return 0;}
        if(o.info||o.self_test)throw std::invalid_argument("use axis0_cpu_tests for CPU tests; --info belongs to CUDA");
        if(o.charts!=1||o.vram_percent)throw std::invalid_argument("CPU runner executes one chart");
        Scene s=input_scene(o);const Scene initial=s;HistoryWriter history(o.history,s);
        std::uint64_t n=0;const auto begin=std::chrono::steady_clock::now();
        while(o.until_empty?popcount(s.op)!=0:n<o.steps){step_cpu(s,o.mode,step_key(o,n),o.jitter);++n;history.append(s.op);}
        const auto end=std::chrono::steady_clock::now();bool verified=false;
        if(o.verify){Scene ref=initial;for(std::uint64_t k=0;k<n;++k)step_scalar(ref,o.mode,step_key(o,k),o.jitter);
            if(s.field!=ref.field||s.op!=ref.op)throw std::runtime_error("scalar oracle mismatch");verified=true;}
        if(!o.out.empty())write_scene(o.out,s);
        std::ostringstream r;r<<"{\n  \"version\": \"4.0\", \"backend\": \"cpu_packed\",\n"
          <<"  \"mode\": \""<<name(o.mode)<<"\", \"topology\": \""<<name(s.topology)<<"\",\n"
          <<"  \"theta\": "<<s.layout.theta<<", \"rings\": "<<s.layout.rings<<",\n"
          <<"  \"executed_steps\": "<<n<<", \"elapsed_host_ns\": "<<nanos(begin,end)<<",\n"
          <<"  \"field_ones\": "<<popcount(s.field)<<", \"operator_ones\": "<<popcount(s.op)<<",\n"
          <<"  \"digest_u64\": "<<digest(s)<<", \"oracle_verified\": "<<(verified?"true":"false")<<",\n"
          <<"  \"exhausted\": "<<((o.mode==Mode::Wave&&!popcount(s.op))?"true":"false")<<",\n"
          <<"  \"timing_includes_history_io\": "<<(history.enabled()?"true":"false")<<"\n}";
        emit(r.str(),o.json);return 0;
    }catch(const std::exception& e){std::cerr<<"axis0_cpu: "<<e.what()<<'\n';return 1;}
}
