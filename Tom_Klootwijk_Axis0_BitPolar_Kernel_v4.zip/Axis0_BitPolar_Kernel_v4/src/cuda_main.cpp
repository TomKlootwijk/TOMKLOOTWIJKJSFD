#include "host.hpp"
#include "axis0/cli.hpp"
#include "axis0/oracle.hpp"
#include <random>
namespace {
using namespace axis0;using namespace axis0::gpu;
std::string info_json(const cudaDeviceProp& p,int dev) {
    std::size_t free=0,total=0;check(cudaMemGetInfo(&free,&total),"cudaMemGetInfo");
    int driver=0,runtime=0;check(cudaDriverGetVersion(&driver),"driver version");check(cudaRuntimeGetVersion(&runtime),"runtime version");
    std::ostringstream s;s<<"{\"device\":"<<dev<<",\"name\":\""<<escape(p.name)<<"\",\"compute_major\":"<<p.major
      <<",\"compute_minor\":"<<p.minor<<",\"total_bytes\":"<<total<<",\"free_bytes\":"<<free
      <<",\"sm_count\":"<<p.multiProcessorCount<<",\"l2_bytes\":"<<p.l2CacheSize
      <<",\"max_texture_1d_elements\":"<<p.maxTexture1DLinear<<",\"driver_version\":"<<driver<<",\"runtime_version\":"<<runtime<<"}";
    return s.str();
}
void self_test(const Options& options,const cudaDeviceProp& prop) {
    std::mt19937 rng(20260918u);std::uint64_t cases=0;
    for(Topology topo:{Topology::Rect,Topology::Polar,Topology::Klein})
      for(Word theta:{32u,64u,256u})for(Word rings:{1u,2u,8u}) {
        const Scene schema=blank_scene(theta,rings,topo);
        Buffer<Row> rows(schema.rows.size());rows.from(schema.rows.data(),schema.rows.size());Texture rt(rows.get(),schema.rows.size()*sizeof(Row),true);
        const Word charts=3,words=schema.layout.chart_words;std::vector<Word> f(charts*words),o(f.size()),a(f.size());
        for(Word i=0;i<f.size();++i){f[i]=Word(rng());o[i]=Word(rng());a[i]=Word(rng());}
        for(bool texture:{false,true}) {
            Shard sh(Word(f.size()),charts,texture);
            for(Mode m:{Mode::Wave,Mode::Union,Mode::Exchange,Mode::Inverse})
              for(Word jitter=0;jitter<=(m==Mode::Exchange||m==Mode::Inverse?1u:0u);++jitter) {
                sh.field[0].from(f.data(),f.size());sh.op[0].from(o.data(),o.size());sh.allowed.from(a.data(),a.size());Word key=Word(rng());
                check(update(sh.view(0,rows.get(),rt.get()),sh.field[1].get(),sh.op[1].get(),sh.words,schema.layout,m,texture,key,jitter,nullptr,blocks_for(sh.words,prop)),"test launch");
                check(cudaDeviceSynchronize(),"test synchronize");std::vector<Word> af(f.size()),ao(o.size());sh.field[1].to(af.data(),af.size());sh.op[1].to(ao.data(),ao.size());
                for(Word c=0;c<charts;++c) {
                    Scene ref=schema;ref.field.assign(f.begin()+c*words,f.begin()+(c+1)*words);ref.op.assign(o.begin()+c*words,o.begin()+(c+1)*words);
                    ref.allowed.assign(a.begin()+c*words,a.begin()+(c+1)*words);step_scalar(ref,m,key,jitter);
                    for(Word i=0;i<words;++i)if(af[c*words+i]!=ref.field[i]||ao[c*words+i]!=ref.op[i])throw std::runtime_error("GPU scalar mismatch");++cases;
                }
              }
        }
      }
    // Test launch-to-launch texture feedback, not merely isolated updates.
    Scene seed=seeded_scene(64,8,Topology::Polar);const auto expected=bfs(seed);
    Buffer<Row> rows(seed.rows.size());rows.from(seed.rows.data(),seed.rows.size());Texture rt(rows.get(),seed.rows.size()*sizeof(Row),true);
    Shard sh(seed.layout.chart_words,1,true);sh.field[0].from(seed.field.data(),seed.field.size());sh.op[0].from(seed.op.data(),seed.op.size());sh.allowed.from(seed.allowed.data(),seed.allowed.size());
    Buffer<Word> any(1);int p=0;Word alive=1;std::int64_t n=0;std::vector<std::int64_t>d(expected.size(),-1);
    while(alive) {
        std::vector<Word> op(seed.op.size());sh.op[p].to(op.data(),op.size());
        for(std::size_t i=0;i<d.size();++i)if(bit(op,i)){if(d[i]>=0)throw std::runtime_error("repeated GPU arrival");d[i]=n;}
        check(cudaMemset(any.get(),0,sizeof(Word)),"reset test flag");
        check(update(sh.view(p,rows.get(),rt.get()),sh.field[1-p].get(),sh.op[1-p].get(),sh.words,seed.layout,Mode::Wave,true,0,0,any.get(),blocks_for(sh.words,prop)),"wave launch");
        p=1-p;any.to(&alive,1);++n;if(n>std::int64_t(d.size()))throw std::runtime_error("GPU wave failed to terminate");
    }
    if(d!=expected)throw std::runtime_error("GPU wave distance mismatch");
    std::ostringstream r;r<<"{\"version\":\"4.0\",\"status\":\"PASS\",\"gpu_execution\":\"EXECUTED\",\"scalar_transition_chart_cases\":"<<cases
      <<",\"multistep_texture_wave_cases\":1,\"device\":"<<info_json(prop,options.device)<<"}";emit(r.str(),options.json);
}
}
int main(int argc,char** argv) {
    using namespace axis0;using namespace axis0::gpu;
    try {
        const Options opts=parse(argc,argv);if(opts.help){usage(std::cout,true);return 0;}
        check(cudaSetDevice(opts.device),"cudaSetDevice");check(cudaFree(nullptr),"initialize context");
        cudaDeviceProp prop{};check(cudaGetDeviceProperties(&prop,opts.device),"device properties");
        if(opts.info){emit(info_json(prop,opts.device),opts.json);return 0;}if(opts.self_test){self_test(opts,prop);return 0;}
        const bool texture=opts.read=="texture";const Scene input=input_scene(opts);const Layout l=input.layout;
        std::size_t free_initial=0,total=0;check(cudaMemGetInfo(&free_initial,&total),"query free memory");
        const std::uint64_t plane_bytes=std::uint64_t(l.chart_words)*sizeof(Word),per_chart=5*plane_bytes;
        const std::uint64_t overhead=input.rows.size()*sizeof(Row)+3*plane_bytes+sizeof(Word)+2*sizeof(unsigned long long);
        std::uint64_t charts=opts.charts;
        if(opts.vram_percent) {
            const std::uint64_t budget=(free_initial/100)*opts.vram_percent;
            if(budget<=overhead||budget-overhead<per_chart)throw std::runtime_error("VRAM budget does not fit one chart");
            charts=(budget-overhead)/per_chart;
        }
        if(charts>(std::numeric_limits<std::uint64_t>::max()-overhead)/per_chart)throw std::overflow_error("atlas size overflow");
        if(charts*per_chart+overhead>free_initial)throw std::runtime_error("atlas exceeds currently free device memory");
        const std::uint64_t maxtex=prop.maxTexture1DLinear>0?std::uint64_t(prop.maxTexture1DLinear):0;
        if(texture&&!maxtex)throw std::runtime_error("no linear texture capacity reported");
        const std::uint64_t shard_limit=texture?std::min(maxtex,std::uint64_t{1}<<27):(std::uint64_t{1}<<27);
        const std::uint64_t charts_per_shard=shard_limit/l.chart_words;
        if(!charts_per_shard)throw std::runtime_error("one chart exceeds texture-address limit");
        if(texture&&input.rows.size()>maxtex)throw std::runtime_error("row LUT exceeds linear-texture limit");
        Buffer<Row> rows(input.rows.size());rows.from(input.rows.data(),input.rows.size());Texture row_tex;
        if(texture)row_tex=Texture(rows.get(),input.rows.size()*sizeof(Row),true);
        Buffer<Word> any(1);Buffer<unsigned long long> counts(2);std::vector<std::unique_ptr<Shard>> shards;
        {
            Buffer<Word> f(l.chart_words),o(l.chart_words),a(l.chart_words);f.from(input.field.data(),l.chart_words);o.from(input.op.data(),l.chart_words);a.from(input.allowed.data(),l.chart_words);
            for(std::uint64_t remaining=charts;remaining;) {
                const auto c=std::min(remaining,charts_per_shard);const Word words=Word(c*l.chart_words);auto sh=std::make_unique<Shard>(words,c,texture);
                check(initialize(sh->field[0].get(),sh->op[0].get(),sh->allowed.get(),f.get(),o.get(),a.get(),words,l.chart_word_mask,blocks_for(words,prop)),"initialize atlas");
                shards.push_back(std::move(sh));remaining-=c;
            }
            check(cudaDeviceSynchronize(),"atlas initialization sync");
        }
        std::size_t free_after=0,total_after=0;check(cudaMemGetInfo(&free_after,&total_after),"post-allocation memory query");
        HistoryWriter history(opts.history,input);int p=0;std::uint64_t n=0;Word active=popcount(input.op)?1u:0u;
        const auto begin=std::chrono::steady_clock::now();
        while(opts.until_empty?active!=0:n<opts.steps) {
            if(opts.until_empty)check(cudaMemset(any.get(),0,sizeof(Word)),"reset frontier flag");
            const Word key=step_key(opts,n);
            for(auto& sh:shards)check(update(sh->view(p,rows.get(),row_tex.get()),sh->field[1-p].get(),sh->op[1-p].get(),sh->words,l,opts.mode,texture,key,opts.jitter,
                opts.until_empty?any.get():nullptr,blocks_for(sh->words,prop)),"update launch");
            p=1-p;++n;if(opts.until_empty)any.to(&active,1);
            if(history.enabled()){std::vector<Word> frame(l.chart_words);shards[0]->op[p].to(frame.data(),frame.size());history.append(frame);}
        }
        check(cudaDeviceSynchronize(),"execution sync");const auto end=std::chrono::steady_clock::now();
        check(cudaMemset(counts.get(),0,2*sizeof(unsigned long long)),"reset counts");
        for(auto& sh:shards)check(statistics(sh->field[p].get(),sh->op[p].get(),sh->words,counts.get(),blocks_for(sh->words,prop)),"statistics launch");
        unsigned long long totals[2]{};counts.to(totals,2);Scene output=input;
        shards[0]->field[p].to(output.field.data(),l.chart_words);shards[0]->op[p].to(output.op.data(),l.chart_words);bool verified=false;
        if(opts.verify){Scene ref=input;for(std::uint64_t k=0;k<n;++k)step_cpu(ref,opts.mode,step_key(opts,k),opts.jitter);
            if(ref.field!=output.field||ref.op!=output.op)throw std::runtime_error("first-chart CPU mismatch");verified=true;}
        if(!opts.out.empty())write_scene(opts.out,output);
        std::ostringstream r;r<<"{\n  \"version\":\"4.0\",\"gpu_execution\":\"EXECUTED\",\n"
          <<"  \"device\":"<<info_json(prop,opts.device)<<",\n"
          <<"  \"mode\":\""<<name(opts.mode)<<"\",\"read_backend\":\""<<opts.read<<"\",\n"
          <<"  \"topology\":\""<<name(input.topology)<<"\",\"theta\":"<<l.theta<<",\"rings\":"<<l.rings<<",\n"
          <<"  \"charts\":"<<charts<<",\"shards\":"<<shards.size()<<",\n"
          <<"  \"logical_cells\":"<<charts*std::uint64_t(l.theta)*l.rings<<",\n"
          <<"  \"state_and_mask_bytes\":"<<charts*per_chart<<",\"row_lut_bytes\":"<<input.rows.size()*sizeof(Row)<<",\n"
          <<"  \"free_before_bytes\":"<<free_initial<<",\"free_after_allocation_bytes\":"<<free_after<<",\n"
          <<"  \"executed_steps\":"<<n<<",\"elapsed_host_ns\":"<<nanos(begin,end)<<",\n"
          <<"  \"field_ones_all_charts\":"<<totals[0]<<",\"operator_ones_all_charts\":"<<totals[1]<<",\n"
          <<"  \"first_chart_digest_u64\":"<<digest(output)<<",\"first_chart_verified\":"<<(verified?"true":"false")<<",\n"
          <<"  \"exhausted\":"<<((opts.mode==Mode::Wave&&totals[1]==0)?"true":"false")<<",\n"
          <<"  \"timing_includes_launch_sync\":true,\"timing_includes_setup\":false,\n"
          <<"  \"timing_includes_history_io\":"<<(history.enabled()?"true":"false")<<"\n}";
        emit(r.str(),opts.json);return 0;
    }catch(const std::exception& e){std::cerr<<"axis0_cuda: "<<e.what()<<'\n';return 1;}
}
