#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mode="${1:-cuda}"
case "$mode" in
  cpu) build=build-cpu; cuda=OFF ;;
  cuda) build=build; cuda=ON ;;
  *) echo "Usage: ./build_linux.sh [cuda|cpu]" >&2; exit 2 ;;
esac
cmake -S . -B "$build" -DCMAKE_BUILD_TYPE=Release -DAXIS0_ENABLE_CUDA="$cuda" -DAXIS0_CUDA_ARCH=120
cmake --build "$build" --parallel
ctest --test-dir "$build" --output-on-failure
printf '\nBuilt %s. Run ./tools/readout.py through Python for recorded wave paths.\n' "$build"
if [[ "$cuda" == "ON" ]]; then
  echo "Next: $build/axis0_cuda --info"
  echo "Then: $build/axis0_cuda --self-test --json verification/local_gpu_tests.json"
fi
