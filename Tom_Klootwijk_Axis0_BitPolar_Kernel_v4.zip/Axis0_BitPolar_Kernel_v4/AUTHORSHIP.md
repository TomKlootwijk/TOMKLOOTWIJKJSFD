# Attribution record

Concept/formalization: **Tom Klootwijk**

Identifier supplied: **NL200678942**

Date supplied: **10-07-1990**

Artifact: **Axis0 BitPolar packed-bit kernel, version 4.0**

The supplied identifier and date are reproduced as requested. This file does not independently verify or assign a legal type to them.

The operational profiles, layout, CUDA and CPU source, tests, examples and post-hoc measurements were constructed in response to the request. Original terminology, exported explanatory statements, implementation choices and tested properties are distinguished in docs/MODEL.md and docs/SOURCES.md.
