#pragma once
// Independent coordinate/scalar oracle; not a part of the device hot path.
#include "axis0/model.hpp"
#include <deque>
namespace axis0 {
inline std::vector<std::uint64_t> adjacent(const Scene& s,std::uint64_t i) {
    const std::uint64_t t=s.layout.theta,r=s.layout.rings,x=i%t,y=i/t;
    if(i>=t*r)throw std::out_of_range("cell outside chart");
    std::vector<std::uint64_t> out;
    if(x)out.push_back(i-1);else if(s.topology!=Topology::Rect)out.push_back(y*t+t-1);
    if(x+1<t)out.push_back(i+1);else if(s.topology!=Topology::Rect)out.push_back(y*t);
    if(y)out.push_back(i-t);else if(s.topology==Topology::Klein)out.push_back((r-1)*t+(t-1-x));
    if(y+1<r)out.push_back(i+t);else if(s.topology==Topology::Klein)out.push_back(t-1-x);
    return out;
}
inline std::vector<Word> scalar_neighbours(const Scene& s,const std::vector<Word>& plane) {
    std::vector<Word> out(plane.size(),0);const std::uint64_t n=std::uint64_t(s.layout.theta)*s.layout.rings;
    for(std::uint64_t i=0;i<n;++i)if(bit(plane,i))for(auto j:adjacent(s,i))put(out,j);return out;
}
inline void step_scalar(Scene& s,Mode m,Word key=0,Word jitter=0) {
    const auto n=scalar_neighbours(s,m==Mode::Inverse?s.field:s.op);
    std::vector<Word> f(n.size()),o(n.size());
    for(std::size_t i=0;i<n.size();++i) {
        if(m==Mode::Union){f[i]=s.field[i]|s.op[i];o[i]=s.op[i];}
        else if(m==Mode::Wave){o[i]=n[i]&s.allowed[i]&~s.field[i];f[i]=s.field[i]|o[i];}
        else {const Word mask=jitter?(Word{1}<<(mix32(Word(i)^key)&31u)):0u;
            if(m==Mode::Exchange){f[i]=s.op[i];o[i]=s.field[i]^n[i]^mask;}
            else {f[i]=s.op[i]^n[i]^mask;o[i]=s.field[i];}}
    }
    s.field.swap(f);s.op.swap(o);
}
inline std::vector<std::int64_t> bfs(const Scene& s) {
    const std::uint64_t n=std::uint64_t(s.layout.theta)*s.layout.rings;
    std::vector<std::int64_t>d(std::size_t(n),-1);std::deque<std::uint64_t>q;
    for(std::uint64_t i=0;i<n;++i)if(bit(s.field,i)){d[std::size_t(i)]=0;q.push_back(i);}
    while(!q.empty()){auto i=q.front();q.pop_front();
        for(auto j:adjacent(s,i))if(bit(s.allowed,j)&&d[std::size_t(j)]<0){d[std::size_t(j)]=d[std::size_t(i)]+1;q.push_back(j);}}
    return d;
}
inline std::vector<std::int64_t> packed_arrivals(Scene s) {
    validate_wave_seed(s);const std::size_t n=std::size_t(s.layout.theta)*s.layout.rings;
    std::vector<std::int64_t>d(n,-1);std::int64_t step=0;
    while(popcount(s.op)) {
        for(std::size_t i=0;i<n;++i)if(bit(s.op,i)) {
            if(d[i]>=0)throw std::runtime_error("duplicate arrival");
            d[i]=step;
        }
        step_cpu(s,Mode::Wave);++step;
        if(std::uint64_t(step)>n)throw std::runtime_error("finite wave did not terminate");
    }
    return d;
}
} // namespace axis0
