#pragma once
// Axis 0 / Boolean Double UU. Tom Klootwijk | NL200678942 | 10-07-1990.
// 32 logical one-bit cells per unsigned 32-bit word; integer-only update math.
#include <cstdint>
#if defined(__CUDACC__)
# define A0_HD __host__ __device__ __forceinline__
#else
# define A0_HD inline
#endif
namespace axis0 {
using Word=std::uint32_t;
constexpr Word INVALID=0xffffffffu;
enum class Topology:Word { Rect=0, Polar=1, Klein=2 };
enum class Mode:Word { Wave=0, Union=1, Exchange=2, Inverse=3 };
enum class Plane:Word { Field=0, Operator=1, Allowed=2 };
struct Layout {
    Word theta,rings,row_word_log,ring_log,row_words,row_word_mask;
    Word chart_words,chart_word_mask,ring_mask,periodic_theta,bins_per_phi;
};
// Native log-polar row lookup: previous/next word offsets, seam flags,
// and exact fixed-point log_phi coordinate. NOT a dense distance lookup.
struct Row { Word prev,next,flags,log_phi_q16; };
struct Pair { Word field,op; };
static_assert(sizeof(Word)==4 && sizeof(Row)==16,"Unexpected packed ABI");
A0_HD Word mix32(Word x) {
    x^=x>>16; x*=0x7feb352du; x^=x>>15; x*=0x846ca68bu; return x^(x>>16);
}
A0_HD Word reverse_bits(Word x) {
#if defined(__CUDA_ARCH__)
    return __brev(x);
#else
    x=((x&0x55555555u)<<1)|((x>>1)&0x55555555u);
    x=((x&0x33333333u)<<2)|((x>>2)&0x33333333u);
    x=((x&0x0f0f0f0fu)<<4)|((x>>4)&0x0f0f0f0fu);
    x=((x&0x00ff00ffu)<<8)|((x>>8)&0x00ff00ffu);
    return (x<<16)|(x>>16);
#endif
}
A0_HD Word jitter_word(Word i,Word key,Word enabled) {
    return enabled?(Word{1}<<(mix32(i^key)&31u)):0u;
}
struct PointerReader {
    const Word *field,*op,*allowed; const Row* rows;
    A0_HD Word load(Plane p,Word i)const {
        return p==Plane::Field?field[i]:p==Plane::Operator?op[i]:allowed[i];
    }
    A0_HD Row row(Word rho)const {return rows[rho];}
};
template<class Reader>
A0_HD Word neighbours_or(const Reader& r,Word i,const Layout& l,Plane plane) {
    const Word col=i&l.row_word_mask,row_base=i&~l.row_word_mask;
    const Word chart_base=i&~l.chart_word_mask;
    const Row lut=r.row((i>>l.row_word_log)&l.ring_mask);
    const Word center=r.load(plane,i);
    Word left=0,right=0;
    if(col)left=r.load(plane,i-1);
    else if(l.periodic_theta)left=r.load(plane,row_base+l.row_word_mask);
    if(col!=l.row_word_mask)right=r.load(plane,i+1);
    else if(l.periodic_theta)right=r.load(plane,row_base);
    Word out=(center<<1)|(left>>31)|(center>>1)|(right<<31);
    if(lut.prev!=INVALID) {
        const Word c=(lut.flags&1u)?l.row_word_mask-col:col;
        Word x=r.load(plane,chart_base+lut.prev+c);
        out|=(lut.flags&1u)?reverse_bits(x):x;
    }
    if(lut.next!=INVALID) {
        const Word c=(lut.flags&2u)?l.row_word_mask-col:col;
        Word x=r.load(plane,chart_base+lut.next+c);
        out|=(lut.flags&2u)?reverse_bits(x):x;
    }
    return out;
}
template<Mode M,class Reader>
A0_HD Pair step_word(const Reader& r,Word i,const Layout& l,Word key=0,Word jitter=0) {
    const Word f=r.load(Plane::Field,i),o=r.load(Plane::Operator,i);
    if constexpr(M==Mode::Union)return {f|o,o};
    else if constexpr(M==Mode::Wave) {
        const Word next=neighbours_or(r,i,l,Plane::Operator)&r.load(Plane::Allowed,i)&~f;
        return {f|next,next};
    } else if constexpr(M==Mode::Exchange) {
        return {o,f^neighbours_or(r,i,l,Plane::Operator)^jitter_word(i&l.chart_word_mask,key,jitter)};
    } else {
        return {o^neighbours_or(r,i,l,Plane::Field)^jitter_word(i&l.chart_word_mask,key,jitter),f};
    }
}
A0_HD Pair dispatch(Mode m,const PointerReader& r,Word i,const Layout& l,Word key=0,Word jitter=0) {
    switch(m) {
    case Mode::Wave:return step_word<Mode::Wave>(r,i,l,key,jitter);
    case Mode::Union:return step_word<Mode::Union>(r,i,l,key,jitter);
    case Mode::Exchange:return step_word<Mode::Exchange>(r,i,l,key,jitter);
    default:return step_word<Mode::Inverse>(r,i,l,key,jitter);
    }
}
} // namespace axis0
