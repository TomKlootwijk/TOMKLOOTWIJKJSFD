#pragma once
#include "axis0/bitcore.hpp"
#include <algorithm>
#include <array>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
namespace axis0 {
inline bool power2(Word x){return x && !(x&(x-1));}
inline Word ilog2(Word x){Word n=0;while(x>>=1)++n;return n;}
inline Layout make_layout(Word theta,Word rings,Topology topo,Word bins=64) {
    if(!power2(theta)||theta<32||!power2(rings)||!power2(bins)||bins>65536)
        throw std::invalid_argument("theta must be power-of-two >=32; rings and bins-per-phi powers-of-two; bins<=65536");
    const std::uint64_t words=(std::uint64_t(theta)>>5)*rings;
    if(words>(std::uint64_t{1}<<27))throw std::invalid_argument("one chart exceeds 2^27 words; use independent charts");
    if(((std::uint64_t(rings-1)<<16)/bins)>INVALID)throw std::invalid_argument("radial log coordinate overflow");
    if(Word(topo)>2)throw std::invalid_argument("unknown topology");
    const Word rw=theta>>5;
    return {theta,rings,ilog2(rw),ilog2(rings),rw,rw-1,Word(words),Word(words-1),rings-1,Word(topo!=Topology::Rect),bins};
}
inline std::vector<Row> make_rows(const Layout& l,Topology topo) {
    std::vector<Row> rows(l.rings);
    for(Word r=0;r<l.rings;++r) {
        Row x{r?(r-1)*l.row_words:INVALID,r+1<l.rings?(r+1)*l.row_words:INVALID,0,
              Word((std::uint64_t(r)<<16)/l.bins_per_phi)};
        if(topo==Topology::Klein && r==0){x.prev=(l.rings-1)*l.row_words;x.flags|=1u;}
        if(topo==Topology::Klein && r+1==l.rings){x.next=0;x.flags|=2u;}
        rows[r]=x;
    }
    return rows;
}
inline const char* name(Topology t){return t==Topology::Rect?"rect":t==Topology::Polar?"polar":"klein";}
inline const char* name(Mode m){return m==Mode::Wave?"wave":m==Mode::Union?"union":m==Mode::Exchange?"exchange":"inverse";}
inline Topology topology_from(const std::string& s) {
    if(s=="rect")return Topology::Rect;if(s=="polar")return Topology::Polar;if(s=="klein")return Topology::Klein;
    throw std::invalid_argument("topology must be rect, polar or klein");
}
inline Mode mode_from(const std::string& s) {
    if(s=="wave")return Mode::Wave;if(s=="union")return Mode::Union;
    if(s=="exchange")return Mode::Exchange;if(s=="inverse")return Mode::Inverse;
    throw std::invalid_argument("mode must be wave, union, exchange or inverse");
}
inline bool bit(const std::vector<Word>& a,std::uint64_t i){return (a.at(std::size_t(i>>5))>>(i&31))&1u;}
inline void put(std::vector<Word>& a,std::uint64_t i,bool b=true) {
    Word& w=a.at(std::size_t(i>>5));const Word m=Word{1}<<(i&31);if(b)w|=m;else w&=~m;
}
inline std::uint64_t popcount(const std::vector<Word>& a) {
    std::uint64_t n=0;for(Word w:a)while(w){w&=w-1;++n;}return n;
}
struct Scene {
    Layout layout{};Topology topology=Topology::Polar;
    std::vector<Row> rows;std::vector<Word> allowed,field,op;
};
inline Scene blank_scene(Word theta,Word rings,Topology t,Word bins=64) {
    Scene s;s.layout=make_layout(theta,rings,t,bins);s.topology=t;s.rows=make_rows(s.layout,t);
    s.allowed.assign(s.layout.chart_words,INVALID);s.field.assign(s.layout.chart_words,0);s.op=s.field;return s;
}
inline Scene seeded_scene(Word theta,Word rings,Topology t,Word bins=64,bool dense=false) {
    Scene s=blank_scene(theta,rings,t,bins);
    if(dense)for(Word i=0;i<s.layout.chart_words;++i){s.field[i]=mix32(i^0x13579bdu);s.op[i]=mix32(i^0xa5a5a5a5u);}
    else {put(s.field,std::uint64_t(rings/2)*theta+theta/4);s.op=s.field;}
    return s;
}
inline void validate_wave_seed(const Scene& s) {
    if(s.field!=s.op)throw std::invalid_argument("a fresh wave solve requires initial field==operator (seed set)");
    for(std::size_t i=0;i<s.field.size();++i)if(s.field[i]&~s.allowed[i])throw std::invalid_argument("seed outside allowed mask");
}
inline void step_cpu(Scene& s,Mode m,Word key=0,Word jitter=0) {
    if(jitter && (m==Mode::Wave || m==Mode::Union))throw std::invalid_argument("jitter belongs to exchange/inverse");
    const PointerReader r{s.field.data(),s.op.data(),s.allowed.data(),s.rows.data()};
    std::vector<Word> f(s.field.size()),o(f.size());
    for(Word i=0;i<s.layout.chart_words;++i){Pair p=dispatch(m,r,i,s.layout,key,jitter);f[i]=p.field;o[i]=p.op;}
    s.field.swap(f);s.op.swap(o);
}
inline std::uint64_t digest(const Scene& s) {
    std::uint64_t h=1469598103934665603ull;
    for(const auto* p:{&s.allowed,&s.field,&s.op})for(Word w:*p){h^=w;h*=1099511628211ull;}return h;
}
inline Word read_le32(std::istream& in) {
    std::array<unsigned char,4>b{};in.read(reinterpret_cast<char*>(b.data()),4);
    if(!in)throw std::runtime_error("truncated input");
    return Word(b[0])|(Word(b[1])<<8)|(Word(b[2])<<16)|(Word(b[3])<<24);
}
inline void write_le32(std::ostream& out,Word x) {
    const std::array<char,4>b{char(x&255u),char((x>>8)&255u),char((x>>16)&255u),char(x>>24)};out.write(b.data(),4);
}
inline Scene read_scene(const std::string& path) {
    std::ifstream in(path,std::ios::binary);if(!in)throw std::runtime_error("cannot open scene: "+path);
    std::array<char,8> m{};in.read(m.data(),8);const std::array<char,8> magic{'A','X','I','S','0','U','4','\0'};
    if(m!=magic)throw std::runtime_error("bad AXIS0U4 magic");
    std::array<Word,8> h{};for(Word& x:h)x=read_le32(in);
    if(h[0]!=1||h[6]!=3||h[7]!=0)throw std::runtime_error("unsupported AXIS0U4 header");
    Scene s=blank_scene(h[1],h[2],Topology(h[3]),h[4]);
    if(h[5]!=s.layout.chart_words)throw std::runtime_error("word count mismatch");
    for(auto* p:{&s.allowed,&s.field,&s.op})for(Word& x:*p)x=read_le32(in);
    if(in.peek()!=std::char_traits<char>::eof())throw std::runtime_error("trailing scene data");return s;
}
inline void write_scene(const std::string& path,const Scene& s) {
    std::ofstream out(path,std::ios::binary);if(!out)throw std::runtime_error("cannot write scene");
    out.write("AXIS0U4\0",8);
    for(Word x:std::array<Word,8>{1,s.layout.theta,s.layout.rings,Word(s.topology),s.layout.bins_per_phi,s.layout.chart_words,3,0})write_le32(out,x);
    for(const auto* p:{&s.allowed,&s.field,&s.op})for(Word x:*p)write_le32(out,x);
    if(!out)throw std::runtime_error("scene write failed");
}
} // namespace axis0
