#pragma once
#include "axis0/model.hpp"
#include <charconv>
#include <chrono>
#include <iostream>
#include <sstream>
namespace axis0 {
struct Options {
    bool help=false,info=false,self_test=false,until_empty=false,verify=false;
    Mode mode=Mode::Wave;Topology topology=Topology::Polar;
    Word theta=1024,rings=256,bins=64,jitter=0,seed=19900710u;
    std::uint64_t steps=128,offset=0,charts=1;
    unsigned vram_percent=0;int device=0;
    std::string read="texture",scene,out,history,json;
};
inline std::uint64_t number(const std::string& s) {
    std::uint64_t x=0;auto p=std::from_chars(s.data(),s.data()+s.size(),x);
    if(p.ec!=std::errc()||p.ptr!=s.data()+s.size())throw std::invalid_argument("not an unsigned integer: "+s);return x;
}
inline Word number32(const std::string& s){auto x=number(s);if(x>INVALID)throw std::invalid_argument("32-bit overflow");return Word(x);}
inline Options parse(int argc,char** argv) {
    Options o;
    for(int i=1;i<argc;++i) {
        const std::string a=argv[i];
        if(a=="--help"||a=="-h"){o.help=true;continue;}if(a=="--info"){o.info=true;continue;}
        if(a=="--self-test"){o.self_test=true;continue;}if(a=="--until-empty"){o.until_empty=true;continue;}
        if(a=="--verify"){o.verify=true;continue;}
        if(i+1>=argc)throw std::invalid_argument("missing value for "+a);const std::string v=argv[++i];
        if(a=="--mode")o.mode=mode_from(v);else if(a=="--topology")o.topology=topology_from(v);
        else if(a=="--theta")o.theta=number32(v);else if(a=="--rings")o.rings=number32(v);
        else if(a=="--bins-per-phi")o.bins=number32(v);else if(a=="--jitter")o.jitter=number32(v);
        else if(a=="--seed")o.seed=number32(v);else if(a=="--steps")o.steps=number(v);
        else if(a=="--step-offset")o.offset=number(v);else if(a=="--charts")o.charts=number(v);
        else if(a=="--vram-percent")o.vram_percent=number32(v);else if(a=="--device"){auto x=number32(v);if(x>2147483647u)throw std::invalid_argument("bad device");o.device=int(x);}
        else if(a=="--read")o.read=v;else if(a=="--scene")o.scene=v;else if(a=="--out")o.out=v;
        else if(a=="--history")o.history=v;else if(a=="--json")o.json=v;
        else throw std::invalid_argument("unknown option: "+a);
    }
    if(o.read!="texture"&&o.read!="global")throw std::invalid_argument("--read must be texture or global");
    if(o.jitter>1||(o.jitter&&(o.mode==Mode::Wave||o.mode==Mode::Union)))throw std::invalid_argument("jitter 0|1 belongs to exchange/inverse only");
    if(o.until_empty&&o.mode!=Mode::Wave)throw std::invalid_argument("--until-empty belongs to wave");
    if(!o.charts||o.vram_percent>100)throw std::invalid_argument("charts must be positive; vram-percent 0..100");
    if(o.steps>std::numeric_limits<std::uint64_t>::max()-o.offset)throw std::invalid_argument("step-index overflow");
    return o;
}
inline void usage(std::ostream& os,bool gpu) {
    os<<"Axis 0 BitPolar v4.0 | Tom Klootwijk | NL200678942 | 10-07-1990\n"
      <<"Usage: "<<(gpu?"axis0_cuda":"axis0_cpu")<<" [options]\n"
      <<" --scene FILE  input AXIS0U4; overrides layout options\n"
      <<" --mode wave|union|exchange|inverse  (default wave)\n"
      <<" --theta N --rings N  powers of two; theta>=32\n"
      <<" --topology rect|polar|klein  (default polar)\n"
      <<" --bins-per-phi N  radial log_phi subdivisions, power of two <=65536\n"
      <<" --steps N  fixed updates; --until-empty  wave completion instead\n"
      <<" --jitter 0|1 --seed N --step-offset N  reversible feedback schedule\n"
      <<" --out FILE --history FILE --json FILE\n"
      <<" --verify  compare first-chart result against CPU reference\n";
    if(gpu)os<<" --read texture|global --charts N --vram-percent P\n"
             <<" --device N --info --self-test\n";
}
inline Word step_key(const Options& o,std::uint64_t n) {
    const auto index=o.offset+(o.mode==Mode::Inverse?o.steps-1-n:n);
    return mix32(o.seed^Word(index)^Word(index>>32));
}
inline Scene input_scene(const Options& o) {
    Scene s=o.scene.empty()?seeded_scene(o.theta,o.rings,o.topology,o.bins,
                 o.mode==Mode::Exchange||o.mode==Mode::Inverse||o.mode==Mode::Union):read_scene(o.scene);
    if(o.mode==Mode::Wave)validate_wave_seed(s);return s;
}
class HistoryWriter {
    std::ofstream out_;std::size_t words_=0;
public:
    HistoryWriter(const std::string& path,const Scene& s) {
        if(path.empty())return;out_.open(path,std::ios::binary);if(!out_)throw std::runtime_error("cannot write history");
        out_.write("AXIS0H4\0",8);words_=s.layout.chart_words;
        for(Word x:std::array<Word,8>{1,s.layout.theta,s.layout.rings,Word(s.topology),s.layout.bins_per_phi,s.layout.chart_words,0,0})write_le32(out_,x);
        append(s.op);
    }
    bool enabled()const{return out_.is_open();}
    void append(const std::vector<Word>& op) {
        if(!enabled())return;if(op.size()!=words_)throw std::runtime_error("history frame mismatch");
        for(Word w:op)write_le32(out_,w);if(!out_)throw std::runtime_error("history write failed");
    }
};
inline void emit(const std::string& text,const std::string& path) {
    std::cout<<text<<'\n';if(!path.empty()){std::ofstream out(path);if(!out)throw std::runtime_error("cannot write report");out<<text<<'\n';}
}
inline std::uint64_t nanos(std::chrono::steady_clock::time_point a,std::chrono::steady_clock::time_point b) {
    return std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(b-a).count());
}
inline std::string escape(const std::string& s) {
    std::string out;for(unsigned char c:s){if(c=='"'||c=='\\')out.push_back('\\');if(c>=32)out.push_back(char(c));}return out;
}
} // namespace axis0
