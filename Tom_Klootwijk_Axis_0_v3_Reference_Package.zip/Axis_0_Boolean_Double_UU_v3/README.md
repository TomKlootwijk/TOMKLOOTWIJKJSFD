# Axis 0 / Boolean double-UU - Reference package, version 3.0

Concept source: Tom Klootwijk, NL200678942, date supplied 10-07-1990.
Companion to the 23-page PDF `Tom_Klootwijk_Axis_0_Boolean_Double_UU_v3.pdf`.

## Contents

- `axis0_double_uu_reference.py`: executable profile R (rectangular grid) and
  profile C (exact nonnegative-integer-cost complete-graph TSP), decoders,
  independent verification oracles and deterministic test suite.
- `verification.json`: the output of the executed verification run.
- `README.md`: these instructions.

Python 3.10 or later is required. Only the standard library is used.

## Run

Print both worked examples:

    python axis0_double_uu_reference.py

Run all finite tests and write a fresh record:

    python axis0_double_uu_reference.py --verify --report verification_new.json

The supplied record was produced using Python 3.13.5, with random seed 20260918.
It reports PASS for 30,064 input cases, each of which may check several assertions.
The file's SHA-256 digest is recorded in the JSON so it can be matched to the code.

## Defined inputs and outputs

Profile R uses a finite rectangular, zero-exterior, four-neighbor, unit-cost grid.
A bit at index x + width*y identifies the cell (x, y). `allowed` is the fixed
allowed-cell mask and `seed` must be a subset of it. `wavefronts` yields successive
arrival frontiers and stops exactly when the frontier is empty. Collecting that
history, calculating arrival indices or retaining a decoded path uses memory in
addition to the two evolving field/operator planes.

Profile C takes a complete square matrix of nonnegative integer costs with a zero
diagonal and at least three cities. Directed/asymmetric costs are accepted. It
builds all attainable-cost bitsets for visited-subset/endpoint states; no cost
budget is truncated. `tsp_solve` returns the exact optimum, one complete optimal
closed tour, and the bitset of every attainable tour cost. The subset axis is
exponential and the cost-axis width depends on the numeric costs.

`klein_step` is an independently tested lifted east/west seam construction. The
rectangular pathfinder does not use Klein boundary conditions. The original
version 2 golden-ratio recurrence is not part of this test suite.

## Verification scope

Grid outputs are checked against an independent coordinate/queue traversal.
All attainable tour-cost sets and decoded tours are checked against complete
permutation enumeration on the stated small instances. Named examples give a
10-edge obstacle-avoiding grid path and a six-city optimum of 24, with feasible
tour-cost positions 24, 42 and 60.

The tests are finite correctness checks, not a timing, energy or FPGA benchmark.
The accompanying PDF supplies the definitions, proofs, source distinctions,
resource bounds and retained Axis 0 / SDF / T / Klein / lowercase-phi context.
