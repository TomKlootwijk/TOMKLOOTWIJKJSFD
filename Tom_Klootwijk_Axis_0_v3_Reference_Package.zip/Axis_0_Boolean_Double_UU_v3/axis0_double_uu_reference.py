"""Axis 0 / Boolean double-UU: reference constructions, version 3.0.

Concept source: Tom Klootwijk, NL200678942, date supplied 10-07-1990.
These executable profiles are proposed formal constructions accompanying the PDF.
Python 3.10+; standard library only.

Usage:
    python axis0_double_uu_reference.py
    python axis0_double_uu_reference.py --verify --report verification.json

Profile R: fixed rectangular unit-cost grid, two evolving Boolean bitplanes.
Profile C: complete graph with nonnegative integer costs; exact attainable-cost
bitsets indexed by visited subset and endpoint. It is not a two-spatial-plane TSP
solver. No budget truncation is used. Output includes a reconstructible tour.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import platform
import random
from collections import deque
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from typing import Iterator, Sequence


def bits(value: int) -> Iterator[int]:
    """Yield set-bit indices in ascending order."""
    if type(value) is not int or value < 0:
        raise ValueError("bitset must be a nonnegative integer")
    while value:
        low = value & -value
        yield low.bit_length() - 1
        value ^= low


@dataclass(frozen=True)
class Grid:
    width: int
    height: int

    def __post_init__(self) -> None:
        if any(type(v) is not int or v <= 0
               for v in (self.width, self.height)):
            raise ValueError("width and height must be positive integers")

    @cached_property
    def size(self) -> int:
        return self.width * self.height

    @cached_property
    def mask(self) -> int:
        return (1 << self.size) - 1

    @cached_property
    def left(self) -> int:
        return sum(1 << (y * self.width) for y in range(self.height))

    @cached_property
    def right(self) -> int:
        return self.left << (self.width - 1)

    def validate(self, value: int) -> None:
        if type(value) is not int or value < 0 or value & ~self.mask:
            raise ValueError("bitset has bits outside the declared grid")

    def index(self, x: int, y: int) -> int:
        if type(x) is not int or type(y) is not int:
            raise ValueError("coordinates must be integers")
        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError("coordinate outside grid")
        return x + self.width * y

    def shifts(self, b: int) -> tuple[int, int, int, int]:
        """East, west, south, north; zero exterior and no row wrapping."""
        self.validate(b)
        east = ((b & (self.mask ^ self.right)) << 1) & self.mask
        west = (b & (self.mask ^ self.left)) >> 1
        south = (b << self.width) & self.mask
        north = b >> self.width
        return east, west, south, north

    def neighbors(self, b: int) -> int:
        e, w, s, n = self.shifts(b)
        return e | w | s | n


def wavefronts(grid: Grid, allowed: int, seed: int) -> Iterator[int]:
    """Yield O_0, ..., O_D. Empty O_{D+1} is the exact completion test.

    Only F and O are evolving state planes. The yielded history is optional
    output; a caller storing it uses additional memory.
    """
    grid.validate(allowed)
    grid.validate(seed)
    if seed & ~allowed:
        raise ValueError("seed must be contained in allowed cells")
    f = o = seed
    while o:
        yield o
        new_o = grid.neighbors(o) & allowed & (grid.mask ^ f)
        f ^= new_o
        o = new_o


def arrival_indices(grid: Grid, layers: Sequence[int]) -> list[int | None]:
    """Decode optional history. None means no arrival in the supplied run."""
    distance: list[int | None] = [None] * grid.size
    for time, layer in enumerate(layers):
        grid.validate(layer)
        for v in bits(layer):
            if distance[v] is not None:
                raise ValueError("a vertex occurs in more than one frontier")
            distance[v] = time
    return distance


def shortest_grid_path(grid: Grid, layers: Sequence[int], target: int
                       ) -> list[tuple[int, int]] | None:
    if type(target) is not int or not (0 <= target < grid.size):
        raise ValueError("target index outside grid")
    d = arrival_indices(grid, layers)
    time = d[target]
    if time is None:
        return None
    v = target
    reverse_path = [v]
    while time > 0:
        candidates = grid.neighbors(1 << v) & layers[time - 1]
        if not candidates:
            raise ValueError("history has no predecessor for target")
        v = next(bits(candidates))
        reverse_path.append(v)
        time -= 1
    return [(v % grid.width, v // grid.width)
            for v in reversed(reverse_path)]


def queue_distances(grid: Grid, allowed: int, seed: int) -> list[int | None]:
    """Independent coordinate/queue implementation used only as a test oracle."""
    d: list[int | None] = [None] * grid.size
    q: deque[int] = deque()
    for v in range(grid.size):
        if (seed >> v) & 1:
            d[v] = 0
            q.append(v)
    while q:
        v = q.popleft()
        x, y = v % grid.width, v // grid.width
        for xx, yy in ((x+1, y), (x-1, y), (x, y+1), (x, y-1)):
            if not (0 <= xx < grid.width and 0 <= yy < grid.height):
                continue
            z = xx + grid.width * yy
            if (allowed >> z) & 1 and d[z] is None:
                assert d[v] is not None
                d[z] = d[v] + 1
                q.append(z)
    return d


def validate_costs(cost: Sequence[Sequence[int]]) -> tuple[tuple[int, ...], ...]:
    a = tuple(tuple(row) for row in cost)
    n = len(a)
    if n < 3 or any(len(row) != n for row in a):
        raise ValueError("complete cost matrix must be square with n >= 3")
    if any(type(v) is not int or v < 0 for row in a for v in row):
        raise ValueError("costs must be nonnegative integers")
    if any(a[i][i] != 0 for i in range(n)):
        raise ValueError("diagonal costs must be zero")
    return a


def tsp_cost_bits(cost: Sequence[Sequence[int]]
                  ) -> tuple[int, dict[tuple[int, int], int]]:
    """Return all attainable tour-cost bits and the full predecessor-state table."""
    c = validate_costs(cost)
    n, full = len(c), (1 << len(c)) - 1
    a: dict[tuple[int, int], int] = {(1, 0): 1}
    # Masks contain city 0; removing a city decreases the integer mask.
    for subset in range(1, full + 1, 2):
        if subset == 1:
            continue
        for j in range(1, n):
            if not (subset & (1 << j)):
                continue
            previous = subset ^ (1 << j)
            attainable = 0
            for i in bits(previous):
                attainable |= a.get((previous, i), 0) << c[i][j]
            a[subset, j] = attainable
    tours = 0
    for j in range(1, n):
        tours |= a[full, j] << c[j][0]
    return tours, a


def tsp_solve(cost: Sequence[Sequence[int]]) -> tuple[int, list[int], int]:
    """Exact minimum, one optimal closed tour, and every attainable cost bit."""
    c = validate_costs(cost)
    tours, a = tsp_cost_bits(c)
    optimum = (tours & -tours).bit_length() - 1
    n, full = len(c), (1 << len(c)) - 1
    endpoint = next(j for j in range(1, n)
                    if optimum >= c[j][0]
                    and ((a[full, j] >> (optimum - c[j][0])) & 1))
    subset, j = full, endpoint
    budget = optimum - c[j][0]
    reverse_path = [j]
    while subset != 1:
        previous = subset ^ (1 << j)
        for i in bits(previous):
            prior_budget = budget - c[i][j]
            if prior_budget >= 0 and ((a.get((previous, i), 0)
                                      >> prior_budget) & 1):
                subset, j, budget = previous, i, prior_budget
                reverse_path.append(i)
                break
        else:
            raise RuntimeError("no predecessor in exact state table")
    assert budget == 0
    return optimum, list(reversed(reverse_path)) + [0], tours


def brute_tour_bits(c: Sequence[Sequence[int]]) -> int:
    """Independent exhaustive permutation oracle for small instances."""
    result = 0
    for p in itertools.permutations(range(1, len(c))):
        route = (0,) + p + (0,)
        total = sum(c[u][v] for u, v in zip(route, route[1:]))
        result |= 1 << total
    return result


def klein_step(x: int, y: int, p: int, width: int, height: int,
               direction: int = 1) -> tuple[int, int, int]:
    """A cell-center east/west seam map; scalar occupancy need not flip."""
    nx = x + direction
    if nx < 0:
        return width - 1, height - 1 - y, p ^ 1
    if nx == width:
        return 0, height - 1 - y, p ^ 1
    return nx, y, p


def demo() -> dict:
    grid = Grid(7, 5)
    blocked = sum(1 << grid.index(3, y) for y in range(4))
    allowed = grid.mask ^ blocked
    seed = 1 << grid.index(0, 2)
    layers = list(wavefronts(grid, allowed, seed))
    distances = arrival_indices(grid, layers)
    trace = []
    f = 0
    for n, o in enumerate(layers):
        f |= o
        trace.append({"step": n, "frontier_hex": f"{o:09x}",
                      "reached_count": f.bit_count()})
    trace.append({"step": len(layers), "frontier_hex": "000000000",
                  "reached_count": f.bit_count()})
    costs = tuple(tuple(0 if i == j else 1 if i // 3 == j // 3 else 10
                        for j in range(6)) for i in range(6))
    best, tour, costs_bitset = tsp_solve(costs)
    return {
        "grid": {"width": 7, "height": 5, "allowed_hex": f"{allowed:09x}",
                 "seed_hex": f"{seed:09x}", "target": [6, 2],
                 "arrival_rows": [distances[y*7:(y+1)*7] for y in range(5)],
                 "shortest_path": shortest_grid_path(grid, layers, grid.index(6, 2)),
                 "distance": distances[grid.index(6, 2)], "trace": trace},
        "tsp": {"costs": costs, "optimum": best, "tour": tour,
                "attainable_costs": list(bits(costs_bitset)),
                "tour_cost_bits_hex": hex(costs_bitset),
                "disconnected_two_triangle_cost": 6}}


def verify() -> dict:
    counts: dict[str, int] = {}
    total = 0
    for f in range(32):
        for m in range(32):
            assert ((f ^ m) ^ m) == f
            total += 1
    counts["xor_involution_5_bit_pairs"] = total
    total = 0
    for f in range(32):
        for m in range(32):
            if not (f & m):
                assert (f ^ m) == (f | m)
                total += 1
    counts["disjoint_xor_equals_or_5_bit_pairs"] = total
    total = 0
    for width in range(1, 9):
        for height in range(1, 9):
            grid = Grid(width, height)
            for v in range(grid.size):
                x, y = v % width, v // width
                got = grid.shifts(1 << v)
                for actual, (xx, yy) in zip(got,
                        ((x+1, y), (x-1, y), (x, y+1), (x, y-1))):
                    expected = (1 << (xx + width*yy)
                                if 0 <= xx < width and 0 <= yy < height else 0)
                    assert actual == expected
                    total += 1
    counts["rectangular_singleton_direction_shifts"] = total

    def check_grid(grid: Grid, allowed: int, seed: int) -> None:
        layers = list(wavefronts(grid, allowed, seed))
        assert arrival_indices(grid, layers) == queue_distances(grid, allowed, seed)
        f = 0
        for o in layers:
            assert not (f & o)
            assert (f ^ o) == (f | o)
            f ^= o
            assert not (f & ~allowed)
        assert len(layers) <= grid.size
        if layers:
            assert not (grid.neighbors(layers[-1]) & allowed & ~f)
        assert not (grid.neighbors(f) & allowed & ~f)

    grid = Grid(3, 3)
    total = 0
    for cells in itertools.product(range(3), repeat=grid.size):
        # 0 blocked; 1 allowed/unseeded; 2 allowed/seeded.
        allowed = sum(1 << v for v, value in enumerate(cells) if value)
        seed = sum(1 << v for v, value in enumerate(cells) if value == 2)
        check_grid(grid, allowed, seed)
        total += 1
    counts["all_3x3_obstacle_and_seed_configurations"] = total
    rng = random.Random(20260918)
    for _ in range(600):
        grid = Grid(rng.randrange(1, 13), rng.randrange(1, 13))
        allowed = rng.getrandbits(grid.size)
        seed = rng.getrandbits(grid.size) & allowed
        check_grid(grid, allowed, seed)
    counts["random_rectangular_grid_runs"] = 600

    total = 0
    for width in range(2, 9):
        for height in range(2, 9):
            for x in range(width):
                for y in range(height):
                    for p in range(2):
                        start = x, y, p
                        once = klein_step(*start, width, height)
                        assert klein_step(*once, width, height, -1) == start
                        state = start
                        for _ in range(2 * width):
                            state = klein_step(*state, width, height)
                        assert state == start
                        total += 1
    counts["klein_lifted_seam_inverse_and_double_transport"] = total

    def check_tsp(c: Sequence[Sequence[int]]) -> None:
        optimum, route, attainable = tsp_solve(c)
        expected = brute_tour_bits(c)
        assert attainable == expected
        assert optimum == min(bits(expected))
        assert route[0] == route[-1] == 0
        assert len(route) == len(c) + 1
        assert sorted(route[:-1]) == list(range(len(c)))
        assert sum(c[u][v] for u, v in zip(route, route[1:])) == optimum

    total = 0
    for n in (3, 4):
        edges = list(itertools.combinations(range(n), 2))
        for values in itertools.product((0, 1, 2), repeat=len(edges)):
            c = [[0] * n for _ in range(n)]
            for (i, j), value in zip(edges, values):
                c[i][j] = c[j][i] = value
            check_tsp(c)
            total += 1
    counts["exhaustive_small_symmetric_integer_tsp_instances"] = total
    total = 0
    for n in range(3, 9):
        for repeat in range(20):
            c = [[0 if i == j else rng.randrange(10)
                  for j in range(n)] for i in range(n)]
            if repeat < 10:
                for i in range(n):
                    for j in range(i):
                        c[i][j] = c[j][i]
            check_tsp(c)
            total += 1
    counts["random_integer_tsp_instances_3_through_8_cities"] = total
    example = demo()
    check_tsp(example["tsp"]["costs"])
    assert example["tsp"]["optimum"] == 24
    assert example["tsp"]["attainable_costs"] == [24, 42, 60]
    assert example["grid"]["distance"] == 10
    assert len(example["grid"]["shortest_path"]) - 1 == 10
    # Two arrivals at the center cancel with XOR but not OR.
    grid = Grid(3, 1)
    east, west, _, _ = grid.shifts(0b101)
    assert (east ^ west) == 0 and (east | west) == 0b010
    # The two orientations of a 3-city equal-cost tour cancel with XOR.
    assert ((1 << 3) ^ (1 << 3)) == 0
    assert ((1 << 3) | (1 << 3)) == (1 << 3)
    counts["named_examples_and_cancellation_cases"] = 4
    return {"status": "PASS", "python": platform.python_version(),
            "random_seed": 20260918, "families": counts,
            "case_count": sum(counts.values()),
            "case_definition": "One listed input case per family; each case may check multiple assertions.",
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "demonstrations": example,
            "scope": "Exact finite correctness tests; not a hardware or runtime benchmark; v2 golden-ratio recurrence not rerun."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = verify() if args.verify else demo()
    text = json.dumps(result, indent=2)
    if args.report is not None:
        args.report.write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
