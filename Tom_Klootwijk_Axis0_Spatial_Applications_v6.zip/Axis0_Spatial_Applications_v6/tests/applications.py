#!/usr/bin/env python3
"""Independent finite tests for the source-mapped application suite."""
from __future__ import annotations
import argparse,copy,itertools,json,random,subprocess,sys,time
from collections import deque
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'python'))
from axis0.model import Grid,Field,Definition,RULES,U32,shift
from axis0.kernel import Kernel,job_bytes
from axis0.routing import wave,Edge,network_route,exact_tour,time_route
from axis0.crowd import Node,simulate,replay_occupancy
from axis0.interfaces import lattice_gas_step,event_timing,certify_corridor
from axis0.ledger import Ledger

def oracle_shift(f:Field,d:int)->set[int]:
    return {j for i in f.active() if (j:=f.grid.neighbor(i,d)) is not None}
def oracle_wave(grid:Grid,blocked:set[int],seeds:set[int]):
    q=deque(sorted(seeds));dist={s:0 for s in seeds}
    while q:
        i=q.popleft()
        for j in grid.neighbors(i):
            if j not in blocked and j not in dist:dist[j]=dist[i]+1;q.append(j)
    return dist

def network_oracle(edges:list[Edge],start:int,goal:int,horizon:int=80):
    layers=[set() for _ in range(horizon+1)];layers[0].add(start)
    for t in range(horizon+1):
        if goal in layers[t]:return t
        for u in list(layers[t]):
            if t<horizon:layers[t+1].add(u)
            for e in edges:
                if e.source!=u:continue
                delay,up=e.at(t)
                if up and t+delay<=horizon:layers[t+delay].add(e.target)
    return None

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--backend',default='cpu',choices=('cpu','texture','global','shared'));p.add_argument('--json',type=Path);p.add_argument('--quick',action='store_true');a=p.parse_args()
    start=time.perf_counter_ns();rng=random.Random(20260918);counts={}
    with Kernel(a.kernel,a.backend) as kernel:
        # 3^9 occupancy/seed assignments; blocked padding leaves exactly 3x3 active domain.
        g=Grid(32,4);inside={g.cell(x,y) for y in range(3) for x in range(3)};outside=set(range(g.cells))-inside
        limit=243 if a.quick else 19683
        for code in range(limit):
            v=code;allowed=set();seeds=set()
            for cell in sorted(inside):
                status=v%3;v//=3
                if status:allowed.add(cell)
                if status==2:seeds.add(cell)
            closed=outside|(inside-allowed);result=wave(kernel,Field.from_cells(g,closed),seeds)
            assert result.distances==oracle_wave(g,closed,seeds)
            for target in result.distances:
                path=result.path(target)
                assert len(path)-1==result.distances[target] and path[0] in seeds
        counts['exhaustive_3x3_allowed_seed_cases']=limit
        stencil_cases=0;source_cases=0
        for topo in ('rect','polar','klein'):
            for w,h in ((32,1),(64,2),(128,7)):
                g=Grid(w,h)
                for trial in range(12):
                    cells={i for i in range(g.cells) if rng.randrange(8)==0};other={i for i in range(g.cells) if rng.randrange(9)==0};block={i for i in range(g.cells) if rng.randrange(11)==0}
                    f=Field.from_cells(g,cells);o=Field.from_cells(g,other);b=Field.from_cells(g,block)
                    for d in range(4):
                        rule=Definition('literal',1,RULES['literal'].table,0,1<<d)
                        output,_,_=kernel.stencil(f,o,b,rule)
                        assert set(output.active())==cells.symmetric_difference(oracle_shift(o,d));source_cases+=1
                    for name in ('wave','boundary','dilate','erode'):
                        op=o if name=='wave' else f
                        nxt,expression,delta=kernel.stencil(f,op,b,name)
                        transported=[oracle_shift(op,d) for d in range(4)]
                        any_cells=set.union(*transported);every=set.intersection(*transported)
                        if name=='wave':expected=cells|((any_cells-block)-cells)
                        elif name=='boundary':expected=(cells-every)|(any_cells-cells)
                        elif name=='dilate':expected=(cells|any_cells)-block
                        else:expected=(cells&every)-block
                        assert set(nxt.active())==expected
                        assert f.xor(delta).words==nxt.words;stencil_cases+=1
        counts['literal_shift_cases']=source_cases;counts['stencil_profile_cases']=stencil_cases
        # Arbitrary calibrated maps include drops and collisions; result is Boolean OR, not XOR.
        for trial in range(96):
            g=Grid(64,8);active=set(rng.sample(range(g.cells),70));mapping={i:rng.randrange(g.cells) for i in rng.sample(range(g.cells),200)}
            result=kernel.remap(Field.from_cells(g,active),mapping)
            assert set(result.active())=={mapping[i] for i in active if i in mapping}
        counts['calibration_lookup_cases']=96
        # Proposal oracle and whole-crowd invariants, with synthetic per-node periods.
        slow=None
        for trial in range(40):
            g=Grid(32,4);open_cells={g.cell(x,1) for x in range(1,32)};b=Field.from_cells(g,set(range(g.cells))-open_cells)
            starts=rng.sample(list(range(1,27)),6)
            nodes=[Node(i+1,g.cell(x,1),rng.randint(1,4),rng.randint(0,3),i+1) for i,x in enumerate(starts)]
            result,ledger=simulate(kernel,b,[g.cell(31,1)],nodes,240)
            assert result['remaining']==0 and result['evacuated']==6
            replay=replay_occupancy(ledger);assert replay['evacuated']==6
            altered=copy.deepcopy(ledger.records);altered[-1]['event']['tick']+=1
            assert not Ledger.verify(altered,ledger.previous)
        counts['delayed_crowd_scenarios']=40
        g=Grid(32,1);b=Field(g);nodes=[Node(1,28,1000),Node(2,29,1500),Node(3,30,2000)]
        slow,ledger=simulate(kernel,b,[31],nodes,10000)
        assert slow['evacuated']==3 and slow['empty_integer_ticks_skipped_between_events']>4000
        counts['event_gap_skip_scenarios']=1
        # Particle-number conservation and identical cellular rules; no continuous-fluid claims.
        for trial in range(16):
            g=Grid(32,8);block={g.cell(x,y) for y in range(8) for x in range(32) if x in (0,31) or y in (0,7)}
            b=Field.from_cells(g,block);allowed=list(set(range(g.cells))-block)
            channels=[Field.from_cells(g,rng.sample(allowed,20)) for _ in range(4)]
            for _ in range(12):channels=lattice_gas_step(kernel,channels,b)
            assert sum(c.count() for c in channels)==80
        counts['cellular_gas_scenarios']=16
        kernel_metrics=kernel.metrics()
    tour_cases=0
    for m in range(2,8):
        for trial in range(12):
            costs=[[0 if i==j else (None if rng.randrange(7)==0 else rng.randrange(1,10)) for j in range(m)] for i in range(m)]
            values=[]
            for perm in itertools.permutations(range(1,m)):
                route=(0,*perm,0);weights=[costs[x][y] for x,y in zip(route,route[1:])]
                if all(x is not None for x in weights):values.append(sum(weights))
            result=exact_tour(costs)
            assert result['feasible']==bool(values)
            if values:
                assert result['cost']==min(values) and result['attainable_closed_tour_costs']==sorted(set(values))
                route=result['tour'];assert route[0]==route[-1]==0 and set(route[:-1])==set(range(m)) and len(route)==m+1
                assert sum(costs[x][y] for x,y in zip(route,route[1:]))==result['cost']
            tour_cases+=1
    counts['TSP_graphs_vs_complete_tour_enumeration']=tour_cases
    for trial in range(120):
        n=5;edges=[]
        for i in range(n):
            for j in range(n):
                if i!=j and rng.randrange(3):edges.append(Edge(i,j,tuple((t,rng.randint(1,7),rng.randrange(4)!=0) for t in (0,4,9))))
        result=network_route(edges,0,4)
        assert result['arrival']==network_oracle(edges,0,4)
    counts['network_latency_event_graphs']=120
    for trial in range(80):
        lat={k:rng.randrange(20000) for k in ('visual','left','right')};offsets={'visual':0,'left':0,'right':rng.randrange(-500,501)}
        result=event_timing([0,500000],lat,offsets)
        for event in result['events']:
            base=event['delivery_reference_us']
            for key in lat:assert event['predicted_delivery_us'][key]==base+offsets[key] and event['command_times_us'][key]>=event['input_event_us']
    counts['synthetic_timestamp_alignment_cases']=80
    g=Grid(1024,1);certificate=certify_corridor(g,Field(g),list(range(1024)));assert certificate['duration_ticks']==1023
    try:certify_corridor(g,Field.from_cells(g,[512]),list(range(1024)))
    except ValueError:pass
    else:raise AssertionError('blocked corridor was incorrectly certified')
    counts['corridor_gap_cases']=2
    report={'status':'PASS','source_document_pages':31,'backend':a.backend,'gpu_executed':a.backend!='cpu',
            'counts':counts,'slow_clock_crowd':slow,'kernel_bridge_metrics':kernel_metrics,
            'elapsed_host_ns':time.perf_counter_ns()-start,
            'interpretation':'finite implementation tests, not demonstrations of biological response, cryptographic consensus, instantaneous TSP or real-world crowd fidelity'}
    text=json.dumps(report,indent=2);print(text)
    if a.json:a.json.write_text(text+'\n',encoding='utf-8')
if __name__=='__main__':main()
