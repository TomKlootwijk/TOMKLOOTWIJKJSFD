#!/usr/bin/env python3
"""Generate real spatial jobs: constant active support in larger worlds; 10k movers."""
from __future__ import annotations
import argparse,json,random,struct,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'python'))
from axis0.model import Grid,Field,RULES,neighborhood
from axis0.kernel import Kernel,job_bytes
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True);p.add_argument('--out',type=Path,default=ROOT/'verification/scaling');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
rng=random.Random(20260918);template={y*32+x:rng.getrandbits(32) for y in range(16,32) for x in range(8,16)}
results=[]
with Kernel(a.kernel) as kernel:
    previous=None
    for height in (64,4096,1048576):
        g=Grid(1024,height);f=Field(g,template.copy());tasks=sorted(neighborhood(f).words)
        raw=job_bytes(1,g,RULES['wave'],field=f,operator=f,tasks=tasks)
        path=a.out/f'empty_space_{g.cells}.job';path.write_bytes(raw)
        out=kernel.execute(raw)
        if previous is not None:assert out==previous
        previous=out
        results.append({'domain_cells':g.cells,'dense_one_bit_plane_bytes':g.cells//8,'active_words':len(f.words),
                        'active_cells':f.count(),'candidate_words':len(tasks),'job_bytes':len(raw),
                        'output_unchanged_when_implicit_zero_domain_grows':True,'job_file':path.name})
    g=Grid(1024,256);cells=[g.cell(1+4*(i%250),1+4*(i//250)) for i in range(10000)]
    f=Field.from_cells(g,cells);nav={c:1023-c%1024 for cell in cells for c in [cell,*g.neighbors(cell)]}
    nodes=[[i,cell,1,i,0,0,0,0] for i,cell in enumerate(cells)]
    raw=job_bytes(2,g,RULES['crowd'],field=f,navigation=nav,nodes=nodes,tick=0)
    path=a.out/'ten_thousand_movers.job';path.write_bytes(raw)
    begin=time.perf_counter_ns();output=kernel.execute(raw);elapsed=time.perf_counter_ns()-begin
    assert len(output)==10000
    for ident,old,target,kind in output:assert old==cells[ident] and target==old+1 and kind==1
    assert len({target for ident,old,target,kind in output})==10000
    report={'status':'PASS','backend':'CPU','implicit_zero_cases':results,
            'active_crowd_batch':{'nodes':10000,'proposal_targets_verified':10000,'duplicate_targets':0,
            'elapsed_bridge_ns':elapsed,'job_bytes':len(raw),'navigation_entries':len(nav),
            'active_occupancy_words':len(f.words),'scope':'one simultaneous move-proposal batch on a synthetic empty corridor layout; not a full 10k evacuation or validated human model'}}
(a.out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
