#include "axis0/core.hpp"
#include <iostream>
#include <random>
#include <stdexcept>
int main(){using namespace axis0;try{
    std::uint64_t checks=0;std::mt19937 random(20260918u);
    for(Word table=0;table<65536;++table){Word a=0xaaaaaaaau,b=0xccccccccu,c=0xf0f0f0f0u,d=0xff00ff00u;Word out=truth4(a,b,c,d,table);
        for(Word bit=0;bit<32;++bit){Word row=((a>>bit)&1)|(((b>>bit)&1)<<1)|(((c>>bit)&1)<<2)|(((d>>bit)&1)<<3);if(((out>>bit)&1)!=((table>>row)&1))throw std::runtime_error("truth mismatch");++checks;}}
    for(unsigned i=0;i<10000;++i){Word a=random();if(reverse_bits(reverse_bits(a))!=a)throw std::runtime_error("bit reversal mismatch");}
    std::cout<<"{\"status\":\"PASS\",\"truth4_lane_assertions\":"<<checks<<",\"reversal_cases\":10000,\"gpu_executed\":false}\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
