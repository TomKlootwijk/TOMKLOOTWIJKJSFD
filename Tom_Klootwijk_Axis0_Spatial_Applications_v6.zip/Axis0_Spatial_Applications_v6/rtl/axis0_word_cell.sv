// Source-derived word cell: field + operator in 32 parallel one-bit positions.
// Not synthesized/tested in the delivery environment. No device power claim.
module axis0_word_cell #(
    parameter integer WIDTH = 32
)(
    input  logic clk,
    input  logic reset,
    input  logic event_valid,
    input  logic [WIDTH-1:0] seed_field,
    input  logic [WIDTH-1:0] operator_field,
    input  logic [WIDTH-1:0] shift_destination_valid,
    output logic [WIDTH-1:0] field_state,
    output logic [WIDTH-1:0] expressed_delta
);
    // A full design must supply row boundaries, direction and its event scheduler.
    always_comb expressed_delta = (operator_field >> 1) & shift_destination_valid;
    always_ff @(posedge clk) begin
        if (reset) field_state <= seed_field;
        else if (event_valid) field_state <= field_state ^ expressed_delta;
    end
endmodule
