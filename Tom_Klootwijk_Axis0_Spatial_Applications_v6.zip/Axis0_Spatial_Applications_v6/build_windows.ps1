param([string]$Arch = "120")
$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DAXIS0_ENABLE_CUDA=ON "-DAXIS0_CUDA_ARCH=$Arch"
    if ($LASTEXITCODE -ne 0) { throw "Configure failed; check CUDA toolkit and Visual Studio integration." }
    cmake --build build --config Release --parallel
    if ($LASTEXITCODE -ne 0) { throw "Build failed." }
    ctest --test-dir build -C Release --output-on-failure
    if ($LASTEXITCODE -ne 0) { throw "CPU truth tests failed." }
    Write-Host "Next: python tests\applications.py --kernel build\Release\axis0_cuda.exe --backend texture --quick --json verification\laptop_quick.json"
} finally { Pop-Location }
