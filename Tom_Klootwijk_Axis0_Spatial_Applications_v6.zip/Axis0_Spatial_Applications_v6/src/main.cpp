#include "axis0/job.hpp"
#include <chrono>
#include <iostream>
#include <sstream>
#if defined(_WIN32)
#include <fcntl.h>
#include <io.h>
#endif
int main(int argc, char** argv) {
    using namespace axis0;
    try {
        bool serve = false; std::string input, output, report; unsigned repeat = 1;
        for (int i = 1; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "--serve") { serve = true; continue; }
            if (a == "--help") { std::cout << "axis0_cpu --serve | --job FILE --out FILE [--repeat N --report FILE]\n"; return 0; }
            if (i + 1 >= argc) throw std::invalid_argument("missing argument");
            std::string v = argv[++i];
            if (a == "--job") input = v; else if (a == "--out") output = v;
            else if (a == "--report") report = v;
            else if (a == "--repeat") { if (v.empty() || v.find_first_not_of("0123456789") != std::string::npos) throw std::invalid_argument("bad repeat"); std::size_t used = 0; auto n = std::stoul(v, &used); if (used != v.size() || !n || n > NONE) throw std::invalid_argument("bad repeat"); repeat = unsigned(n); }
            else throw std::invalid_argument("unknown argument: " + a);
        }
        if (serve) {
#if defined(_WIN32)
            _setmode(_fileno(stdin), _O_BINARY); _setmode(_fileno(stdout), _O_BINARY);
#endif
            while (std::cin.peek() != std::char_traits<char>::eof()) {
                Job job = read_job(std::cin); write_output(std::cout, run_cpu(job));
            }
            return 0;
        }
        if (input.empty() || output.empty()) throw std::invalid_argument("job and output paths required");
        std::ifstream in(input, std::ios::binary); if (!in) throw std::runtime_error("cannot open job");
        Job job = read_job(in); std::vector<Output> result;
        auto begin = std::chrono::steady_clock::now();
        for (unsigned i = 0; i < repeat; ++i) result = run_cpu(job);
        auto end = std::chrono::steady_clock::now();
        std::ofstream out(output, std::ios::binary); if (!out) throw std::runtime_error("cannot open output");
        write_output(out, result);
        if (!report.empty()) {
            std::ofstream f(report); if (!f) throw std::runtime_error("cannot write report");
            f << "{\"backend\":\"CPU\",\"task_count\":" << job.count << ",\"repeat\":" << repeat
              << ",\"elapsed_ns\":" << std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin).count()
              << ",\"input_bytes\":" << job.data.size() * 4 << ",\"gpu_executed\":false}\n";
        }
        return 0;
    } catch (const std::exception& e) { std::cerr << "axis0_cpu: " << e.what() << '\n'; return 1; }
}
