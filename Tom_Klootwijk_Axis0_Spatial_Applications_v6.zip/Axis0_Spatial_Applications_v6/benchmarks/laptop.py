#!/usr/bin/env python3
"""Compare real CUDA backends on the same immutable spatial job."""
import argparse,json,statistics,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--exe',type=Path,required=True);p.add_argument('--job',type=Path,required=True);p.add_argument('--repeat',type=int,default=100);p.add_argument('--samples',type=int,default=5);p.add_argument('--out',type=Path,default=Path('laptop_benchmark.json'));a=p.parse_args()
if a.repeat<1 or a.samples<1:p.error('repeat/samples must be positive')
exe=str(a.exe.resolve());info=json.loads(subprocess.check_output([exe,'--info'],text=True))
report={'device':info,'job':str(a.job),'scope':'same immutable sparse snapshot; resident launch/completion time only, NOT end-to-end application throughput','backends':{}}
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp);expected=None
    for backend in ('texture','global','shared'):
        samples=[]
        for sample in range(a.samples+1):
            out=tmp/'result.bin';metrics=tmp/'metrics.json'
            subprocess.run([exe,'--job',str(a.job.resolve()),'--out',str(out),'--backend',backend,'--repeat',str(a.repeat),'--verify','--report',str(metrics)],check=True)
            raw=out.read_bytes()
            if expected is None:expected=raw
            if raw!=expected:raise AssertionError('backend mismatch')
            if sample:samples.append(json.loads(metrics.read_text()))
        report['backends'][backend]={'samples':samples,'median_ns':int(statistics.median(x['resident_launch_completion_ns'] for x in samples))}
        a.out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(a.out),'status':'PASS','gpu_executed':True}))
