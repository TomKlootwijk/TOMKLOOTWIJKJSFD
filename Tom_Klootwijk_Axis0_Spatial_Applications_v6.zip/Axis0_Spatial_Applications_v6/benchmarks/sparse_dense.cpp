// After-the-fact representation benchmark: one Boolean first-arrival transition.
// Not part of the application kernel; no renderer or floating-distance comparison.
#include "axis0/job.hpp"
#include <chrono>
#include <iostream>
#include <sstream>
using namespace axis0;
std::uint64_t now_ns(){return std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());}
std::uint64_t median(std::vector<std::uint64_t> v){std::sort(v.begin(),v.end());return v[v.size()/2];}
void dense(const std::vector<Word>& f,const std::vector<Word>& o,std::vector<Word>& next,const Layout& l){
    for(Word i=0;i<l.words;++i){Word col=i%l.row_words,row=i/l.row_words;
        Word left=col?o[i-1]:0,right=col+1<l.row_words?o[i+1]:0;
        Word candidate=(o[i]<<1)|(left>>31)|(o[i]>>1)|(right<<31);
        if(row)candidate|=o[i-l.row_words];if(row+1<l.height)candidate|=o[i+l.row_words];
        next[i]=f[i]|candidate;
    }
}
std::string samples(const std::vector<std::uint64_t>& v){std::ostringstream s;s<<'[';for(std::size_t i=0;i<v.size();++i){if(i)s<<',';s<<v[i];}return s.str()+']';}
int main(int argc,char**argv){try{
    if(argc!=3)throw std::invalid_argument("usage: sparse_dense PACKAGE_DIRECTORY REPORT_JSON");
    std::string base=argv[1];std::ostringstream report;report<<"{\"method\":\"post-hoc CPU-only single Boolean transition; allocation and initial expansion excluded; outputs verified\",\"repetitions\":7,\"cases\":[";
    bool first=true;
    for(const char* cells:{"65536","4194304","1073741824"}){
        std::ifstream in(base+"/verification/scaling/empty_space_"+cells+".job",std::ios::binary);if(!in)throw std::runtime_error("missing scaling fixture");Job job=read_job(in);
        if(job.layout.topology!=Rectangle||job.layout.nb)throw std::runtime_error("benchmark fixture must be unblocked rectangle");
        std::vector<Word>f(job.layout.words,0),o(f.size(),0),next(f.size(),0);
        for(Word i=0;i<job.layout.nf;++i)f[job.data[job.layout.f_offset+2*i]]=job.data[job.layout.f_offset+2*i+1];
        for(Word i=0;i<job.layout.no;++i)o[job.data[job.layout.o_offset+2*i]]=job.data[job.layout.o_offset+2*i+1];
        auto reference=run_cpu(job);auto expected=f;for(auto row:reference)expected[row.key]=row.value;
        dense(f,o,next,job.layout);if(next!=expected)throw std::runtime_error("dense/sparse outputs disagree");
        std::vector<std::uint64_t>sparse_times,dense_times;std::uint64_t checksum=0;
        for(unsigned rep=0;rep<7;++rep){
            auto a=now_ns();for(unsigned k=0;k<128;++k){auto value=run_cpu(job);checksum+=value.empty()?0:value[0].value;}auto b=now_ns();sparse_times.push_back((b-a)/128);
            a=now_ns();dense(f,o,next,job.layout);b=now_ns();dense_times.push_back(b-a);if(next!=expected)throw std::runtime_error("repeat mismatch");
        }
        if(!first)report<<',';first=false;
        report<<"{\"domain_cells\":"<<job.layout.cells<<",\"active_words\":"<<job.layout.nf<<",\"sparse_tasks\":"<<job.count<<",\"serialized_sparse_job_bytes\":"<<job.data.size()*4<<",\"dense_work_planes_bytes\":"<<std::uint64_t(job.layout.words)*12<<",\"sparse_median_ns\":"<<median(sparse_times)<<",\"dense_median_ns\":"<<median(dense_times)<<",\"sparse_samples_ns\":"<<samples(sparse_times)<<",\"dense_samples_ns\":"<<samples(dense_times)<<",\"output_agreement\":true,\"checksum\":"<<checksum<<'}';
    }
    report<<"],\"scope\":\"One sparse-active step, not a complete route. Sparse setup/task discovery and host Python work excluded. Dense baseline specialized for unblocked rect grids. No GPU result.\"}\n";
    std::ofstream out(argv[2]);if(!out)throw std::runtime_error("cannot write report");out<<report.str();std::cout<<report.str();return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
