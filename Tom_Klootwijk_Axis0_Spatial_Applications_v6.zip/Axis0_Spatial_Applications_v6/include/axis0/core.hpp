#pragma once
// Tom Klootwijk / NL200678942 / date supplied 10-07-1990.
// Source-specific spatial applications, v6.0. CPU and CUDA share these rules.
// Logical state is Boolean; addresses, durations and priorities are integer metadata.
#include <cstdint>
#if defined(__CUDACC__)
# define A0_HD __host__ __device__ __forceinline__
#else
# define A0_HD inline
#endif
namespace axis0 {
using Word = std::uint32_t;
using Tick = std::uint64_t;
constexpr Word NONE = 0xffffffffu;
constexpr Word MAGIC = 0xa6062026u;
constexpr Word HEADER_WORDS = 16, RECORD_WORDS = 16, PREFIX_WORDS = 48;
enum JobKind : Word { Stencil = 1, CrowdProposal = 2, Remap = 3 };
enum Topology : Word { Rectangle = 0, LogPolar = 1, KleinSeam = 2 };
enum Direction : Word { East = 0, West = 1, North = 2, South = 3 };
enum HeaderIndex : Word {
    HMagic, HVersion, HKind, HWidth, HHeight, HTopology,
    HFCount, HOCount, HBCount, HNavCount, HNodeCount,
    HTaskCount, HMapCount, HWords, HTickLow, HTickHigh
};
struct Pair { Word key, value; };
struct Output { Word key, value, delta, aux; };
static_assert(sizeof(Pair) == 8 && sizeof(Output) == 16, "Unexpected ABI");
struct Layout {
    Word width, height, topology, row_words, cells, words;
    Word nf, no, nb, nn, nodes, tasks, maps;
    Word f_offset, o_offset, b_offset, nav_offset, node_offset, task_offset, map_offset;
    Tick tick;
};
struct PointerReader {
    const Word* data;
    A0_HD Word read(Word address) const { return data[address]; }
};
A0_HD Word choose(Word zero, Word one, Word condition) {
    return zero ^ ((zero ^ one) & condition);
}
A0_HD Word bitmask(Word bit) { return Word(0) - (bit & 1u); }
A0_HD Word truth3(Word a, Word b, Word c, Word table) {
    Word x0 = choose(bitmask(table), bitmask(table >> 1), a);
    Word x1 = choose(bitmask(table >> 2), bitmask(table >> 3), a);
    Word x2 = choose(bitmask(table >> 4), bitmask(table >> 5), a);
    Word x3 = choose(bitmask(table >> 6), bitmask(table >> 7), a);
    return choose(choose(x0, x1, b), choose(x2, x3, b), c);
}
A0_HD Word truth4(Word a, Word b, Word c, Word d, Word table) {
    return choose(truth3(a, b, c, table & 255u), truth3(a, b, c, table >> 8), d);
}
A0_HD Word reverse_bits(Word x) {
#if defined(__CUDA_ARCH__)
    return __brev(x);
#else
    x = ((x & 0x55555555u) << 1) | ((x >> 1) & 0x55555555u);
    x = ((x & 0x33333333u) << 2) | ((x >> 2) & 0x33333333u);
    x = ((x & 0x0f0f0f0fu) << 4) | ((x >> 4) & 0x0f0f0f0fu);
    x = ((x & 0x00ff00ffu) << 8) | ((x >> 8) & 0x00ff00ffu);
    return (x << 16) | (x >> 16);
#endif
}
template<class Reader>
A0_HD Word lookup(const Reader& r, Word offset, Word count, Word key, Word missing = 0) {
    Word lo = 0, hi = count;
    while (lo < hi) {
        Word mid = lo + ((hi - lo) >> 1);
        if (r.read(offset + 2 * mid) < key) lo = mid + 1;
        else hi = mid;
    }
    return lo < count && r.read(offset + 2 * lo) == key
        ? r.read(offset + 2 * lo + 1) : missing;
}
template<class Reader>
A0_HD Word cell_bit(const Reader& r, Word offset, Word count, Word cell) {
    return (lookup(r, offset, count, cell >> 5) >> (cell & 31u)) & 1u;
}
template<class Reader>
A0_HD Word shifted(const Reader& r, const Layout& l, Word key, Word direction) {
    const Word col = key % l.row_words, row = key / l.row_words;
    Word center = lookup(r, l.o_offset, l.no, key), neighbor = 0;
    if (direction == East) {
        if (col) neighbor = lookup(r, l.o_offset, l.no, key - 1);
        else if (l.topology != Rectangle)
            neighbor = lookup(r, l.o_offset, l.no, key + l.row_words - 1);
        return (center << 1) | (neighbor >> 31);
    }
    if (direction == West) {
        if (col + 1 < l.row_words) neighbor = lookup(r, l.o_offset, l.no, key + 1);
        else if (l.topology != Rectangle)
            neighbor = lookup(r, l.o_offset, l.no, key - col);
        return (center >> 1) | (neighbor << 31);
    }
    // North shifts toward smaller row indices; South toward larger indices.
    if (direction == North) {
        if (row + 1 < l.height) return lookup(r, l.o_offset, l.no, key + l.row_words);
        if (l.topology == KleinSeam)
            return reverse_bits(lookup(r, l.o_offset, l.no, l.row_words - 1 - col));
        return 0;
    }
    if (row) return lookup(r, l.o_offset, l.no, key - l.row_words);
    if (l.topology == KleinSeam)
        return reverse_bits(lookup(r, l.o_offset, l.no,
            (l.height - 1) * l.row_words + l.row_words - 1 - col));
    return 0;
}
A0_HD Word neighbor_cell(Word cell, Word direction, const Layout& l) {
    Word x = cell % l.width, y = cell / l.width;
    if (direction == East) {
        if (x + 1 < l.width) return cell + 1;
        return l.topology != Rectangle ? y * l.width : NONE;
    }
    if (direction == West) {
        if (x) return cell - 1;
        return l.topology != Rectangle ? y * l.width + l.width - 1 : NONE;
    }
    if (direction == North) {
        if (y) return cell - l.width;
        return l.topology == KleinSeam
            ? (l.height - 1) * l.width + l.width - 1 - x : NONE;
    }
    if (y + 1 < l.height) return cell + l.width;
    return l.topology == KleinSeam ? l.width - 1 - x : NONE;
}
template<class Reader>
A0_HD Output stencil(const Reader& r, const Layout& l, Word task, const Word* definition) {
    Word key = r.read(l.task_offset + task);
    Word field = lookup(r, l.f_offset, l.nf, key);
    Word any = 0, every = NONE;
    for (Word direction = 0; direction < 4; ++direction) {
        if (definition[3] & (1u << direction)) {
            Word v = shifted(r, l, key, direction);
            any |= v; every &= v;
        }
    }
    Word allowed = ~lookup(r, l.b_offset, l.nb, key);
    Word expression = truth4(field, any, every, allowed, definition[1]);
    // The literal profile supplies a delta; derived profiles may supply a next field.
    Word next = definition[2] == 0 ? field ^ expression : expression;
    return {key, next, field ^ next, expression};
}
template<class Reader>
A0_HD Output propose(const Reader& r, const Layout& l, Word task, const Word* definition) {
    Word start = l.node_offset + task * 8;
    Word id = r.read(start), from = r.read(start + 1);
    Tick due = Tick(r.read(start + 4)) | (Tick(r.read(start + 5)) << 32);
    if (due > l.tick) return {id, from, from, 0};
    Word current = lookup(r, l.nav_offset, l.nn, from, NONE);
    if (current == 0) return {id, from, from, 2}; // already at an exit
    Word best = NONE, best_cost = NONE;
    for (Word direction = 0; direction < 4; ++direction) {
        if (!(definition[3] & (1u << direction))) continue;
        Word to = neighbor_cell(from, direction, l);
        if (to == NONE) continue;
        Word distance = lookup(r, l.nav_offset, l.nn, to, NONE);
        Word lower = bitmask(distance < current);
        Word empty = bitmask(!cell_bit(r, l.f_offset, l.nf, to));
        Word open = bitmask(!cell_bit(r, l.b_offset, l.nb, to));
        if (!(truth3(lower, empty, open, definition[4]) & 1u)) continue;
        if (distance < best_cost || (distance == best_cost && to < best)) {
            best = to; best_cost = distance;
        }
    }
    return best == NONE ? Output{id, from, from, 0} : Output{id, from, best, 1};
}
template<class Reader>
A0_HD Output remap(const Reader& r, const Layout& l, Word task, const Word* definition) {
    Word source = r.read(l.task_offset + task);
    Word target = lookup(r, l.map_offset, l.maps, source, NONE);
    Word valid = target != NONE && target < l.cells;
    Word active = cell_bit(r, l.f_offset, l.nf, source);
    Word accepted = truth3(bitmask(active), bitmask(valid), 0, definition[4]) & 1u;
    return {source, target, accepted, 0};
}
template<class Reader>
A0_HD Output evaluate(const Reader& r, const Layout& l, Word kind, Word task, const Word* definition) {
    if (kind == Stencil) return stencil(r, l, task, definition);
    if (kind == CrowdProposal) return propose(r, l, task, definition);
    return remap(r, l, task, definition);
}
} // namespace axis0
