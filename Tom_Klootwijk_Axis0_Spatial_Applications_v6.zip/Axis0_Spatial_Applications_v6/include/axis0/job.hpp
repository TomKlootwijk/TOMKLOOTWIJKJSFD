#pragma once
#include "axis0/core.hpp"
#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
namespace axis0 {
struct Job {
    std::vector<Word> data;
    Layout layout{};
    Word kind = 0, count = 0;
    const Word* definition() const { return data.data() + 16; }
    void validate() {
        if (data.size() < PREFIX_WORDS || data[HMagic] != MAGIC || data[HVersion] != 6 ||
            data[HWords] != data.size()) throw std::runtime_error("invalid v6 job header");
        kind = data[HKind];
        if (kind < Stencil || kind > Remap) throw std::runtime_error("unknown application kernel");
        Word w = data[HWidth], h = data[HHeight];
        if (w < 32 || (w & (w - 1)) || !h || std::uint64_t(w) * h >= NONE || data[HTopology] > 2)
            throw std::runtime_error("layout: power-of-two width >=32, positive height, cells<UINT32_MAX");
        layout = {w, h, data[HTopology], w / 32, Word(std::uint64_t(w) * h), w / 32 * h,
            data[HFCount], data[HOCount], data[HBCount], data[HNavCount], data[HNodeCount],
            data[HTaskCount], data[HMapCount], 0, 0, 0, 0, 0, 0, 0,
            Tick(data[HTickLow]) | (Tick(data[HTickHigh]) << 32)};
        std::uint64_t offset = PREFIX_WORDS;
        auto segment = [&](Word& address, Word n, unsigned words) {
            address = Word(offset); offset += std::uint64_t(n) * words;
            if (offset > data.size()) throw std::runtime_error("truncated job segment");
        };
        segment(layout.f_offset, layout.nf, 2); segment(layout.o_offset, layout.no, 2);
        segment(layout.b_offset, layout.nb, 2); segment(layout.nav_offset, layout.nn, 2);
        segment(layout.node_offset, layout.nodes, 8); segment(layout.task_offset, layout.tasks, 1);
        segment(layout.map_offset, layout.maps, 2);
        if (offset != data.size()) throw std::runtime_error("extra job data");
        auto ordered = [&](Word address, Word n, Word max_key, bool nonzero, bool is_map) {
            Word last = 0;
            for (Word i = 0; i < n; ++i) {
                Word key = data[address + 2 * i], value = data[address + 2 * i + 1];
                if (key >= max_key || (i && key <= last) || (nonzero && !value) ||
                    (is_map && value != NONE && value >= layout.cells))
                    throw std::runtime_error("invalid sparse key/value order");
                last = key;
            }
        };
        ordered(layout.f_offset, layout.nf, layout.words, true, false);
        ordered(layout.o_offset, layout.no, layout.words, true, false);
        ordered(layout.b_offset, layout.nb, layout.words, true, false);
        ordered(layout.nav_offset, layout.nn, layout.cells, false, false);
        ordered(layout.map_offset, layout.maps, layout.cells, false, true);
        for (Word i = 0; i < layout.nodes; ++i) {
            Word off = layout.node_offset + i * 8;
            if (data[off + 1] >= layout.cells || !data[off + 2])
                throw std::runtime_error("invalid active-node cell/delay");
        }
        for (Word i = 0; i < layout.tasks; ++i) {
            Word key = data[layout.task_offset + i];
            if (key >= (kind == Remap ? layout.cells : layout.words))
                throw std::runtime_error("task out of range");
        }
        const Word* d = definition(); const Word* t = data.data() + 32;
        if (d[1] > 65535 || d[2] > 1 || d[3] > 15 || d[4] > 255 ||
            d[14] != d[0] || d[15] != t[0] || t[14] != t[0] || t[15] != t[0] ||
            t[1] != data[HTickLow] || t[2] != data[HTickHigh])
            throw std::runtime_error("invalid field/time definition");
        count = kind == CrowdProposal ? layout.nodes : layout.tasks;
    }
};
inline Word read32(std::istream& in) {
    unsigned char b[4]{}; in.read(reinterpret_cast<char*>(b), 4);
    if (!in) throw std::runtime_error("truncated binary input");
    return Word(b[0]) | Word(b[1]) << 8 | Word(b[2]) << 16 | Word(b[3]) << 24;
}
inline void write32(std::ostream& out, Word x) {
    char b[4]{char(x & 255u), char((x >> 8) & 255u), char((x >> 16) & 255u), char(x >> 24)};
    out.write(b, 4);
}
inline Job read_job(std::istream& in) {
    Job job; job.data.resize(16);
    for (Word& x : job.data) x = read32(in);
    if (job.data[HMagic] != MAGIC || job.data[HWords] < 48 || job.data[HWords] > (1u << 29))
        throw std::runtime_error("invalid job size or magic");
    job.data.resize(job.data[HWords]);
    for (std::size_t i = 16; i < job.data.size(); ++i) job.data[i] = read32(in);
    job.validate(); return job;
}
inline void write_output(std::ostream& out, const std::vector<Output>& values) {
    out.write("AX0OUT6\0", 8); write32(out, Word(values.size()));
    for (const auto& v : values) { write32(out, v.key); write32(out, v.value); write32(out, v.delta); write32(out, v.aux); }
    out.flush(); if (!out) throw std::runtime_error("output failure");
}
inline std::vector<Output> run_cpu(const Job& job) {
    std::vector<Output> output(job.count);
    PointerReader reader{job.data.data()};
    for (Word i = 0; i < job.count; ++i)
        output[i] = evaluate(reader, job.layout, job.kind, i, job.definition());
    return output;
}
} // namespace axis0
