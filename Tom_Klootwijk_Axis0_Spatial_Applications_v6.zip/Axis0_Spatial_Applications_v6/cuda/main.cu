#include <cuda_runtime.h>
#include "axis0/job.hpp"
#include <chrono>
#include <iostream>
#include <memory>
#if defined(_WIN32)
#include <fcntl.h>
#include <io.h>
#endif
namespace axis0::gpu {
void check(cudaError_t status,const char* label) {
    if(status!=cudaSuccess)throw std::runtime_error(std::string(label)+": "+cudaGetErrorString(status));
}
template<class T>struct Buffer {
    T* data=nullptr;
    explicit Buffer(std::size_t n) {if(n)check(cudaMalloc(reinterpret_cast<void**>(&data),n*sizeof(T)),"cudaMalloc");}
    ~Buffer(){if(data)cudaFree(data);}Buffer(const Buffer&)=delete;
};
struct Texture {
    cudaTextureObject_t object=0;
    Texture(const Word* data,std::size_t count) {
        cudaResourceDesc resource{};resource.resType=cudaResourceTypeLinear;
        resource.res.linear.devPtr=const_cast<Word*>(data);
        resource.res.linear.desc=cudaCreateChannelDesc<unsigned int>();
        resource.res.linear.sizeInBytes=count*sizeof(Word);
        cudaTextureDesc descriptor{};descriptor.readMode=cudaReadModeElementType;
        descriptor.normalizedCoords=0;descriptor.filterMode=cudaFilterModePoint;
        descriptor.addressMode[0]=cudaAddressModeClamp;
        check(cudaCreateTextureObject(&object,&resource,&descriptor,nullptr),"create integer texture");
    }
    ~Texture(){if(object)cudaDestroyTextureObject(object);}Texture(const Texture&)=delete;
};
template<int Backend>struct Reader {
    const Word* data;cudaTextureObject_t texture;
    __device__ __forceinline__ Word read(Word address)const {
        if constexpr(Backend==1)return data[address];
        else return tex1Dfetch<unsigned int>(texture,static_cast<int>(address));
    }
};
template<int Backend>__global__ void application_kernel(const Word* atlas,cudaTextureObject_t texture,
    Layout layout,Word kind,Word task_count,Output* results) {
    Reader<Backend> reader{atlas,texture};
    __shared__ Word shared_definition[16];
    if constexpr(Backend==2) {
        if(threadIdx.x<16)shared_definition[threadIdx.x]=reader.read(16+threadIdx.x);
        __syncthreads();
    }
    Word local_definition[16];
    const Word* definition;
    if constexpr(Backend==2)definition=shared_definition;
    else {for(Word i=0;i<16;++i)local_definition[i]=reader.read(16+i);definition=local_definition;}
    for(Word i=blockIdx.x*blockDim.x+threadIdx.x;i<task_count;i+=blockDim.x*gridDim.x)
        results[i]=evaluate(reader,layout,kind,i,definition);
}
struct Result {std::vector<Output> output;std::uint64_t elapsed_ns=0;};
Result run(const Job& job,int backend,unsigned repeats,const cudaDeviceProp& property) {
    Result result;result.output.resize(job.count);if(!job.count)return result;
    if(backend!=1 && (property.maxTexture1DLinear<=0 || job.data.size()>std::size_t(property.maxTexture1DLinear)))
        throw std::runtime_error("sparse atlas exceeds linear texture limit; use global or a smaller batch");
    std::size_t free=0,total=0;check(cudaMemGetInfo(&free,&total),"query free VRAM");
    const std::uint64_t need=job.data.size()*4ull+job.count*sizeof(Output);
    if(need>free)throw std::runtime_error("sparse input/output exceed free VRAM");
    Buffer<Word> atlas(job.data.size());Buffer<Output> output(job.count);
    check(cudaMemcpy(atlas.data,job.data.data(),job.data.size()*4,cudaMemcpyHostToDevice),"upload sparse field atlas");
    std::unique_ptr<Texture> texture;
    if(backend!=1)texture=std::make_unique<Texture>(atlas.data,job.data.size());
    cudaTextureObject_t object=texture?texture->object:0;
    unsigned blocks=std::max(1u,std::min((job.count+127u)/128u,unsigned(std::max(property.multiProcessorCount,1))*8u));
    auto launch=[&](){
        if(backend==0)application_kernel<0><<<blocks,128>>>(atlas.data,object,job.layout,job.kind,job.count,output.data);
        else if(backend==1)application_kernel<1><<<blocks,128>>>(atlas.data,object,job.layout,job.kind,job.count,output.data);
        else application_kernel<2><<<blocks,128>>>(atlas.data,object,job.layout,job.kind,job.count,output.data);
        check(cudaGetLastError(),"application kernel launch");
    };
    check(cudaDeviceSynchronize(),"input ready");auto begin=std::chrono::steady_clock::now();
    for(unsigned i=0;i<repeats;++i)launch();
    check(cudaDeviceSynchronize(),"application completion");auto end=std::chrono::steady_clock::now();
    result.elapsed_ns=std::uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count());
    check(cudaMemcpy(result.output.data(),output.data,job.count*sizeof(Output),cudaMemcpyDeviceToHost),"read proposals");
    return result;
}
}
int main(int argc,char**argv){using namespace axis0;using namespace axis0::gpu;try{
    bool serve=false,info=false,verify=false;std::string input,output,report,backend_name="texture";int backend=0;unsigned repeat=1;
    for(int i=1;i<argc;++i){std::string a=argv[i];
        if(a=="--serve"){serve=true;continue;}if(a=="--info"){info=true;continue;}if(a=="--verify"){verify=true;continue;}
        if(a=="--help"){std::cout<<"axis0_cuda --serve --backend texture|global|shared | --job file --out file [--repeat N --verify --report file]\n";return 0;}
        if(i+1>=argc)throw std::invalid_argument("missing argument");std::string v=argv[++i];
        if(a=="--job")input=v;else if(a=="--out")output=v;else if(a=="--report")report=v;else if(a=="--backend")backend_name=v;
        else if(a=="--repeat"){if(v.empty()||v.find_first_not_of("0123456789")!=std::string::npos)throw std::invalid_argument("bad repeat");std::size_t used=0;auto n=std::stoul(v,&used);if(used!=v.size()||!n||n>NONE)throw std::invalid_argument("bad repeat");repeat=unsigned(n);}else throw std::invalid_argument("unknown argument");}
    if(backend_name=="texture")backend=0;else if(backend_name=="global")backend=1;else if(backend_name=="shared")backend=2;else throw std::invalid_argument("unknown backend");
    check(cudaSetDevice(0),"select CUDA device 0");check(cudaFree(nullptr),"initialize context");cudaDeviceProp property{};check(cudaGetDeviceProperties(&property,0),"device properties");
    if(info){std::size_t f=0,t=0;check(cudaMemGetInfo(&f,&t),"memory information");std::cout<<"{\"name\":\""<<property.name<<"\",\"compute_major\":"<<property.major<<",\"compute_minor\":"<<property.minor<<",\"free_bytes\":"<<f<<",\"total_bytes\":"<<t<<",\"texture_max_elements\":"<<property.maxTexture1DLinear<<",\"l2_bytes\":"<<property.l2CacheSize<<"}\n";return 0;}
    if(serve){
#if defined(_WIN32)
        _setmode(_fileno(stdin),_O_BINARY);_setmode(_fileno(stdout),_O_BINARY);
#endif
        while(std::cin.peek()!=std::char_traits<char>::eof()){Job job=read_job(std::cin);auto result=run(job,backend,1,property);write_output(std::cout,result.output);}return 0;
    }
    if(input.empty()||output.empty())throw std::invalid_argument("job/output required");std::ifstream in(input,std::ios::binary);if(!in)throw std::runtime_error("cannot read job");Job job=read_job(in);auto result=run(job,backend,repeat,property);
    if(verify){auto oracle=run_cpu(job);if(oracle.size()!=result.output.size()||std::memcmp(oracle.data(),result.output.data(),oracle.size()*sizeof(Output)))throw std::runtime_error("GPU/CPU disagreement");}
    std::ofstream out(output,std::ios::binary);if(!out)throw std::runtime_error("cannot write output");write_output(out,result.output);
    if(!report.empty()){std::ofstream f(report);if(!f)throw std::runtime_error("cannot write report");f<<"{\"backend\":\""<<backend_name<<"\",\"repeat\":"<<repeat<<",\"task_count\":"<<job.count<<",\"resident_launch_completion_ns\":"<<result.elapsed_ns<<",\"input_bytes\":"<<job.data.size()*4<<",\"gpu_executed\":true,\"cpu_verified\":"<<(verify?"true":"false")<<",\"scope\":\"repeated evaluation of one immutable snapshot; upload and output copies excluded\"}\n";}
    return 0;
}catch(const std::exception&e){std::cerr<<"axis0_cuda: "<<e.what()<<'\n';return 1;}}
