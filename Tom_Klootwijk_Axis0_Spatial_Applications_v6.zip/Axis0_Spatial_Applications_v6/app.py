#!/usr/bin/env python3
"""Run a user-supplied use-case scenario, rather than only the bundled fixtures."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'python'))
from axis0.model import Grid,Field
from axis0.kernel import Kernel
from axis0.routing import wave,network_route,Edge,exact_tour,eda_routes,time_route
from axis0.crowd import Node,simulate,replay_occupancy
from axis0.interfaces import read_pbm,write_pbm,edge_profile,event_timing
from axis0.ledger import Ledger

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('kind',choices=('crowd','route','moving','network','eda','tsp','boundary','timing','replay'))
    p.add_argument('input',type=Path);p.add_argument('--kernel',type=Path);p.add_argument('--backend',choices=('cpu','texture','global','shared'),default='cpu')
    p.add_argument('--out',type=Path,required=True);p.add_argument('--expected-head',help='trusted external head for replay verification')
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    uses_kernel=a.kind in ('crowd','route','eda','boundary')
    if uses_kernel and a.kernel is None:p.error('this profile needs --kernel')
    if a.kind not in ('boundary','replay'):scene=json.loads(a.input.read_text())
    if a.kind in ('crowd','route','moving','eda'):
        grid=Grid(**scene['grid']);blocked=Field.from_cells(grid,(grid.cell(*xy) for xy in scene.get('blocked_xy',[])))
    kernel=Kernel(a.kernel,a.backend) if uses_kernel else None
    try:
        if a.kind=='crowd':
            nodes=[Node(n['id'],grid.cell(*n['xy']),n['delta_t'],n.get('ready',0),n.get('priority',n['id'])) for n in scene['nodes']]
            result,ledger=simulate(kernel,blocked,[grid.cell(*xy) for xy in scene['exits_xy']],nodes,scene['horizon'])
            ledger.save(a.out/'events.jsonl');result['replay']=replay_occupancy(ledger)
        elif a.kind=='route':
            target=grid.cell(*scene['target_xy']);result_wave=wave(kernel,blocked,[grid.cell(*xy) for xy in scene['seed_xy']],target)
            path=result_wave.path(target);result={'reached':bool(path),'path_xy':[grid.xy(c) for c in path],
                'graph_hops':len(path)-1 if path else None,'visited_cells':result_wave.visited.count(),'updates':result_wave.updates}
        elif a.kind=='moving':
            changes={int(t):[(grid.cell(*item['xy']),item['blocked']) for item in events] for t,events in scene.get('changes',{}).items()}
            result=time_route(grid,blocked,changes,grid.cell(*scene['start_xy']),grid.cell(*scene['target_xy']),scene['horizon'])
        elif a.kind=='network':
            edges=[Edge(e['source'],e['target'],tuple(tuple(x) for x in e['schedule'])) for e in scene['edges']]
            result=network_route(edges,scene['start'],scene['goal'],scene.get('start_time',0))
        elif a.kind=='eda':
            nets=[(grid.cell(*n['from_xy']),grid.cell(*n['to_xy'])) for n in scene['nets']]
            result=eda_routes(kernel,blocked,nets,scene.get('clearance',0))
        elif a.kind=='tsp':result=exact_tour(scene['cost_matrix'])
        elif a.kind=='boundary':
            fields=edge_profile(kernel,read_pbm(a.input));result=fields['counts']
            for name in ('source','boundary','dilation','erosion'):write_pbm(a.out/f'{name}.pbm',fields[name])
        elif a.kind=='timing':result=event_timing(scene['events_us'],scene['latency_us'],scene.get('relative_delivery_us'))
        else:
            records=[json.loads(line) for line in a.input.read_text().splitlines() if line.strip()]
            if not Ledger.verify(records,a.expected_head):raise ValueError('chain or trusted head does not verify')
            ledger=object.__new__(Ledger);ledger.records=records;ledger.previous=records[-1]['hash']
            result=replay_occupancy(ledger);result['anchored_to_external_head']=a.expected_head is not None
        if kernel:result['kernel']=kernel.metrics()
        (a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    finally:
        if kernel:kernel.close()
if __name__=='__main__':main()
