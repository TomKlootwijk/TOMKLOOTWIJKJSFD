"""Application routing closures; none are asserted to occur instantly.

The literal source XOR profile is preserved separately. Exact reachability uses
OR for alternative arrivals, then produces the source-form XOR delta mask.
"""
from __future__ import annotations
from dataclasses import dataclass
import heapq
from .model import Field, Grid
from .kernel import Kernel

@dataclass
class Wave:
    visited: Field
    distances: dict[int, int]
    parents: dict[int, int | None]
    updates: int
    frontier_words_processed: int
    def path(self, target: int) -> list[int]:
        if target not in self.parents: return []
        result = [target]
        while self.parents[result[-1]] is not None: result.append(self.parents[result[-1]])
        result.reverse(); return result

def wave(kernel: Kernel, blocked: Field, seeds, target: int | None = None) -> Wave:
    grid = blocked.grid; seeds = sorted(set(seeds))
    if any(not 0 <= x < grid.cells or blocked.has(x) for x in seeds): raise ValueError("invalid/blocked seed")
    frontier = Field.from_cells(grid, seeds); visited = frontier.copy()
    parents = {s: None for s in seeds}; distance = {s: 0 for s in seeds}
    updates = work = 0
    while frontier.words and (target is None or target not in distance):
        previous = frontier
        visited, frontier, delta = kernel.stencil(visited, frontier, blocked, 'wave', updates)
        work += len(previous.words); updates += 1
        if delta.words != frontier.words: raise AssertionError("wave operator is not the disjoint arrival mask")
        for cell in frontier.active():
            if cell in distance: raise AssertionError("duplicate first arrival")
            candidates = [n for n in grid.neighbors(cell) if previous.has(n)]
            if not candidates: raise AssertionError("missing predecessor")
            distance[cell] = updates; parents[cell] = min(candidates)
    return Wave(visited, distance, parents, updates, work)

def time_route(grid: Grid, initial_blocked: Field, changes: dict[int, list[tuple[int,bool]]],
               start: int, goal: int, horizon: int) -> dict:
    """Exact finite time-expanded route with waiting and known cell-validity events.

At time t, the occupant must be in a free cell at t. A move/wait to v is admitted
only when v is free at t+1. This is a discrete validity convention, not a claim
about collisions between continuous trajectories during a tick.
"""
    if initial_blocked.grid != grid or not 0 <= start < grid.cells or not 0 <= goal < grid.cells or horizon < 0:
        raise ValueError("invalid time-route input")
    blocked = initial_blocked.copy()
    for c, value in changes.get(0, []): blocked.set(c, value)
    if blocked.has(start): return {"reached":False,"reason":"blocked start at time zero","path":[]}
    current = {start}; parents = {(0,start):None}; found = (0,start) if start == goal else None
    time_steps = 0
    for t in range(horizon):
        if found is not None or not current: break
        for c,value in changes.get(t+1,[]): blocked.set(c,value)
        next_layer=set()
        for u in sorted(current):
            for v in sorted(set([u,*grid.neighbors(u)])):
                if blocked.has(v) or v in next_layer: continue
                next_layer.add(v);parents[(t+1,v)]=(t,u)
        current=next_layer;time_steps=t+1
        if goal in current:found=(t+1,goal)
    path=[]
    while found is not None:
        path.append(found);found=parents[found]
    path.reverse()
    return {"reached":bool(path),"arrival_tick":path[-1][0] if path else None,
            "path":[{"tick":t,"cell":c} for t,c in path],"expanded_states":len(parents),
            "evaluated_time_steps":time_steps,"horizon":horizon,"solver":"CPU exact bounded temporal reachability"}

@dataclass(frozen=True)
class Edge:
    source: int
    target: int
    # (effective tick, positive traversal latency, enabled). State persists to next event.
    schedule: tuple[tuple[int,int,bool], ...]
    def __post_init__(self):
        if not self.schedule or self.schedule[0][0] != 0: raise ValueError("edge needs initial state at t=0")
        if any(t<0 or delay<=0 for t,delay,up in self.schedule): raise ValueError("nonnegative ticks, positive delays")
        if any(a[0]>=b[0] for a,b in zip(self.schedule,self.schedule[1:])): raise ValueError("schedule not strictly ordered")
    def at(self,t):
        chosen=self.schedule[0]
        for value in self.schedule:
            if value[0]>t:break
            chosen=value
        return chosen[1:]
    def best_departure(self,earliest):
        # Waiting is allowed. Only a current departure or a change boundary can improve arrival.
        candidates=[earliest]+[t for t,delay,up in self.schedule if t>earliest]
        best=None
        for t in candidates:
            delay,up=self.at(t)
            if up:
                candidate=(t+delay,t)
                if best is None or candidate<best:best=candidate
        return best

def network_route(edges: list[Edge], start: int, goal: int, start_time=0) -> dict:
    if start_time<0:raise ValueError("start_time must be nonnegative")
    outgoing={}
    for e in edges:outgoing.setdefault(e.source,[]).append(e)
    arrivals={start:start_time};previous={start:None};queue=[(start_time,start)];expanded=0
    while queue:
        now,u=heapq.heappop(queue)
        if now!=arrivals[u]:continue
        expanded+=1
        if u==goal:break
        for e in outgoing.get(u,[]):
            candidate=e.best_departure(now)
            if candidate is None:continue
            arrival,departure=candidate
            if arrival<arrivals.get(e.target,1<<100):
                arrivals[e.target]=arrival;previous[e.target]=(u,departure,arrival)
                heapq.heappush(queue,(arrival,e.target))
    legs=[]
    if goal in arrivals:
        cur=goal
        while previous[cur] is not None:
            u,depart,arrive=previous[cur];legs.append({"source":u,"target":cur,"departure":depart,"arrival":arrive});cur=u
        legs.reverse()
    return {"reached":goal in arrivals,"arrival":arrivals.get(goal),"legs":legs,"expanded_nodes":expanded,
            "semantics":"edge state/latency sampled at departure; waiting allowed; no mid-flight revocation","backend":"CPU sparse event router"}

def exact_tour(costs: list[list[int | None]]) -> dict:
    """Exact finite TSP using bit positions for attainable integer costs.

This is an explicit additional subset/endpoint state, NOT the source's asserted
first-wave-collision proof. It is exponential in the number of cities.
"""
    m=len(costs)
    if m<2 or any(len(row)!=m for row in costs):raise ValueError("square matrix, at least two cities")
    for row in costs:
        if any(x is not None and (type(x) is not int or x<0) for x in row):raise ValueError("nonnegative integer costs")
    dp={}
    for j in range(1,m):
        if costs[0][j] is not None:dp[(1<<(j-1),j)]=1<<costs[0][j]
    for subset in range(1,1<<(m-1)):
        for j in range(1,m):
            bits=dp.get((subset,j),0)
            if not bits:continue
            for k in range(1,m):
                flag=1<<(k-1);weight=costs[j][k]
                if subset&flag or weight is None:continue
                key=(subset|flag,k);dp[key]=dp.get(key,0)|(bits<<weight)
    full=(1<<(m-1))-1;final=0
    for j in range(1,m):
        if costs[j][0] is not None:final |= dp.get((full,j),0)<<costs[j][0]
    if not final:return {"feasible":False,"cost":None,"tour":[],"subset_endpoint_states":len(dp)}
    best=(final&-final).bit_length()-1
    j=next(j for j in range(1,m) if costs[j][0] is not None and best>=costs[j][0] and ((dp.get((full,j),0)>>(best-costs[j][0]))&1))
    cost=best-costs[j][0];subset=full;reverse=[0,j]
    while subset!=(1<<(j-1)):
        prevset=subset^(1<<(j-1))
        i=next(i for i in range(1,m) if prevset&(1<<(i-1)) and costs[i][j] is not None and cost>=costs[i][j] and ((dp.get((prevset,i),0)>>(cost-costs[i][j]))&1))
        cost-=costs[i][j];subset=prevset;j=i;reverse.append(j)
    reverse.append(0);reverse.reverse()
    return {"feasible":True,"cost":best,"tour":reverse,"subset_endpoint_states":len(dp),
            "attainable_closed_tour_costs":[i for i in range(final.bit_length()) if (final>>i)&1],
            "cost_bit_capacity":final.bit_length(),"solver":"CPU exact subset/cost-bitset closure"}

def eda_routes(kernel: Kernel, blocked: Field, nets: list[tuple[int,int]], clearance=0) -> dict:
    if clearance<0:raise ValueError("nonnegative clearance")
    reserved=blocked.copy();routes=[]
    for index,(start,end) in enumerate(nets):
        if reserved.has(start) or reserved.has(end):
            routes.append({"net":index,"feasible":False,"reason":"terminal blocked or reserved"});continue
        result=wave(kernel,reserved,[start],end);path=result.path(end)
        if not path:routes.append({"net":index,"feasible":False,"reason":"no route under current reservations"});continue
        occupied=set(path)
        for _ in range(clearance):occupied |= {j for i in list(occupied) for j in reserved.grid.neighbors(i)}
        reserved=reserved.union(Field.from_cells(reserved.grid,occupied))
        routes.append({"net":index,"feasible":True,"path":path,"hops":len(path)-1})
    return {"routes":routes,"all_feasible":all(r['feasible'] for r in routes),
            "reserved_cells":reserved.count(),"method":"sequential single-layer routes with explicit clearance; not joint wirelength optimum"}
