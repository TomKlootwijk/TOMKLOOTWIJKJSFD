"""Binary boundary, device-calibration and timing adapters; no renderer or stimuli."""
from __future__ import annotations
from pathlib import Path
from .model import Field, Grid
from .kernel import Kernel

def read_pbm(path:Path)->Field:
    lines=[]
    for line in path.read_text().splitlines():lines.append(line.split('#',1)[0])
    words=' '.join(lines).split()
    if len(words)<3 or words[0]!='P1':raise ValueError('only ASCII P1 PBM is supported')
    width,height=map(int,words[1:3]);grid=Grid(width,height)
    values=words[3:]
    if len(values)!=grid.cells or any(v not in ('0','1') for v in values):raise ValueError('invalid PBM payload')
    return Field.from_cells(grid,(i for i,v in enumerate(values) if v=='1'))

def write_pbm(path:Path,field:Field):
    g=field.grid
    path.write_text('P1\n# Axis0 binary data export; not an inference of physical geometry\n'+f'{g.width} {g.height}\n'+
                    '\n'.join(' '.join('1' if field.has(y*g.width+x) else '0' for x in range(g.width)) for y in range(g.height))+'\n')

def edge_profile(kernel:Kernel,source:Field)->dict:
    boundary,_,_=kernel.stencil(source,source,definition='boundary')
    grown,_,_=kernel.stencil(source,source,definition='dilate')
    contracted,_,_=kernel.stencil(source,source,definition='erode')
    # Operator delta is an observable change, separate from a claimed numeric distance.
    return {'source':source,'boundary':boundary,'dilation':grown,'erosion':contracted,
            'counts':{'source_cells':source.count(),'boundary_cells':boundary.count(),
                      'dilated_cells':grown.count(),'eroded_cells':contracted.count()}}

def translate_map(grid:Grid,active:Field,dx:int,dy:int)->dict[int,int]:
    result={}
    for i in active.active():
        x,y=grid.xy(i);xx,yy=x+dx,y+dy
        if 0<=xx<grid.width and 0<=yy<grid.height:result[i]=yy*grid.width+xx
    return result

def calibrate(kernel:Kernel,channels:dict[str,Field],measured_shift:dict[str,tuple[int,int]])->dict:
    corrected={};counts={}
    for name,source in channels.items():
        # A supplied measured displacement, not one inferred from a person's origin.
        dx,dy=measured_shift[name]
        output=kernel.remap(source,translate_map(source.grid,source,-dx,-dy))
        corrected[name]=output;counts[name]={'input_ones':source.count(),'output_ones':output.count(),
                                          'dropped_or_merged':source.count()-output.count()}
    return {'corrected':corrected,'counts':counts,
            'scope':'binary sample registration using supplied integer LUTs; no optical model, subpixel interpolation, audio playback or gaze-device control'}

def event_timing(events:list[int],latency_us:dict[str,int],relative_delivery_us:dict[str,int]|None=None)->dict:
    """Align simulated device delivery stamps using supplied measured latencies."""
    if not latency_us or any(type(x) is not int or x<0 for x in latency_us.values()):raise ValueError('nonnegative integer latencies')
    offsets=relative_delivery_us or {k:0 for k in latency_us}
    if set(offsets)!=set(latency_us) or any(type(v) is not int for v in offsets.values()):raise ValueError('offset channels/types mismatch')
    lead=max(latency_us[k]-offsets[k] for k in latency_us)
    lead=max(lead,0);records=[]
    for tick in events:
        if type(tick) is not int or tick<0:raise ValueError('nonnegative event times')
        base=tick+lead
        command={k:base+offsets[k]-latency_us[k] for k in latency_us}
        delivered={k:command[k]+latency_us[k] for k in latency_us}
        assert all(command[k]>=tick for k in latency_us)
        records.append({'input_event_us':tick,'delivery_reference_us':base,'command_times_us':command,
                        'predicted_delivery_us':delivered})
    return {'events':records,'calibration_latency_us':latency_us,'relative_delivery_us':offsets,
            'scope':'offline integer event stamps; predicted delivery only, no measurements of pleasure, dopamine, comfort or optical correction'}

def certify_corridor(grid:Grid,blocked:Field,path:list[int])->dict:
    if not path or blocked.grid!=grid:raise ValueError('empty corridor or grid mismatch')
    for c in path:
        if not 0<=c<grid.cells or blocked.has(c):raise ValueError('corridor blocked/outside grid')
    for a,b in zip(path,path[1:]):
        if b not in set(grid.neighbors(a)):raise ValueError('uncertified gap: path not adjacent')
    return {'start':path[0],'end':path[-1],'duration_ticks':len(path)-1,
            'verified_path':path,'runtime_event_count':2,'meaning':'interior validated once; duration retained, not teleported or free traversal'}

def lattice_gas_step(kernel:Kernel,channels:list[Field],blocked:Field):
    """Four-velocity Boolean lattice-gas construction; not a continuum fluid solver.

Head-on horizontal pairs turn vertical and vice versa when no other velocity
occupies the cell. Streaming is one cell per tick; walls reflect at the source.
Each velocity is one Boolean plane. Four planes are required, not one bit total.
"""
    from .model import Definition,truth_table4,shift
    if len(channels)!=4 or any(c.grid!=blocked.grid for c in channels):raise ValueError('four compatible channel fields required')
    east,west,north,south=channels
    horizontal=east.intersection(west).minus(north.union(south))
    vertical=north.intersection(south).minus(east.union(west))
    flip=horizontal.union(vertical)
    post=[channel.xor(flip) for channel in channels]
    output=[Field(blocked.grid) for _ in range(4)]
    for direction,source in enumerate(post):
        rule=Definition('single-direction lattice transport',8,truth_table4(lambda a,b,c,d:b),0,1<<direction)
        transported,_,_=kernel.stencil(Field(blocked.grid),source,definition=rule)
        arrivals=transported.minus(blocked)
        origins_arrived=shift(arrivals,direction^1)
        reflected=source.minus(origins_arrived)
        output[direction]=output[direction].union(arrivals)
        output[direction^1]=output[direction^1].union(reflected)
    if sum(c.count() for c in output)!=sum(c.count() for c in channels):raise AssertionError('lattice particle count changed')
    if any(c.intersection(blocked).words for c in output):raise AssertionError('particle in obstacle')
    return output
