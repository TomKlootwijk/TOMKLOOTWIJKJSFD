"""Binary bridge to the shared C++/CUDA application kernels.

A persistent worker amortizes process creation. Scheduling, sparse compaction
and crowd conflict resolution remain on the host; this is a declared hybrid.
"""
from __future__ import annotations
import json
from pathlib import Path
import struct
import subprocess
import time
from .model import Field, Grid, Definition, RULES, U32, time_record, neighborhood

MAGIC = 0xA6062026

def job_bytes(kind: int, grid: Grid, definition: Definition, *, field=None, operator=None,
              blocked=None, navigation=None, nodes=None, tasks=None, mapping=None, tick=0) -> bytes:
    field = field if field is not None else Field(grid)
    operator = operator if operator is not None else Field(grid)
    blocked = blocked if blocked is not None else Field(grid)
    for f in (field, operator, blocked):
        if f.grid != grid: raise ValueError("job field layout mismatch")
    f, o, b = field.rows(), operator.rows(), blocked.rows()
    nav = sorted((navigation or {}).items()); maps = sorted((mapping or {}).items())
    nodes, tasks = list(nodes or []), list(tasks or [])
    payload = definition.record() + time_record(tick)
    for rows in (f, o, b, nav):
        for key, value in rows: payload.extend((key, value))
    for node in nodes:
        if len(node) != 8: raise ValueError("node record needs 8 words")
        payload.extend(node)
    payload.extend(tasks)
    for key, value in maps: payload.extend((key, value))
    header = [MAGIC, 6, kind, grid.width, grid.height, {"rect":0,"polar":1,"klein":2}[grid.topology],
              len(f), len(o), len(b), len(nav), len(nodes), len(tasks), len(maps), 16 + len(payload),
              tick & U32, tick >> 32]
    return struct.pack(f"<{len(header)+len(payload)}I", *header, *payload)

def read_exact(stream, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        part = stream.read(size - len(chunks))
        if not part: raise EOFError("kernel worker closed its output")
        chunks.extend(part)
    return bytes(chunks)

class Kernel:
    def __init__(self, executable: Path, backend: str = "cpu"):
        args = [str(executable.resolve()), "--serve"]
        if backend != "cpu": args += ["--backend", backend]
        self.executable, self.backend = executable.resolve(), backend
        self.process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.calls = self.tasks = self.bytes_sent = self.wall_ns = 0
    def close(self):
        if self.process.poll() is None:
            self.process.stdin.close(); self.process.wait(timeout=30)
        if self.process.returncode:
            raise RuntimeError(self.process.stderr.read().decode(errors="replace"))
        self.process.stdout.close(); self.process.stderr.close()
    def __enter__(self): return self
    def __exit__(self, kind, value, tb):
        if kind:
            self.process.kill(); self.process.wait()
        else: self.close()
    def execute(self, raw: bytes) -> list[tuple[int,int,int,int]]:
        start = time.perf_counter_ns()
        try:
            self.process.stdin.write(raw); self.process.stdin.flush()
            prefix = read_exact(self.process.stdout, 12)
            if prefix[:8] != b"AX0OUT6\0": raise ValueError("kernel response magic")
            count, = struct.unpack_from("<I", prefix, 8)
            body = read_exact(self.process.stdout, 16 * count)
        except (BrokenPipeError, EOFError) as error:
            self.process.wait(timeout=10)
            raise RuntimeError(self.process.stderr.read().decode(errors="replace")) from error
        self.calls += 1; self.tasks += count; self.bytes_sent += len(raw); self.wall_ns += time.perf_counter_ns() - start
        return list(struct.iter_unpack("<4I", body))
    def stencil(self, field: Field, operator: Field, blocked: Field | None = None,
                definition: Definition | str = "wave", tick: int = 0):
        if isinstance(definition, str): definition = RULES[definition]
        candidate = neighborhood(operator, definition.directions)
        keys = set(candidate.words)
        if definition.output_mode: keys |= field.words.keys()
        rows = self.execute(job_bytes(1, field.grid, definition, field=field, operator=operator,
                           blocked=blocked, tasks=sorted(keys), tick=tick))
        next_field = field.patch((key, delta) for key, value, delta, expression in rows)
        expressed = Field(field.grid, {key: expression for key, value, delta, expression in rows})
        delta = Field(field.grid, {key: delta for key, value, delta, expression in rows})
        return next_field, expressed, delta
    def proposals(self, field: Field, blocked: Field, navigation: dict[int,int], nodes, tick: int):
        return self.execute(job_bytes(2, field.grid, RULES['crowd'], field=field, blocked=blocked,
                                     navigation=navigation, nodes=nodes, tick=tick))
    def remap(self, source: Field, mapping: dict[int,int], tick: int=0) -> Field:
        result = self.execute(job_bytes(3, source.grid, RULES['remap'], field=source,
                             tasks=list(source.active()), mapping=mapping, tick=tick))
        return Field.from_cells(source.grid, (target for src,target,accepted,_ in result if accepted))
    def metrics(self) -> dict:
        return {"backend":self.backend, "kernel_calls":self.calls, "kernel_tasks":self.tasks,
                "serialized_input_bytes":self.bytes_sent, "bridge_wall_ns":self.wall_ns,
                "timing_scope":"includes serialization transfer, kernel worker, allocation and synchronization; excludes Python application planning"}
