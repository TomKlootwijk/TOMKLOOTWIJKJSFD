"""Source-grounded sparse spatial application profiles, version 6.0."""
__version__ = "6.0"
