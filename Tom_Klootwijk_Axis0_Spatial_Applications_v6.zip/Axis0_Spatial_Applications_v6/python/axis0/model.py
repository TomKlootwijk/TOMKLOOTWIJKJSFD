"""Finite Boolean double-UU fields. Missing word records represent implicit zeros.

The attached document calls this a binary phase SDF. This implementation retains
that terminology for its adjacency boundary; it does not invent metric distances.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Iterable

U32 = (1 << 32) - 1
U64 = (1 << 64) - 1

@dataclass(frozen=True)
class Grid:
    width: int
    height: int
    topology: str = "rect"
    def __post_init__(self):
        if self.width < 32 or self.width & (self.width - 1) or self.height < 1:
            raise ValueError("width must be a power of two >=32; height positive")
        if self.width * self.height >= U32:
            raise ValueError("finite ABI needs cell count < UINT32_MAX")
        if self.topology not in ("rect", "polar", "klein"):
            raise ValueError("unknown topology")
    @property
    def cells(self) -> int: return self.width * self.height
    @property
    def row_words(self) -> int: return self.width // 32
    @property
    def words(self) -> int: return self.cells // 32
    def cell(self, x: int, y: int) -> int:
        if not (0 <= x < self.width and 0 <= y < self.height): raise ValueError("cell outside grid")
        return y * self.width + x
    def xy(self, cell: int) -> tuple[int, int]:
        if not 0 <= cell < self.cells: raise ValueError("cell outside grid")
        return cell % self.width, cell // self.width
    def neighbor(self, cell: int, direction: int) -> int | None:
        x, y = self.xy(cell)
        if direction == 0:
            return cell + 1 if x + 1 < self.width else y * self.width if self.topology != "rect" else None
        if direction == 1:
            return cell - 1 if x else y * self.width + self.width - 1 if self.topology != "rect" else None
        if direction == 2:
            return cell - self.width if y else ((self.height - 1) * self.width + self.width - 1 - x if self.topology == "klein" else None)
        if direction == 3:
            return cell + self.width if y + 1 < self.height else (self.width - 1 - x if self.topology == "klein" else None)
        raise ValueError("direction must be 0..3")
    def neighbors(self, cell: int):
        for direction in range(4):
            n = self.neighbor(cell, direction)
            if n is not None: yield n

@dataclass
class Field:
    """Only nonzero uint32 words are stored. A word is 32 logical one-bit cells."""
    grid: Grid
    words: dict[int, int] = field(default_factory=dict)
    def __post_init__(self):
        for key, value in list(self.words.items()):
            if not 0 <= key < self.grid.words or not 0 <= value <= U32:
                raise ValueError("invalid sparse word")
            if not value: del self.words[key]
    @classmethod
    def from_cells(cls, grid: Grid, cells: Iterable[int]) -> "Field":
        result = cls(grid)
        for c in cells: result.set(c)
        return result
    def copy(self) -> "Field": return Field(self.grid, self.words.copy())
    def has(self, cell: int) -> bool:
        return 0 <= cell < self.grid.cells and bool((self.words.get(cell >> 5, 0) >> (cell & 31)) & 1)
    def set(self, cell: int, value: bool = True):
        if not 0 <= cell < self.grid.cells: raise ValueError("cell outside grid")
        key, bit = cell >> 5, 1 << (cell & 31)
        word = self.words.get(key, 0)
        word = word | bit if value else word & (U32 ^ bit)
        if word: self.words[key] = word
        else: self.words.pop(key, None)
    def active(self):
        for key, word in sorted(self.words.items()):
            while word:
                b = word & -word
                yield key * 32 + b.bit_length() - 1
                word ^= b
    def count(self): return sum(w.bit_count() for w in self.words.values())
    def rows(self): return sorted(self.words.items())
    def logical_payload_bytes(self): return len(self.words) * 8
    def xor(self, other: "Field") -> "Field":
        self._same(other)
        return Field(self.grid, {k: self.words.get(k, 0) ^ other.words.get(k, 0) for k in self.words.keys() | other.words.keys()})
    def union(self, other: "Field") -> "Field":
        self._same(other)
        return Field(self.grid, {k: self.words.get(k, 0) | other.words.get(k, 0) for k in self.words.keys() | other.words.keys()})
    def intersection(self, other: "Field") -> "Field":
        self._same(other)
        return Field(self.grid, {k: self.words[k] & other.words[k] for k in self.words.keys() & other.words.keys()})
    def minus(self, other: "Field") -> "Field":
        self._same(other)
        return Field(self.grid, {k: v & (U32 ^ other.words.get(k, 0)) for k, v in self.words.items()})
    def _same(self, other):
        if self.grid != other.grid: raise ValueError("fields have different layouts")
    def patch(self, deltas: Iterable[tuple[int, int]]) -> "Field":
        result = self.copy()
        for key, delta in deltas:
            value = result.words.get(key, 0) ^ delta
            if value: result.words[key] = value
            else: result.words.pop(key, None)
        return result

def reverse32(word: int) -> int:
    # Integer reversal, not floating-point coordinate reflection.
    word = ((word & 0x55555555) << 1) | ((word >> 1) & 0x55555555)
    word = ((word & 0x33333333) << 2) | ((word >> 2) & 0x33333333)
    word = ((word & 0x0F0F0F0F) << 4) | ((word >> 4) & 0x0F0F0F0F)
    word = ((word & 0x00FF00FF) << 8) | ((word >> 8) & 0x00FF00FF)
    return ((word << 16) | (word >> 16)) & U32

def shift(source: Field, direction: int) -> Field:
    """Scatter only nonzero words; zero words are not traversed."""
    grid, result = source.grid, {}
    def emit(key, value):
        if value: result[key] = result.get(key, 0) | (value & U32)
    for key, word in source.words.items():
        row, col = divmod(key, grid.row_words)
        if direction == 0:
            emit(key, (word << 1) & U32)
            if col + 1 < grid.row_words: emit(key + 1, word >> 31)
            elif grid.topology != "rect": emit(row * grid.row_words, word >> 31)
        elif direction == 1:
            emit(key, word >> 1)
            if col: emit(key - 1, (word & 1) << 31)
            elif grid.topology != "rect": emit((row + 1) * grid.row_words - 1, (word & 1) << 31)
        elif direction == 2:
            if row: emit(key - grid.row_words, word)
            elif grid.topology == "klein": emit(grid.words - 1 - col, reverse32(word))
        elif direction == 3:
            if row + 1 < grid.height: emit(key + grid.row_words, word)
            elif grid.topology == "klein": emit(grid.row_words - 1 - col, reverse32(word))
        else: raise ValueError("direction must be 0..3")
    return Field(grid, result)

def neighborhood(source: Field, directions: int = 15) -> Field:
    result = Field(source.grid)
    for d in range(4):
        if directions & (1 << d): result = result.union(shift(source, d))
    return result

def truth_table4(function) -> int:
    return sum(int(bool(function(i & 1, (i >> 1) & 1, (i >> 2) & 1, (i >> 3) & 1))) << i for i in range(16))

@dataclass(frozen=True)
class Definition:
    name: str
    ident: int
    table: int
    output_mode: int = 0  # 0: result is delta, then F'=F XOR result; 1: direct next field
    directions: int = 15
    decision_table: int = 0x80
    source_role: str = "implementation closure"
    def record(self) -> list[int]:
        r = [0] * 16
        r[0:5] = [self.ident, self.table, self.output_mode, self.directions, self.decision_table]
        r[14], r[15] = self.ident, 0
        return r

RULES = {
    "literal": Definition("literal source XOR after one directional shift", 1, truth_table4(lambda a,b,c,d: b), 0, 1,
                          source_role="source equation, pages 3 and 21; direction explicitly East"),
    "wave": Definition("first arrival closure", 2, truth_table4(lambda a,b,c,d: not a and b and d)),
    "boundary": Definition("adjacent phase disagreement", 3, truth_table4(lambda a,b,c,d: (a and not c) or (not a and b)), 1),
    "dilate": Definition("binary growth", 4, truth_table4(lambda a,b,c,d: (a or b) and d), 1),
    "erode": Definition("binary contraction", 5, truth_table4(lambda a,b,c,d: a and c and d), 1),
    "crowd": Definition("delayed collision-free descending proposal", 6, 0, 0, 15, 0x80),
    "remap": Definition("calibrated Boolean sample remap", 7, 0, 1, 15, 0x88),
}

def time_record(tick: int) -> list[int]:
    if not 0 <= tick <= U64: raise ValueError("tick outside uint64")
    # Object zero is A=T. Its stamp is data and its self reference remains zero.
    return [0, tick & U32, tick >> 32, 1] + [0] * 12
