"""A reproducible event hash-chain, not cryptocurrency or distributed consensus."""
from __future__ import annotations
import hashlib,json
from pathlib import Path

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('ascii')

class Ledger:
    def __init__(self, genesis:dict):
        self.records=[];self.previous='0'*64
        self.append({'type':'genesis','definition':genesis})
    def append(self,event:dict):
        body={'index':len(self.records),'previous':self.previous,'event':event}
        body['hash']=hashlib.sha256(canonical(body)).hexdigest()
        self.records.append(body);self.previous=body['hash']
    def save(self,path:Path):path.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in self.records),encoding='utf-8')
    @staticmethod
    def verify(records:list[dict], expected_head:str|None=None)->bool:
        previous='0'*64
        for i,record in enumerate(records):
            if set(record)!={'index','previous','event','hash'} or record['index']!=i or record['previous']!=previous:return False
            body={k:record[k] for k in ('index','previous','event')}
            if hashlib.sha256(canonical(body)).hexdigest()!=record['hash']:return False
            previous=record['hash']
        return bool(records) and (expected_head is None or previous==expected_head)
