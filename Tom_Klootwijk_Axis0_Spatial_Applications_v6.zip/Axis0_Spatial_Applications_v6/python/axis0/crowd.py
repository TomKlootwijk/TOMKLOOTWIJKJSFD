"""Sparse occupancy plus per-node delta-time: a declared toy crowd model.

One shared rule, no psychological/cultural classifiers. Each active node carries
only its identifier, occupied cell, delay, deadline and optional tie priority.
"""
from __future__ import annotations
from dataclasses import dataclass
import heapq
from .model import Field,U32,U64
from .kernel import Kernel
from .routing import wave
from .ledger import Ledger

@dataclass
class Node:
    ident:int
    cell:int
    delay:int
    due:int=0
    priority:int=0
    def record(self):return [self.ident,self.cell,self.delay,self.priority,self.due&U32,self.due>>32,0,0]

def simulate(kernel:Kernel,blocked:Field,exits:list[int],nodes:list[Node],horizon:int,*,navigation=None):
    grid=blocked.grid
    if horizon<0 or not exits or any(not 0<=g<grid.cells or blocked.has(g) for g in exits):raise ValueError('invalid exit/horizon')
    nodes=[Node(n.ident,n.cell,n.delay,n.due,n.priority) for n in nodes]
    if len({n.ident for n in nodes})!=len(nodes) or len({n.cell for n in nodes})!=len(nodes):raise ValueError('duplicate node id/occupancy')
    for n in nodes:
        if not 0<=n.ident<=U32 or not 0<=n.priority<=U32 or not 1<=n.delay<=U32 or not 0<=n.due<=U64 or blocked.has(n.cell) or not 0<=n.cell<grid.cells:raise ValueError('invalid active node')
    goals=set(exits)
    nav=wave(kernel,blocked,exits).distances if navigation is None else navigation
    initial=Field.from_cells(grid,(n.cell for n in nodes));occupancy=initial.copy()
    live={n.ident:n for n in nodes};queue=[(n.due,n.ident) for n in nodes];heapq.heapify(queue)
    genesis={'grid':{'width':grid.width,'height':grid.height,'topology':grid.topology},
             'blocked_words':blocked.rows(),'exit_cells':sorted(goals),
             'nodes':[n.record() for n in sorted(nodes,key=lambda n:n.ident)],
             'rule':'strictly descending hop potential; empty old-snapshot target; (priority,id) conflict winner',
             'time':'A=T = earliest queued active-node deadline; delta_t is assigned simulation metadata'}
    ledger=Ledger(genesis);exited=[];collisions=0;rounds=0;proposals_total=0;skipped=0;previous_tick=-1
    while queue and queue[0][0]<=horizon:
        now=queue[0][0];due=[]
        while queue and queue[0][0]==now:
            t,ident=heapq.heappop(queue)
            if ident in live and live[ident].due==t:due.append(live[ident])
        if not due:continue
        due.sort(key=lambda n:n.ident)
        proposals=kernel.proposals(occupancy,blocked,nav,[n.record() for n in due],now)
        if len(proposals)!=len(due):raise AssertionError('missing proposals')
        if previous_tick>=0:skipped+=max(0,now-previous_tick-1)
        previous_tick=now;rounds+=1;proposals_total+=len(proposals)
        groups={};leaving=[]
        for ident,old,target,kind in proposals:
            if live[ident].cell!=old:raise AssertionError('proposal identity mismatch')
            if kind==2:
                if old not in goals:raise AssertionError('exit from non-exit cell')
                leaving.append((ident,old,old))
            elif kind==1:
                if target not in set(grid.neighbors(old)) or occupancy.has(target) or blocked.has(target) or nav.get(target,U32)>=nav.get(old,U32):raise AssertionError('invalid motion proposal')
                groups.setdefault(target,[]).append(ident)
        accepted=[]
        for target,identifiers in sorted(groups.items()):
            winner=min(identifiers,key=lambda ident:(live[ident].priority,ident))
            accepted.append((winner,live[winner].cell,target));collisions+=len(identifiers)-1
        before=occupancy.copy();moves=[]
        # Resolve first; commit disjoint departures and old-empty targets second.
        for ident,old,target in leaving+accepted:
            occupancy.set(old,False)
            is_exit=target in goals
            if is_exit:
                exited.append({'id':ident,'tick':now,'exit_cell':target});del live[ident]
            else:
                if occupancy.has(target):raise AssertionError('double occupancy')
                occupancy.set(target);live[ident].cell=target
            moves.append({'id':ident,'from':old,'to':target,'exit':is_exit})
        schedule=[]
        for n in due:
            if n.ident in live:
                if now>U64-n.delay:raise OverflowError('time deadline overflow')
                live[n.ident].due=now+n.delay;heapq.heappush(queue,(now+n.delay,n.ident));schedule.append([n.ident,now+n.delay])
        delta=before.xor(occupancy)
        if before.xor(delta).words!=occupancy.words:raise AssertionError('XOR commit identity')
        if occupancy.count()!=len(live) or len(live)+len(exited)!=len(nodes):raise AssertionError('occupancy conservation')
        if any(blocked.has(c) for c in occupancy.active()):raise AssertionError('blocked occupancy')
        ledger.append({'type':'state_transition','tick':now,'due_ids':[n.ident for n in due],
                       'moves':moves,'operator_delta_words':delta.rows(),'next_deadlines':schedule,
                       'rejected_same_target':sum(len(v)-1 for v in groups.values())})
    return {'initial_nodes':len(nodes),'evacuated':len(exited),'remaining':len(live),
            'exit_events':exited,'remaining_nodes':[n.record() for n in sorted(live.values(),key=lambda n:n.ident)],
            'horizon':horizon,'event_rounds':rounds,'due_node_proposals':proposals_total,
            'empty_integer_ticks_skipped_between_events':skipped,'same_target_losers':collisions,
            'occupancy_conserved_with_exits':True,'body_overlaps':0,'head_on_swaps':0,
            'last_tick':previous_tick if rounds else None,'active_word_payload_bytes':occupancy.logical_payload_bytes(),
            'delay_model':'synthetic per-node positive integer period, not human personality/biology',
            'termination':'all exited' if not live else 'finite horizon reached','ledger_head':ledger.previous},ledger

def replay_occupancy(ledger:Ledger)->dict:
    if not Ledger.verify(ledger.records,ledger.previous):raise ValueError('invalid event chain')
    genesis=ledger.records[0]['event']['definition']
    from .model import Grid
    grid=Grid(**genesis['grid']);blocked=Field(grid,dict(genesis['blocked_words']))
    positions={r[0]:r[1] for r in genesis['nodes']};occupancy=Field.from_cells(grid,positions.values());exits=set(genesis['exit_cells']);evacuated=0
    for record in ledger.records[1:]:
        event=record['event'];before=occupancy.copy();targets=[]
        for move in event['moves']:
            if positions.get(move['id'])!=move['from']:raise ValueError('replay source mismatch')
            if move['from']!=move['to'] and move['to'] not in set(grid.neighbors(move['from'])):raise ValueError('invalid replay edge')
            if move['from']!=move['to'] and before.has(move['to']):raise ValueError('old target occupied')
            if blocked.has(move['to']) or (move['exit'] and move['to'] not in exits):raise ValueError('invalid replay target')
            targets.append(move['to'])
        if len(targets)!=len(set(targets)):raise ValueError('replay target conflict')
        for move in event['moves']:
            occupancy.set(move['from'],False)
            if move['exit']:del positions[move['id']];evacuated+=1
            else:occupancy.set(move['to']);positions[move['id']]=move['to']
        if before.xor(Field(grid,dict(event['operator_delta_words']))).words!=occupancy.words:raise ValueError('delta does not replay')
        if occupancy.count()!=len(positions):raise ValueError('replay conservation failure')
    return {'status':'PASS','replayed_transitions':len(ledger.records)-1,'remaining':len(positions),'evacuated':evacuated}
