# Axis 0 — sparse spatial applications, v6.0

**Tom Klootwijk · NL200678942 · date supplied 10-07-1990**

This release is based on the **new 31-page attachment**, particularly its final
crowd/delta-time/implicit-zero requirements on pages 26–29. It is an application
suite, not an arithmetic demonstration or rendering engine.

The prior field-calculator prototype did not demonstrate these workflows. v6
keeps the document's native Boolean double-UU and adjacency-boundary definitions,
then supplies *explicitly labelled implementation rules* for the missing parts.
`docs/SOURCE_MAP.md` maps every source use-case family to its implementation and
remaining boundary. `docs/FORMALIZATION.md` and the companion PDF give the equations.

## Actual execution status

The C++ CPU core and all application fixtures were **compiled, executed and tested**.
The CUDA implementation shares the integer transition code but **has not been
compiled or run here**: no CUDA compiler or NVIDIA device was available. The RTL
word cell is supplied as source and **has not been synthesized or simulated here**.
This ZIP contains no precompiled GPU executable and makes no laptop-speed or
sub-milliwatt power claim. See the raw reports under `verification/`.

## Source use cases actually exercised

| Source use case | Executable result in this package |
|---|---|
| Sparse crowd / individual delta-time | Collision-resolved movement with one shared rule; event time skips absent ticks; exact occupancy replay. |
| Logistics / robot route discovery | Sparse first-arrival paths, known moving-obstacle schedules and a small exact all-city tour closure. |
| Dynamic network congestion | Earliest arrival under explicit latency/failure events with waiting. |
| Chip trace routing | Sequential single-layer routes with clearance reservations. |
| Ladybug boundary / computer vision | The actual emblem image on source page 10 becomes a binary input; boundary, dilation and erosion are computed. |
| Cellular automata dynamics | Four one-bit velocity planes; particle-conserving lattice-gas steps, not a numerical fluid renderer. |
| Display calibration and timing | Integer active-sample LUT remaps and offline device-delivery timestamp alignment. No sound, light or sensory stimuli are emitted. |
| Blockchain-like state history | Hash-linked event records plus spatially validated replay; not currency, consensus, authentication or a PUF. |

The strongest measured application fixture is **15 delayed nodes exiting a shared
bottleneck** with no double occupancy. Another sparse-time fixture executes seven
event rounds through tick 5,000, skipping 4,994 empty integer ticks between events.
A 10,000-node proposal batch checks 10,000 distinct admissible destinations. These
are synthetic cell models, not measured evidence that actual people are identical
except for delay.

## Build for the stated RTX 5070 Ti Laptop

Use CUDA 12.8 or later (SM120 support), CMake 3.24+, a CUDA-compatible C++17 host
compiler, and a compatible NVIDIA driver. Python 3.10+ with its standard library
is sufficient for the application layer; no Python package installation is needed.
The included preprocessed emblem avoids requiring an image library at runtime.

**Windows**, in a Visual Studio 2022 Developer PowerShell with the Desktop C++
workload and CUDA Visual Studio integration:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DAXIS0_ENABLE_CUDA=ON -DAXIS0_CUDA_ARCH=120
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
python tests\applications.py --kernel build\Release\axis0_cuda.exe --backend texture --quick --json verification\laptop_quick.json
```

**Linux**:

```bash
cmake -S . -B build -DAXIS0_ENABLE_CUDA=ON -DAXIS0_CUDA_ARCH=120 -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
python tests/applications.py --kernel build/axis0_cuda --backend texture --quick --json verification/laptop_quick.json
```

Build scripts `build_windows.ps1` and `build_linux.sh` run the build and the C++
truth tests. `--quick` limits the exhaustive small-map part to 243 cases; omit it
for all 19,683 allowed/seed cases. The other application tests still run.

**CPU-only**, without CUDA:

```bash
cmake -S . -B build-cpu -DAXIS0_ENABLE_CUDA=OFF -DCMAKE_BUILD_TYPE=Release
cmake --build build-cpu --config Release --parallel
python tests/applications.py --kernel build-cpu/axis0_cpu --json verification/local_cpu.json
```

On Windows the executable is `build-cpu/Release/axis0_cpu.exe`. Subsequent commands
use Linux-style paths; substitute the Windows executable path as needed.

## Run all source-oriented demonstrations

```bash
python run.py --kernel build-cpu/axis0_cpu --backend cpu --output results
```

After compiling and validating CUDA:

```bash
python run.py --kernel build/axis0_cuda --backend texture --output results-gpu
```

`application_results.json` contains actual paths, event times, route costs, crowd
exit records, calibration mismatches and execution scope. Binary `.pbm` outputs
are field-data exports, not a renderer. `crowd_events.jsonl` contains the complete
replayable event chain. The fixture's station-like layout is synthetic, not a
survey of Zaandam station. The source image is used only as the declared emblem
boundary input.

## Use your own scene, not just a fixed demo

```bash
python app.py crowd examples/crowd.json --kernel build-cpu/axis0_cpu --out crowd-run
python app.py route examples/route.json --kernel build-cpu/axis0_cpu --out route-run
python app.py network examples/network.json --out network-run
python app.py tsp examples/tour.json --out tour-run
python app.py boundary examples/emblem.pbm --kernel build-cpu/axis0_cpu --out edge-run
python app.py timing examples/timing.json --out timing-run
python app.py replay crowd-run/events.jsonl --out replay-run --expected-head HASH_FROM_RESULT
```

The crowd scene contains a finite grid, blocked cells, exit cells, and active
node records `{id, xy, delta_t, ready, priority}`. No racial, cultural, religious,
biometric or psychological categories determine those parameters. `priority`
only breaks same-target ties; it is not an assertion of social value or fairness.

The route scene contains seeds and a target in the same grid. The `moving`
subcommand additionally accepts `changes` keyed by integer time and a `horizon`.
The `eda` subcommand accepts a list of nets `{from_xy,to_xy}` and integer
`clearance`. `network` accepts directed edges with schedules `[tick,latency,up]`.
`tsp` accepts a finite nonnegative integer cost matrix; null means no edge.
These Python adapters are CPU routines even when their spatial primitives use
CUDA. The host/device boundary is explicit rather than called all-GPU computation.

## What the kernel actually does

Three native job types are shared between C++ and CUDA:

1. **Sparse stencil:** gather a shifted operator field, apply a stored four-input
   Boolean truth field, emit next-state words and their exact XOR deltas.
2. **Due-node proposal:** gather only active nodes' neighborhood occupancy and
   goal-potential data, evaluate the stored eligibility rule, emit movement
   proposals. Host code resolves same-target competition before a parallel commit.
3. **Calibrated remap:** read active sample ids and a supplied integer remap table;
   emit destinations. The host OR-compacts duplicates and drops absent entries.

The operator and A=T time records are ordinary 512-bit fields in the input atlas.
They carry their own addresses and explicit parameters. The kernel reads truth
coefficients as data; field roles and transport directions are declared. The
reader, sorting, event scheduler and conflict resolution remain explicit code.
This does not claim arbitrary self-hosting or autonomous CUDA instruction mutation.

## Sparse storage instead of unused-memory saturation

Only nonzero 32-cell words are stored as `(word_key, word_bits)`. An absent word
represents 32 zero cells. Zero positions within an active word still occupy their
bit positions; sparse indices, timing and node records cost additional memory.
Tasks cover active words and their local halo, not the entire declared domain.

The measured scaling fixture has **2,054 active cells in 128 nonzero words**. Its
one-step sparse job is **2,868 bytes** and processes **157 candidate words**, whether
the declared world has 65,536 or 1,073,741,824 cells. A dense one-bit plane for the
largest domain alone would be 128 MiB. This is sparse-domain omission, not free
storage for a fully occupied billion-cell world.

The final document asks to leave zeros implicit. v6 therefore does not fill unused
VRAM with repeated meaningless charts merely to claim saturation. Actual sparse
snapshots, operator fields, candidate batches and outputs consume device memory.
Long histories reside in the event log. Workloads can be batched by the caller;
this version does not implement permanent on-device event queues.

`--backend texture`, `global`, and `shared` compare sparse atlas access. Shared
mode stages the 64-byte current operator definition per block, not the full sparse
world. Integer texture fetches are unfiltered. The GPU resource limits are queried.
Cache lines are hardware-managed: no permanent texture-cache residency is claimed.

## Literal source versus additional closure

The exact source form `F_next = F XOR shift(O)` is available as `literal`. It is
not silently replaced. Routing needs the additional operator rule

```
O_next = neighbours_OR(O) & ~blocked & ~F
F_next = F XOR O_next   // equals OR here because O_next and F are disjoint
```

OR is used to preserve alternative arrivals; XOR collisions alone cannot establish
a single globally optimal all-city tour. The tour adapter explicitly retains
visited-subset, endpoint and cost-bit state and is therefore exponential in city
count. The document's claimed instantaneous general TSP bypass is not presented
as an achieved measurement.

The shared crowd rule uses minimum-hop potential, an empty old-snapshot target
and a deterministic conflict winner. It prevents overlap under its cell model;
it does not guarantee fairness, deadlock freedom or realistic human behavior.
A finite horizon is explicit. It is not a hidden claim of natural convergence.

## “Query-free” and implicit gaps, precisely

The event clock jumps to the next due node instead of iterating empty time ticks.
Spatial kernels process active supports only. But binary search for sparse
neighbors, event-queue operations, sorting and compaction still occur. The program
is not literally free of memory lookups. A long corridor is compressed only after
its path is supplied and checked; its traversal duration is retained. An unknown
obstacle cannot be skipped just by calling the gap implicit.

## Limits tied to the source, not silently inferred capabilities

- Binary channel registration is not a waveguide physics model or evidence of
  biological pleasure. IPD/ITD or channel offsets must be supplied/measured.
- Offline timing records do not stimulate or control a human nervous system.
- Event hashes are not consensus, currency, biometric authentication or a PUF.
  Trusting a final hash externally is different from accepting a recomputed chain.
- The HDL block is a portable source-equation primitive, not a synthesized chip.
- The lattice gas is a discrete count-conserving model, not a validated smoke or
  fluid simulator. EDA routing is sequential and single-layer, not a complete tool.
- The source's cultural and biological generalizations are not used as empirical
  laws or encoded population classes. Synthetic delta-time is a model parameter.

The PDF explains these boundaries beside the relevant source pages rather than
making blanket claims that every speculative benefit has already been implemented.
