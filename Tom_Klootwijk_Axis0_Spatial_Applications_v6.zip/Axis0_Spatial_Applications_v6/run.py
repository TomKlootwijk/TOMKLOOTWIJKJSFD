#!/usr/bin/env python3
"""Run the attached document's concrete spatial application fixtures."""
from __future__ import annotations
import argparse,copy,json,random,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'python'))
from axis0.model import Grid,Field,RULES,shift
from axis0.kernel import Kernel
from axis0.routing import wave,time_route,Edge,network_route,exact_tour,eda_routes
from axis0.crowd import Node,simulate,replay_occupancy
from axis0.interfaces import read_pbm,write_pbm,edge_profile,calibrate,event_timing,certify_corridor,lattice_gas_step
from axis0.ledger import Ledger

def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def rect_fixture():
    g=Grid(32,8);allowed=set()
    for y,row in enumerate(('S...#...','.##.#.#.','...#....','.#...##.','...#....','...#...T')):
        for x,c in enumerate(row):
            if c!='#':allowed.add(g.cell(x,y))
    return g,Field.from_cells(g,(c for c in range(g.cells) if c not in allowed))

def run_all(kernel:Kernel,out:Path):
    results={};begin=time.perf_counter_ns()
    # 1. Literal source equation remains separately executable.
    g=Grid(32,4);f=Field.from_cells(g,[g.cell(1,1)]);o=f.copy()
    after,expressed,delta=kernel.stencil(f,o,definition='literal')
    assert after.words==f.xor(shift(o,0)).words
    results['literal_source']={'field_before':list(f.active()),'operator_before':list(o.active()),
                               'field_after':list(after.active()),'delta':list(delta.active()),'source_pages':[3,21]}
    # 2. Shortest-hop logistics and exact finite tour closure.
    g,b=rect_fixture();goals=[g.cell(0,0),g.cell(7,0),g.cell(0,5),g.cell(7,5)]
    waves=[wave(kernel,b,[c]) for c in goals];path=waves[0].path(goals[-1])
    matrix=[[w.distances.get(c) for c in goals] for w in waves]
    tour=exact_tour(matrix)
    results['spatial_logistics']={'path_xy':[g.xy(c) for c in path],'hops':len(path)-1,
        'allowed_cells':g.cells-b.count(),'landmark_cells':goals,'cost_matrix':matrix,'tour':tour,
        'scope':'synthetic layout; compiled spatial kernel produces legs; CPU finite subset/cost-bitset layer selects a tour'}
    cluster=[[0 if i==j else 1 if i//3==j//3 else 10 for j in range(6)] for i in range(6)]
    results['tsp_counterexample']={'two_disconnected_triangles_cost':6,'single_tour':exact_tour(cluster),
        'meaning':'first local short connections do not by themselves define a single tour'}
    # 3. Known moving-obstacle timeline.
    g=Grid(32,4);corridor={g.cell(x,1) for x in range(1,9)};door=g.cell(4,1)
    b=Field.from_cells(g,(i for i in range(g.cells) if i not in corridor or i==door))
    results['moving_obstacle']=time_route(g,b,{5:[(door,False)]},g.cell(1,1),g.cell(8,1),20)
    # 4. Crowd's common rule plus node-local delta time, with replayable state deltas.
    scene=json.loads((ROOT/'examples/crowd.json').read_text());g=Grid(**scene['grid'])
    b=Field.from_cells(g,(g.cell(*xy) for xy in scene['blocked_xy']))
    nodes=[Node(n['id'],g.cell(*n['xy']),n['delta_t'],n.get('ready',0),n.get('priority',n['id'])) for n in scene['nodes']]
    crowd,ledger=simulate(kernel,b,[g.cell(*xy) for xy in scene['exits_xy']],nodes,scene['horizon'])
    ledger.save(out/'crowd_events.jsonl');crowd['replay']=replay_occupancy(ledger)
    tampered=copy.deepcopy(ledger.records);tampered[1]['event']['tick']+=1
    crowd['tampered_record_rejected']=not Ledger.verify(tampered,ledger.previous)
    results['crowd_delta_time']=crowd
    # 5. Network latency/failure event schedules. No packet transmission.
    edges=[Edge(0,1,((0,8,True),(3,1,True))),Edge(0,2,((0,2,True),)),
           Edge(2,3,((0,6,True),(2,6,False),(7,1,True))),Edge(1,3,((0,2,True),))]
    results['network_events']=network_route(edges,0,3)
    # 6. Feasible EDA traces under sequential reservations.
    g=Grid(32,12);closed={g.cell(x,y) for y in range(g.height) for x in range(g.width) if x in (0,31) or y in (0,11) or (x==15 and 3<=y<=7)}
    results['eda']=eda_routes(kernel,Field.from_cells(g,closed),[(g.cell(1,2),g.cell(29,2)),(g.cell(1,8),g.cell(29,8))],1)
    # 7. Use the supplied page-10 emblem as actual binary input, not decoration.
    emblem=read_pbm(ROOT/'examples/emblem.pbm');edges_result=edge_profile(kernel,emblem)
    for name in ('source','boundary','dilation','erosion'):write_pbm(out/f'emblem_{name}.pbm',edges_result[name])
    results['emblem_boundary']={**edges_result['counts'],'source_page':10,
                              'input_provenance':'nearest integer sample + stated dark-pixel threshold of the supplied emblem image; not site recognition'}
    # 8. Binary channel registration from explicit calibration parameters.
    g=Grid(64,48);base=Field.from_cells(g,((c%emblem.grid.width+16)+(c//emblem.grid.width+4)*g.width for c in emblem.active()))
    shifts={'R':(2,0),'G':(0,0),'B':(-1,1)};channels={}
    for name,(dx,dy) in shifts.items():channels[name]=Field.from_cells(g,(g.cell(g.xy(c)[0]+dx,g.xy(c)[1]+dy) for c in base.active()))
    calibrated=calibrate(kernel,channels,shifts)
    results['display_calibration']={'channels':calibrated['counts'],
        'remaining_binary_mismatches':{n:base.xor(f).count() for n,f in calibrated['corrected'].items()},
        'supplied_integer_offsets':shifts,'scope':calibrated['scope']}
    roi=Field.from_cells(g,(g.cell(x,y) for y in range(15,32) for x in range(24,40)))
    results['display_calibration']['active_cells_in_given_foveal_roi']=base.intersection(roi).count()
    # 9. Frequency/timing is event data only, never an audio/visual stimulator.
    results['timed_feedback']=event_timing([0,500000,1000000,1500000],{'visual':4000,'left':6000,'right':6300},{'visual':0,'left':0,'right':300})
    results['timed_feedback']['event_period_us']=500000
    # 10. Literal computational sparse-gap traversal retains the duration.
    g=Grid(1024,1);certificate=certify_corridor(g,Field(g),list(range(1024)))
    certificate.pop('verified_path');results['implicit_zero_gap']=certificate
    # 11. Four-plane Boolean lattice gas: count-conserving microdynamics, not smoke realism.
    g=Grid(32,16);b=Field.from_cells(g,(g.cell(x,y) for y in range(16) for x in range(32) if x in (0,31) or y in (0,15) or (x==16 and y in range(4,12))))
    rng=random.Random(20260918);channels=[Field(g) for _ in range(4)]
    open_cells=[i for i in range(g.cells) if not b.has(i)]
    for direction in range(4):
        for cell in rng.sample(open_cells,24):channels[direction].set(cell)
    total=sum(c.count() for c in channels)
    for _ in range(24):channels=lattice_gas_step(kernel,channels,b)
    results['cellular_boundary_dynamics']={'model':'four-velocity Boolean lattice gas construction','ticks':24,
        'initial_directional_particles':total,'final_directional_particles':sum(c.count() for c in channels),
        'occupied_direction_words':sum(len(c.words) for c in channels),'numeric_fluid_physics_validated':False}
    results['execution']={**kernel.metrics(),'application_wall_ns':time.perf_counter_ns()-begin,
                         'gpu_execution':kernel.backend!='cpu','source_document_pages':31}
    save(out/'application_results.json',results)
    return results

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--kernel',type=Path,required=True)
    p.add_argument('--backend',choices=('cpu','texture','global','shared'),default='cpu')
    p.add_argument('--output',type=Path,default=ROOT/'results');a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    with Kernel(a.kernel,a.backend) as kernel:results=run_all(kernel,a.output)
    print(json.dumps({'report':str(a.output/'application_results.json'),
         'crowd':{k:results['crowd_delta_time'][k] for k in ('initial_nodes','evacuated','remaining','event_rounds')},
         'route_hops':results['spatial_logistics']['hops'],'network_arrival':results['network_events']['arrival'],
         'registration_mismatches':results['display_calibration']['remaining_binary_mismatches'],
         'backend':a.backend},indent=2))
if __name__=='__main__':main()
