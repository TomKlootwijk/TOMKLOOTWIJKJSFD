#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
cmake -S . -B build -DAXIS0_ENABLE_CUDA=ON -DAXIS0_CUDA_ARCH="${AXIS0_CUDA_ARCH:-120}" -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
printf '\nNext: python tests/applications.py --kernel build/axis0_cuda --backend texture --quick --json verification/laptop_quick.json\n'
