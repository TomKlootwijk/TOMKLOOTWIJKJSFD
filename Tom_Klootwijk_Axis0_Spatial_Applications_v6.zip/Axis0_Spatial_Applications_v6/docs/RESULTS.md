# Executed application results (v6.0)

The newly attached 31-page source is the governing application basis. CPU-only results; CUDA/FPGA execution was unavailable.

## Spatial and temporal use cases

- Shared bottleneck: 15 nodes exited, 104 event rounds, 501 due proposals, 4 same-target losers, last exit tick 110; replay conserved occupancy.
- Long-delay fixture: three exits by tick 5,000, seven event rounds, ten due-node proposals, 4,994 absent integer ticks skipped.
- Larger batch: 10,000 proposal targets checked against the expected neighboring cells; no duplicate destinations.
- Static path: 12 hops. Four-landmark closed tour: 34 hops. Moving door: earliest arrival tick 9.
- Network scheduled latency/failure fixture: earliest arrival tick 6. Two EDA nets: feasible 28-hop routes each.
- Source emblem: 168 active input samples; boundary 309, dilation 351, erosion 42.
- Three synthetic channel shifts: corrected to zero Boolean mismatch using supplied integer LUTs.
- Discrete four-velocity lattice gas: 96 directional particles preserved over 24 steps. Not a validated fluid simulation.

## Sparse empty-space experiment

2,054 active cells, 128 nonzero word records, 157 candidate words. Input job 2,868 bytes at every domain size. Timing is one evaluated first-arrival step, excludes setup, not full routing.

| Domain cells | Sparse median ns | Dense packed median ns |
|---:|---:|---:|
| 65,536 | 12,248 | 4,557 |
| 4,194,304 | 11,199 | 260,131 |
| 1,073,741,824 | 11,295 | 148,364,679 |

Small dense domains can favor direct packed sweeps. A huge empty domain need not be scanned by the sparse profile. The measurements do not predict whole-application or GPU speedups. Raw samples and exact methodology are in `verification/sparse_dense_benchmark.json`.

## Validation

19,683 exhaustive 3x3 allowed/seed cases; 432 literal shifts; 432 stencil profiles; 96 remaps; 40 delayed crowd scenarios; 120 scheduled-network graphs; 72 finite TSP graphs compared with complete enumeration; 80 timing configurations. Shared truth tests checked 2,097,152 lane assertions. CPU sanitizer runs passed.

No emitted stimuli, real-person response study, PUF test, consensus deployment, FPGA power measurement or GPU execution is reported.
