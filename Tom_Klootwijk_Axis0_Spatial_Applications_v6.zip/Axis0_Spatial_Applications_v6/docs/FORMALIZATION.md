# Klootwijk sparse spatial applications — formalization v6.0

Tom Klootwijk / NL200678942 / date supplied 10-07-1990.
Primary source: the attached 31-page ladybug / Boolean double-UU continuation.
This specification separates source definitions, implementation closures and
measured finite results. SOURCE_MAP.md supplies page-level traceability.

## 1. Source-native phase fields, not a numeric-SDF calculator

For a finite declared subset X of the source's Z^d domain, use Boolean fields
F_t=U_F and O_t=U_O. A field's source-defined boundary is

    boundary(F_t) = {x in X: some adjacent y has F_t(x) != F_t(y)}.

Outside an open finite border the phase is zero. Polar and Klein-seam address
profiles replace border adjacency by the stated identifications. This is the
source's binary phase-SDF convention (pp. 3, 21), not a claim that each bit stores
a scalar distance magnitude. Fields have explicit roles: occupied, frontier,
blocked, target, channel, or expressed change. Those role names are not silently
interchanged (e.g. open=1 in a mask does not mean occupied=1).

Each native Boolean operator definition is sixteen uint32 words whose bits have
the same phase-field/adjacency reading. The record carries a truth table,
transport mask, output mode, self-id and time-id. Truth coefficients are read as
data by the shared kernel. References, dimensions and ticks still need multiple
bits. The finite reader and scheduler are declared machinery, not magically
eliminated external instructions.

## 2. Source XOR law and explicit completed profiles

A directional shift is (S_d O)(x)=O(x-d) on admitted neighbors, zero outside an
open domain. The literal supplied update is preserved:

    F_(t+1) = F_t XOR S_d(O_t).

It does not by itself determine O_(t+1), choose directions, resolve multiple
arrivals, or specify a stopping/readout rule. The v6 literal profile accepts O
and a chosen direction. It is not advertised as a complete optimizer.

For routing, define candidate arrival C=N_OR(O), allowed A=NOT blocked, then

    O' = C AND A AND NOT F,
    F' = F XOR O' = F OR O'.

This is an explicitly added closure. OR retains existence when multiple valid
paths meet. XOR would cancel an even number of arrivals. The final update still
has source form because O' is disjoint from F.

Initialization F0=O0=seeds. By induction, frontier O_n is exactly the allowed
vertices at minimum hop distance n, and F_n contains distances at most n.
A shortest n+1 path has an n-step predecessor, and the visited exclusion prevents
an earlier distance. A finite nonempty wave exhausts after at most |allowed|
updates; empty seeds stop immediately. Paths are decoded from stored parents,
which are additional metadata. These statements concern a fixed equal-cost
adjacency graph, not arbitrary physical lengths or moving obstacles.

Boundary detection, dilation and erosion use the same reader with different
truth fields. Let b=N_OR(F), c=N_AND(F), d=allowed, a=F. Their next-field tables are

    boundary = (a AND NOT c) OR (NOT a AND b)
    dilation = (a OR b) AND d
    erosion  = a AND c AND d.

The output-mode flag says whether the truth result is the next field or the
expressed delta. Every result carries delta=F XOR F' so it can be replayed.
The four-input truth-table row is a+2b+4c+8d. Direction bits E,W,N,S are explicit.

## 3. Sparse packing and the actual meaning of query-free

A cell x+y*width occupies bit (x mod 32) in word key y*(width/32)+floor(x/32).
Store only (word_key,word_bits) entries with word_bits != 0. Missing word keys
mean 32 zeros. Zero bits within an active word are still present in that word;
this is sparse word packing, not a claim that index metadata costs nothing.

A field with K stored words has an 8K-byte serialized payload (4-byte key and
4-byte bitword), before language/allocator overhead. A single isolated bit may
cost more in this representation than one entry in a sparse cell-coordinate list;
dense occupancy may favor ordinary packed arrays. Those are explicit tradeoffs.

Stencil tasks are generated only from the nonzero operator-word neighborhood,
plus active field keys when a replacement operation must clear old bits. Runtime
lookup uses binary search in sorted sparse rows. No dense scan through every zero
cell is performed, but this is NOT literally zero queries or zero memory access.
With K field records and C candidate words, the gathered stencil has finite
O(C log K) lookup work up to a fixed number of fields/directions; construction,
sorting and compaction also cost time. Python dictionaries have additional
implementation overhead not included in the serialized 8K formula.

A large empty corridor may be compiled to endpoints plus an integer duration only
when a geometry certificate or provided adjacency establishes the interior. v6
validates the entire supplied path once. The runtime then skips empty event ticks
while retaining duration. It never jumps across an unknown obstacle for free.

## 4. A=T, delta-time and synchronous event commits

Object id zero is A=T, an explicit time-definition record with a 64-bit tick and
self-reference. Its crowd scheduling policy is

    t_next = min {due_i : node i remains active}.

Node i has an explicitly assigned positive integer period delta_i. At its due
event, it can propose one admitted neighboring cell; afterward its next deadline
is t+delta_i. Clock overflow is checked. Deadline changes are part of event data.
All due nodes see the SAME occupancy snapshot. The scheduler skips absent event
times; it does not skip physical travel or make t equal to wall-clock execution.

Node-local delta is a parameter of this synthetic model, not a measured theory
that personality, ancestry, religion or actual human behavior is only a time lag.
No geographic or cultural data is used to choose the delays.

## 5. Crowd closure and proof obligations

A precomputed goal-directed potential P(x) is the minimum static graph-hop distance
to an exit under the declared blocked map. It is constructed by the compiled
wave kernel. A due node at x proposes a neighbor y only if:

    P(y) < P(x), F_t(y)=0, blocked(y)=0.

The common three-input eligibility table is 0x80. Among eligible neighbors it
chooses minimum (P(y),y). Nodes already at exits propose exit removal. Competing
proposals to the same target are resolved by minimum (priority,id), a deterministic
implementation choice NOT supplied by the source. Priorities need not express
human worth, fairness or biological characteristics; they only break a data tie.

First decide all winners, then commit their departures and targets simultaneously.
Old occupied cells are not eligible destinations, so there are no head-on swaps
or chains that rely on a neighbor leaving in the same event. This conservative
rule can reduce throughput. It does not guarantee deadlock freedom or fairness.
A finite horizon is an explicit requested simulation boundary, not a convergence
claim.

With accepted non-exit moves x_i -> y_i and exit departures e_j, remove every x_i
after selection, add every y_i, and remove e_j. Targets are distinct and were
empty, so occupied_count + exited_count is invariant. The expressed operator is

    O_event = F_before XOR F_after.

Its sparse word record replays the commit exactly. Invariants checked each event:
no duplicate occupancy, no blocked occupancy, no nonadjacent move, no old-target
occupancy, count conservation with exits, and exact XOR delta. Node records use
32 bytes of integer metadata in the kernel ABI in addition to the field mask.
This is not a continuous personal-space, biomechanical or behavioral model.

## 6. Logistics and networking

Static spatial routes use the wave proof. The moving-obstacle CPU adapter uses
states (cell,tick), includes waiting, and requires the destination to be unblocked
at the arrival tick. It is exact within a supplied finite horizon under those
sampled-time rules. It does not prove continuous swept-volume collision freedom.

The network adapter accepts known edge-change schedules (time,positive latency,
enabled). An edge's traversal latency and enabled flag are sampled at departure.
In-flight traffic is not retroactively cancelled. Waiting at nodes is allowed.
For earliest node arrival a, admissible candidate departures are a and future
edge-change times. Choosing minimum (departure+latency,departure) gives the best
outgoing arrival. Earlier node arrival dominates a later one because it can wait;
a priority-queue label-setting algorithm therefore finds the earliest arrival
under this convention. Schedule changes, sparse adjacency and integer timestamps
are real stored metadata. This is not deployment into a radio/network controller.

The exact TSP extension is CPU code with subset/endpoint cost bitsets. Bit c of
B[S,j] states that a start-to-j route visiting exactly S has cost c. Extending by
edge cost w is a bit shift:

    B[S union {k},k] |= B[S,j] << w(j,k).

Closing to the start produces possible complete-tour costs; the lowest set bit
is the minimum. A predecessor membership test reconstructs the tour. Subset state
count is exponential and cost-bit span depends on edge costs. No floating cost
sums are needed in the DP, but integer indexing and route reconstruction remain.
The source's claim that first XOR collisions alone guarantee an optimal tour is
NOT silently adopted. The extension supplies the missing global history.

EDA uses sequential single-layer routes and explicit neighborhood clearance
reservations. A path is shortest among currently available cells; the ordering
can block later nets and does not guarantee global wirelength optimality.

## 7. Emblem, cellular boundaries and calibration

The embedded emblem from page 10 is an actual supplied input. Its 235x294 image
is sampled at integer pixel centers into a 32x40 mask, with threshold
(77*R+150*G+29*B)//256 < 120. This produces 168 active input cells. The threshold
is an explicit conversion convention, not learned object recognition or location
proof. Boundary and morphology are then calculated on that binary field.

The cellular-gas profile is a NEW four-velocity Boolean construction: isolated
opposite horizontal particles turn into a vertical pair and vice versa; otherwise
they retain their velocity. Every direction is a separate Boolean plane. Streaming
uses the compiled shift kernel; obstacles reflect blocked streams at their source.
Particle count is conserved in this discrete model. It is not a validated fluid,
smoke, fracture or photorealistic effects simulation.

A calibration LUT maps an active source sample to an integer destination. The
compiled remap kernel reads only active inputs. Destination collisions combine
by OR and can lose information; unmatched entries are explicitly dropped.
Known synthetic channel shifts are inverted exactly in the fixture. The kernel
does not infer a lens model, IPD/ITD, subpixel reconstruction or a person's biology.

Timing adapters compute command stamps from supplied device latencies and desired
relative delivery offsets. A 500,000-microsecond period is only an offline event
schedule. No sound/light stimulation is emitted. Comfort, pleasure, dopamine and
geographic/evolutionary claims in the export are not validated by these tests.

## 8. Event ledger, not consensus or currency

Every committed event records its timestamp, due node ids, moves, XOR delta,
next deadlines and conflict count. Genesis binds the grid, blocked field, exits,
initial active-node metadata and conflict rule. Each record contains the previous
SHA-256 and the hash of its own canonical JSON. Replay checks both chain structure
and the actual spatial constraints. Changing a record without updating the chain
is detected. With an independently trusted final hash, removal/rewriting changes
the expected head. Without such an anchor, a party can recompute a different chain.

This is reproducible event history and tamper evidence, NOT proof of physical
presence, PUF-derived keying, authentication, Byzantine consensus, unmanipulable
currency or an economic/governance theorem. The source supplies none of the
protocol parameters needed to establish those broader properties.

## 9. Host/device split and practical limits

The CPU/CUDA core evaluates sparse word stencils, due-node move proposals, and
calibrated active-sample remaps. Python supplies event scheduling, sorted sparse
assembly/compaction, goal-distance readout, target-conflict resolution, time-route
and network planning, exact tour closure and log writing. This is a working
hybrid use-case pipeline, not an all-device autonomous implementation.

CUDA texture mode reads the immutable sparse atlas with unsigned integer
tex1Dfetch. Global mode uses ordinary reads; shared mode stages the 16-word
operator definition in shared memory and texture-reads sparse data. Inputs and
outputs are distinct; no same-launch texture read-after-write is assumed. A
persistent worker avoids process creation per event, but each job still uploads
its active atlas and downloads its results. On-device-resident comparisons are
separate from end-to-end timings. There is no permanent texture-cache pin.

Rectangular, log-polar and reflected-seam layouts are address profiles. In the
polar convention, angular cell centers use (x+1/2)/width turns and radial row y
may be labelled log_phi(r/r0)=y/64. No actual trig/float coordinates are evaluated.
Shortest native-hop paths are not automatically physical shortest distances.
The final source emphasis on implicit zeros is respected: v6 does not fill unused
VRAM with meaningless repeated definitions. Active workloads and event history
consume memory as required.
