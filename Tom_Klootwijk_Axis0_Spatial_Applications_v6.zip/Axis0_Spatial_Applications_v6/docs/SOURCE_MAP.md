# Fidelity map to the newly attached 31-page document

Identity: Tom Klootwijk / NL200678942 / date supplied 10-07-1990.
The attachment includes author prompts and accompanying generated responses. A
statement's presence is source evidence; it is not independent proof of the
response's performance, biological, security or societal assertions.

| Source pages | Source requirement / use case | v6 executable response | Exact boundary |
|---|---|---|---|
| 2–4, 21 | Boolean double UU; phase SDF; U_F XOR shifted U_O | Literal directional XOR profile; sparse field/operator records; every result has a replayable XOR delta | Direction and finite domain are explicit. The document does not supply a complete next-operator rule. |
| 6–9, 20, 28 | Mirror/prism interpretation questioned; return to raw binary | No optics, prisms, analog Hadamard or ray tracing. Optional polar/Klein address seams only | Cone/double-Hadamard/hinge names have no assigned executable transition in the source. They are not given fabricated physical meanings. |
| 10–11 | Ladybug emblem as a boundary/anchor | Actual embedded emblem from page 10 is converted to a stated binary mask and processed by boundary/dilation/erosion kernels | It is an uploaded image template, not proof of geographic position or a surveyed station map. |
| 5, 11–12, 22 | Robotics, logistics and route discovery | Compiled sparse first-arrival kernel; reconstructed shortest-hop paths; bounded moving-obstacle planner | OR combines alternatives before a source-form XOR commit. Static hops and discrete-time occupancy are explicit metrics; not continuous collision proof. |
| 1–4, 22 | TSP / all-city routes | Small exact subset/endpoint/cost-bitset tour layer fed by spatial leg distances | Additional CPU closure. Exponential subset states remain; first XOR collisions alone are not asserted to solve TSP. |
| 5, 12 | Network failures/congestion represented in time | Sparse event router with supplied edge-enable/latency change schedules | Earliest arrival under waiting and departure-sampled costs; not deployed 6G firmware or mid-flight packet rerouting. |
| 6 | EDA wire routing | Sequential single-layer paths and explicit clearance reservations | Feasible fixture, not simultaneous global optimum or full manufacturing design-rule checking. |
| 5, 12 | Cellular automata physics, edge detection | Binary boundary kernel and four-velocity particle-conserving lattice-gas construction | Four one-bit velocity planes. No validated continuum smoke/fluid/fracture model. |
| 12, 22 | FPGA/ASIC spatial coprocessor | Shared integer C++/CUDA core and a direct source-equation SystemVerilog word cell | CUDA not compiled/run here; RTL not synthesized/simulated here; no power claim. |
| 13–17, 18–22 | Feedback timing, history, display-channel correction, IPD/ITD | Integer event schedules, explicit channel delivery offsets, sparse binary sample-remap LUT, supplied ROI | Offline data/calibration adapter. No emitted stimuli, biological pleasure proof, optics model or automatic headset calibration. |
| 18–20, 23–26 | Geographic/cultural/biological offsets | Anonymous numeric offsets are accepted only when explicitly supplied to a model | No ancestry, religion or geography-to-behavior/physiology mapping is inferred. Human diversity is not measured by this kernel. |
| 26–27 | Shared crowd rule; individual expression as delta-time | Sparse occupied anchors plus positive per-node delay; due-event batching; deterministic conflict resolution | Synthetic cell-occupancy model, not an assertion that actual people differ only by delay. Node identifiers/timers are additional metadata. |
| 28–29 | Store active ones, implicit zeros, query-free event progression | Only nonzero 32-cell words stored; active-halo tasks and due nodes only; certified corridor durations retained; clock jumps to next event | Neighbor lookups, sorting and event-queue queries remain. No zero-cost memory or literal absence of queries is claimed. |
| 27–31 | Blockchain-like shared state history, community validation | Canonical event log with hash links, source/rule genesis and occupancy replay | Tamper evidence relative to a trusted head; not PUF authentication, distributed consensus, a token, currency or governance system. |
| 6, 19–20 | PUF/private-key/proof-of-presence claims | Scope recorded; no custom secret-key or biometric protocol invented | Requires actual device response data, error model, threat model and cryptographic protocol absent from the source. |

## Source decisions that were NOT silently replaced

The literal XOR evolution is available exactly as a separate profile. The routing
closure changes how candidate arrivals are merged, and is explicitly labelled as
a new construction. The source-defined binary phase boundary is retained; v6 does
not replace the user's spatial problem with the v5 arithmetic demonstration or
with a new canonical metric-SDF information codec. SDF in this document's sense
means the native phase field and adjacency interface, not a floating distance.

The source's final sparse/event-driven emphasis takes priority over filling VRAM
with unused copies. The application kernel allocates actual active tasks and
fields. Dense fixed input buffers and arbitrary cache padding are not called
self-replication. Stored operator tables and the A=T event-time record use the
same packed-bit carrier as application fields, but the host scheduler/validator
and hardware decoder remain explicit bootstrap machinery.
