# Sources

## Primary requested basis

**S31:** `ladybug anti violence tile in zaandam at the train station got me to
thinking about the travling salesman NP hard problem where humans try to solve
infinity by defining points instead of signed distance fields and packing thos.pdf`,
31 pages, newly supplied with this request. This is the governing source for v6.
The file contains both author-issued prompts and generated explanatory answers;
these are distinguished in SOURCE_MAP.md and in the formalization.

Important locations: literal definitions pp. 3 and 21; initial practical use cases
pp. 5–6; optical-regression correction pp. 8–9; actual emblem image p. 10; binary
spatial use cases pp. 11–12; feedback/timing pp. 13–17; calibration/biometric claims
pp. 18–22; individual delay/crowd model pp. 26–27; implicit-zero/event-driven
representation pp. 28–29; ledger and societal claims pp. 29–31.

**Earlier source context:** the six-page original Axis 0 definition, the eight-page
temporal continuation, and six-page ladybug precursor are contextual only. The
latest 31-page source's application and sparsity requirements are not replaced
by the previous generic arithmetic demonstrations. The source's use of SDF as a
binary phase map is preserved; no continuous metric field is fabricated.

## Official implementation documentation, consulted 18 September 2026

**N1:** NVIDIA CUDA C++ Programming Guide 12.8.1. Integer tex1Dfetch,
shared memory, texture coherence and cache/resource constraints.
https://docs.nvidia.com/cuda/archive/12.8.1/cuda-c-programming-guide/index.html

**N2:** NVIDIA CUDA 12.8 Features Archive. SM120 compiler support.
https://docs.nvidia.com/cuda/archive/12.8.0/cuda-features-archive/index.html

These documents support CUDA API choices only. No outside source is used to
silently endorse or replace the attachment's biological, cultural, political,
economic or cryptographic assertions. The measurable software invariants are
proved or tested from the specific implementation rules introduced in v6.
