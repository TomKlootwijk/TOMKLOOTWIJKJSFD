#!/usr/bin/env python3
"""Audit authored compute source and, with an installed nvcc, actual generated PTX.

A source token scan alone is NOT a generated machine-code proof. Third-party
CUDA/driver internals are outside the claim about the calculation kernels.
"""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--compile',action='store_true');p.add_argument('--arch',default='compute_120');p.add_argument('--out',type=Path,default=ROOT/'verification/integer_audit.json');a=p.parse_args()
report={'source_status':'PASS','ptx_compile':'NOT_RUN','ptx_float_audit':'NOT_RUN','files':{}}
for path in ('include/tom/core.hpp','cuda/main.cu'):
    raw=(ROOT/path).read_text();plain=re.sub(r'//[^\n]*|/\*.*?\*/','',raw,flags=re.S)
    tokens=re.findall(r'\b(?:float|double|__half|__nv_bfloat16)\b',plain)
    report['files'][path]={'sha256':hashlib.sha256(raw.encode()).hexdigest(),'floating_type_tokens':tokens}
    if tokens:report['source_status']='FAIL'
if a.compile:
    compiler=shutil.which('nvcc')
    if compiler is None:report['ptx_compile']='UNAVAILABLE: nvcc not installed'
    else:
        target=ROOT/'verification/tom_kernel.ptx'
        cmd=[compiler,'--ptx','-std=c++17',f'-arch={a.arch}','-I',str(ROOT/'include'),str(ROOT/'cuda/main.cu'),'-o',str(target)]
        completed=subprocess.run(cmd,capture_output=True,text=True);report['command']=cmd;report['compiler_output']=completed.stdout+completed.stderr
        report['ptx_compile']='PASS' if completed.returncode==0 else 'FAIL'
        if not completed.returncode:
            lines=[line for line in target.read_text().splitlines() if re.search(r'\.(?:f16x2|f16|f32|f64|bf16)\b',line) and not line.strip().startswith('//')]
            report['floating_ptx_lines']=lines;report['ptx_float_audit']='REVIEW_REQUIRED' if lines else 'PASS'
report['scope']='Authored computation paths only; source inspection is not substituted for compiled PTX/SASS evidence or an on-device test.'
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if report['source_status']=='FAIL' or report['ptx_compile']=='FAIL':raise SystemExit(1)
