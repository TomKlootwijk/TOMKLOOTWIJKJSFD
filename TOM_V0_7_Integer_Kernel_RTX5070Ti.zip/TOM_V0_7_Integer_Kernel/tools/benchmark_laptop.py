#!/usr/bin/env python3
"""Compare GPU memory paths and verified kernel lowering with fixed batch sizes.

This tool does not change clocks, voltages, firmware, drivers or power policies.
Times are integer nanoseconds, not inferred from peak hardware specifications.
"""
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'python'))
from tom.compiler import Image

def call(exe,args):return json.loads(subprocess.run([str(exe),*args],capture_output=True,text=True,check=True).stdout)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--exe',type=Path,required=True);p.add_argument('--program',type=Path,default=ROOT/'examples/tom_conformance.tsdf')
    p.add_argument('--lanes',type=int,default=262144);p.add_argument('--ticks',type=int,default=8);p.add_argument('--samples',type=int,default=5);p.add_argument('--percent',default='')
    p.add_argument('--out',type=Path,default=ROOT/'verification/laptop_benchmark.json');a=p.parse_args();a.exe=a.exe.resolve();a.program=a.program.resolve()
    if a.samples<1 or a.ticks<1 or a.lanes<32 or a.lanes%32:p.error('positive counts; lanes multiple of 32')
    im=Image.load(a.program);hardware=call(a.exe,['--info']);batch_sizes=[a.lanes]
    for percent in filter(None,a.percent.split(',')):
        value=int(percent)
        if not 1<=value<=100:p.error('percent must be 1..100')
        free=call(a.exe,['--info'])['free_bytes'];budget=(free//100)*value
        words=(budget-len(im.words)*4)//(4*(2*im.header[8]+im.header[9]))
        if words<1:raise RuntimeError('selected memory budget fits no lane word')
        batch_sizes.append(words*32)
    report={'hardware':hardware,'program':a.program.name,'gpu_executed':True,'cases':[],
      'scope':'identical definition/data for all modes; timer includes launches and completion, not setup; no trace export; sample verification not exhaustive high-batch validation'}
    backends=['texture','global']+(['shared'] if len(im.words)*4<=hardware['shared_optin_bytes'] else [])
    for lanes in batch_sizes:
        cases={(backend,evaluator):[] for backend in backends for evaluator in ('field','lowered')}
        common=['--program',str(a.program),'--lanes',str(lanes),'--ticks',str(a.ticks),'--verify']
        first_digest=None
        # One warmup per choice; rotate order of subsequent independent runs.
        options=list(cases)
        for backend,evaluator in options:call(a.exe,[*common,'--backend',backend,'--evaluator',evaluator])
        for sample in range(a.samples):
            order=options[sample%len(options):]+options[:sample%len(options)]
            for backend,evaluator in order:
                result=call(a.exe,[*common,'--backend',backend,'--evaluator',evaluator])
                if not result['sample_verified']:raise RuntimeError('GPU output not verified')
                if first_digest is None:first_digest=result['sample_digest']
                if result['sample_digest']!=first_digest:raise RuntimeError('different outputs across execution modes')
                cases[(backend,evaluator)].append(result)
        item={'lanes':lanes,'choices':[]}
        for (backend,evaluator),samples in cases.items():
            median=sorted(x['elapsed_host_ns'] for x in samples)[len(samples)//2]
            item['choices'].append({'backend':backend,'evaluator':evaluator,'median_ns':median,
              'transitions_per_second_integer_floor':lanes*a.ticks*1_000_000_000//max(1,median),'samples':samples})
        report['cases'].append(item);a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'PASS','result':str(a.out),'executed_batches':len(report['cases'])}))
if __name__=='__main__':main()
