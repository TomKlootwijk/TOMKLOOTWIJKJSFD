param([string]$Arch = "120")
$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DTOM_ENABLE_CUDA=ON "-DTOM_CUDA_ARCH=$Arch"
    if ($LASTEXITCODE -ne 0) { throw "CMake failed. Check nvcc, supported Visual Studio C++ tools and CUDA VS integration." }
    cmake --build build --config Release --parallel
    if ($LASTEXITCODE -ne 0) { throw "Build failed; no GPU validation result has been produced." }
    ctest --test-dir build -C Release --output-on-failure
    if ($LASTEXITCODE -ne 0) { throw "Integer-core tests failed." }
    Write-Host "Next: python tools\validate_laptop.py --exe build\Release\tom_cuda.exe --quick --out verification\laptop"
} finally { Pop-Location }
