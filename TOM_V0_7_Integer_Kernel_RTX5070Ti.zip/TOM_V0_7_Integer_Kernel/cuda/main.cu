// TOM V0.7 validation backend for SM120. The SDF declaration tape describes
// the evaluator and the programs. CUDA machine instructions remain the explicit
// physical bootstrap. No source-native spatial graph or metric is introduced.
#include <cuda_runtime.h>
#include "tom/cli.hpp"
#include <memory>
namespace tom::gpu {
inline void check(cudaError_t code,const char* operation) {
    if(code!=cudaSuccess)throw std::runtime_error(std::string(operation)+": "+cudaGetErrorString(code));
}
template<class T>class Buffer {
    T* pointer_=nullptr;std::size_t size_=0;
public:
    explicit Buffer(std::size_t n):size_(n) {
        if(n>std::numeric_limits<std::size_t>::max()/sizeof(T))throw std::overflow_error("device allocation size");
        if(n)check(cudaMalloc(reinterpret_cast<void**>(&pointer_),n*sizeof(T)),"cudaMalloc");
    }
    ~Buffer(){if(pointer_)cudaFree(pointer_);}Buffer(const Buffer&)=delete;Buffer& operator=(const Buffer&)=delete;
    T* data()const{return pointer_;}std::size_t size()const{return size_;}
    void upload(const T* source,std::size_t n,std::size_t offset=0) {
        if(offset>size_||n>size_-offset)throw std::out_of_range("device upload extent");
        check(cudaMemcpy(pointer_+offset,source,n*sizeof(T),cudaMemcpyHostToDevice),"upload packed fields");
    }
    void download(T* destination,std::size_t n,std::size_t offset=0)const {
        if(offset>size_||n>size_-offset)throw std::out_of_range("device download extent");
        check(cudaMemcpy(destination,pointer_+offset,n*sizeof(T),cudaMemcpyDeviceToHost),"download packed fields");
    }
};
class Texture {
    cudaTextureObject_t object_=0;
public:
    Texture(const Word* pointer,std::size_t words) {
        cudaResourceDesc r{};r.resType=cudaResourceTypeLinear;
        r.res.linear.devPtr=const_cast<Word*>(pointer);
        r.res.linear.desc=cudaCreateChannelDesc<unsigned int>();
        r.res.linear.sizeInBytes=words*sizeof(Word);
        cudaTextureDesc d{};d.readMode=cudaReadModeElementType;
        d.normalizedCoords=0;d.filterMode=cudaFilterModePoint;d.addressMode[0]=cudaAddressModeClamp;
        check(cudaCreateTextureObject(&object_,&r,&d,nullptr),"create unsigned integer texture");
    }
    ~Texture(){if(object_)cudaDestroyTextureObject(object_);}Texture(const Texture&)=delete;
    cudaTextureObject_t get()const{return object_;}
};
template<int Backend>struct Reader {
    const Word* atlas;const Word* previous;
    cudaTextureObject_t atlas_texture,previous_texture;
    __device__ __forceinline__ Word definition(Word address)const {
        if constexpr(Backend==0)return tex1Dfetch<unsigned int>(atlas_texture,static_cast<int>(address));
        else return atlas[address];
    }
    __device__ __forceinline__ Word data(Word address)const {
        if constexpr(Backend==1)return previous[address];
        else return tex1Dfetch<unsigned int>(previous_texture,static_cast<int>(address));
    }
};
template<int Backend,bool Lowered>
__global__ void execute_kernel(const Word* definition,const Word* old,
    cudaTextureObject_t definition_texture,cudaTextureObject_t old_texture,
    Word* scratch,Word* next,Header h,Word words) {
    extern __shared__ Word shared_definition[];
    const Word* image=definition;
    if constexpr(Backend==2) {
        for(Word i=threadIdx.x;i<h.atlas_words;i+=blockDim.x)shared_definition[i]=definition[i];
        __syncthreads();image=shared_definition;
    }
    Reader<Backend> reader{image,old,definition_texture,old_texture};
    for(Word w=blockIdx.x*blockDim.x+threadIdx.x;w<words;w+=blockDim.x*gridDim.x)
        transition<Lowered>(reader,scratch,next,h,words,w);
}
__global__ void initialize(const Word* definition,Header h,Word* state,Word words,Wide first_word) {
    for(Word w=blockIdx.x*blockDim.x+threadIdx.x;w<words;w+=blockDim.x*gridDim.x) {
        Wide global=first_word+w;
        for(Word id=0;id<h.records;++id) {
            const Word* r=definition+id*16;if(r[0]!=State)continue;
            Word value=0;
            if(r[2]==1)value=FULL;
            else if(r[2]==2)for(Word bit=0;bit<32;++bit)value|=Word((((global<<5)+bit)>>r[3])&1u)<<bit;
            else if(r[2]==3)value=seed_mix(Word(global)^Word(global>>32)^r[3]);
            state[r[1]*words+w]=value;
        }
    }
}
struct Shard {
    Word words;Wide first_word;
    Buffer<Word> state0,state1,scratch;
    std::unique_ptr<Texture> texture0,texture1;
    Shard(const Image& p,Word w,Wide first,bool use_texture):words(w),first_word(first),
      state0(std::size_t(p.h.states)*w),state1(std::size_t(p.h.states)*w),scratch(std::size_t(p.h.scratch_slots)*w) {
        if(use_texture){texture0=std::make_unique<Texture>(state0.data(),state0.size());texture1=std::make_unique<Texture>(state1.data(),state1.size());}
    }
    Buffer<Word>& state(int parity){return parity?state1:state0;}
    cudaTextureObject_t texture(int parity)const {
        const auto& t=parity?texture1:texture0;return t?t->get():0;
    }
};
unsigned blocks(Word words,Word block,const cudaDeviceProp& p) {
    return std::max(1u,std::min((words+block-1)/block,unsigned(std::max(1,p.multiProcessorCount))*8u));
}
template<bool Lowered>
void launch(Shard& shard,int parity,int backend,const Image& p,const Buffer<Word>& definitions,
            cudaTextureObject_t atlas_texture,Word block,const cudaDeviceProp& properties) {
    const Word* old=shard.state(parity).data();Word* next=shard.state(1-parity).data();
    unsigned count=blocks(shard.words,block,properties);
    if(backend==0)execute_kernel<0,Lowered><<<count,block>>>(definitions.data(),old,atlas_texture,shard.texture(parity),shard.scratch.data(),next,p.h,shard.words);
    else if(backend==1)execute_kernel<1,Lowered><<<count,block>>>(definitions.data(),old,0,0,shard.scratch.data(),next,p.h,shard.words);
    else execute_kernel<2,Lowered><<<count,block,std::size_t(p.h.atlas_words)*4>>>(definitions.data(),old,0,shard.texture(parity),shard.scratch.data(),next,p.h,shard.words);
    check(cudaGetLastError(),"TOM field kernel launch");
}
std::string device_info(const cudaDeviceProp& p,unsigned device) {
    std::size_t free=0,total=0;check(cudaMemGetInfo(&free,&total),"query VRAM");
    int runtime=0,driver=0;check(cudaRuntimeGetVersion(&runtime),"runtime version");check(cudaDriverGetVersion(&driver),"driver API version");
    std::ostringstream r;r<<"{\"device\":"<<device<<",\"name\":\""<<escape(p.name)<<"\",\"compute_major\":"<<p.major<<",\"compute_minor\":"<<p.minor
      <<",\"free_bytes\":"<<free<<",\"total_bytes\":"<<total<<",\"shared_default_bytes\":"<<p.sharedMemPerBlock<<",\"shared_optin_bytes\":"<<p.sharedMemPerBlockOptin
      <<",\"linear_texture_max_elements\":"<<p.maxTexture1DLinear<<",\"l2_bytes\":"<<p.l2CacheSize<<",\"sm_count\":"<<p.multiProcessorCount
      <<",\"runtime_version\":"<<runtime<<",\"driver_api_version\":"<<driver<<"}";return r.str();
}
} // namespace tom::gpu
int main(int argc,char** argv) {
    using namespace tom;using namespace tom::gpu;
    try {
        Options o=options(argc,argv);if(o.help){usage(true);return 0;}
        check(cudaSetDevice(int(o.device)),"select GPU");check(cudaFree(nullptr),"initialize CUDA context");
        cudaDeviceProp prop{};check(cudaGetDeviceProperties(&prop,int(o.device)),"device properties");
        if(o.info){emit(device_info(prop,o.device),o.json);return 0;}
        if(o.program.empty())throw std::invalid_argument("--program required");
        Image p=load_image(o.program);check_evaluator(p,o);
        int backend=o.backend=="texture"?0:o.backend=="global"?1:2;
        const bool lower=o.evaluator=="lowered",textures=backend!=1;
        const std::size_t atlas_bytes=p.atlas.size()*4;
        if(backend==2) {
            if(atlas_bytes>std::size_t(prop.sharedMemPerBlockOptin))throw std::runtime_error("this image exceeds per-block shared-memory limit; choose texture or global");
            if(lower)check(cudaFuncSetAttribute(execute_kernel<2,true>,cudaFuncAttributeMaxDynamicSharedMemorySize,int(atlas_bytes)),"shared opt-in for lowered evaluator");
            else check(cudaFuncSetAttribute(execute_kernel<2,false>,cudaFuncAttributeMaxDynamicSharedMemorySize,int(atlas_bytes)),"shared opt-in for field evaluator");
        }
        if(textures&&(prop.maxTexture1DLinear<=0||(backend==0&&p.atlas.size()>std::size_t(prop.maxTexture1DLinear))))throw std::runtime_error("definition texture exceeds device limit");
        Data input;Wide epoch=0,total_words=o.lanes/32;
        if(!o.data.empty()){
            input=load_state(o.data);if(input.slots!=p.h.states)throw std::runtime_error("input data and program slots differ");
            if(o.lanes_given&&o.lanes!=Wide(input.words)*32)throw std::runtime_error("data case count differs from explicit lanes");
            total_words=input.words;epoch=input.epoch;
        }
        if(epoch>std::numeric_limits<Wide>::max()-o.ticks)throw std::runtime_error("epoch would wrap and erase ordering");
        const Wide bytes_per_word=(Wide(2)*p.h.states+p.h.scratch_slots)*4;
        std::size_t free_before=0,total_memory=0;check(cudaMemGetInfo(&free_before,&total_memory),"free memory before batch");
        if(o.percent) {
            Wide budget=(Wide(free_before)/100)*o.percent;
            if(budget<=atlas_bytes)throw std::runtime_error("selected budget cannot fit the definition image");
            total_words=(budget-atlas_bytes)/bytes_per_word;
        }
        if(!total_words||total_words>(std::numeric_limits<Wide>::max()-atlas_bytes)/bytes_per_word||total_words*bytes_per_word+atlas_bytes>free_before||total_words>(std::numeric_limits<Wide>::max()/32))throw std::runtime_error("requested batch does not fit queried free memory/address range");
        const Wide state_limit=textures?Wide(prop.maxTexture1DLinear)/p.h.states:Wide(FULL)/p.h.states;
        const Wide shard_words=std::min({state_limit,Wide(FULL)/p.h.scratch_slots,Wide(1)<<27});
        if(!shard_words)throw std::runtime_error("one packed lane-word exceeds indexing/texture limit");
        Buffer<Word> definitions(p.atlas.size());definitions.upload(p.atlas.data(),p.atlas.size());
        std::unique_ptr<Texture> atlas_texture;
        if(backend==0)atlas_texture=std::make_unique<Texture>(definitions.data(),definitions.size());
        std::vector<std::unique_ptr<Shard>> shards;
        for(Wide first=0;first<total_words;){
            Word words=Word(std::min(shard_words,total_words-first));auto shard=std::make_unique<Shard>(p,words,first,textures);
            if(o.data.empty()){
                initialize<<<blocks(words,o.block,prop),o.block>>>(definitions.data(),p.h,shard->state0.data(),words,first);
                check(cudaGetLastError(),"seed field generation");
            } else {
                for(Word slot=0;slot<p.h.states;++slot)
                    shard->state0.upload(input.values.data()+std::size_t(slot)*input.words+std::size_t(first),words,std::size_t(slot)*words);
            }
            shards.push_back(std::move(shard));first+=words;
        }
        check(cudaDeviceSynchronize(),"initialization complete");
        Shard& first=*shards.front();
        auto full_snapshot=[&](int parity){std::vector<Word> values(first.state(parity).size());first.state(parity).download(values.data(),values.size());return values;};
        Trace trace(o.trace,p.h.states,first.words,epoch,Wide(o.ticks)+1);
        if(trace.enabled())trace.append(full_snapshot(0));
        std::size_t free_after=0,ignored=0;check(cudaMemGetInfo(&free_after,&ignored),"memory after allocation");
        int parity=0;auto begin=std::chrono::steady_clock::now();
        for(Word tick=0;tick<o.ticks;++tick){
            for(auto& s:shards){if(lower)launch<true>(*s,parity,backend,p,definitions,atlas_texture?atlas_texture->get():0,o.block,prop);else launch<false>(*s,parity,backend,p,definitions,atlas_texture?atlas_texture->get():0,o.block,prop);}
            parity=1-parity;if(trace.enabled())trace.append(full_snapshot(parity));
        }
        check(cudaDeviceSynchronize(),"validation computation complete");auto end=std::chrono::steady_clock::now();
        epoch+=o.ticks;
        Word sample_words=std::min(first.words,Word(64));std::vector<Word> sample(std::size_t(p.h.states)*sample_words);
        for(Word slot=0;slot<p.h.states;++slot)first.state(parity).download(sample.data()+std::size_t(slot)*sample_words,sample_words,std::size_t(slot)*first.words);
        if(o.verify) {
            auto expected=seed(p,sample_words);
            if(!o.data.empty())for(Word slot=0;slot<p.h.states;++slot)std::copy_n(input.values.data()+std::size_t(slot)*input.words,sample_words,expected.data()+std::size_t(slot)*sample_words);
            std::vector<Word> scratch(std::size_t(p.h.scratch_slots)*sample_words),next(expected.size());
            for(Word tick=0;tick<o.ticks;++tick){cpu_tick(p,expected,scratch,next,sample_words,false);expected.swap(next);}
            if(sample!=expected)throw std::runtime_error("GPU result differs from field-defined CPU reference");
        }
        if(!o.output.empty())save_state(o.output,full_snapshot(parity),p.h.states,first.words,epoch);
        std::ostringstream report;report<<"{\n\"name\":\"TOM\",\"version\":\"0.7-K1\",\"gpu_executed\":true,\"device\":"<<device_info(prop,o.device)<<",\n"
          <<"\"backend\":\""<<o.backend<<"\",\"evaluator\":\""<<o.evaluator<<"\",\"block_threads\":"<<o.block<<",\"lanes\":"<<total_words*32<<",\"ticks\":"<<o.ticks<<",\"epoch\":"<<epoch<<",\"shards\":"<<shards.size()<<",\n"
          <<"\"definition_bytes\":"<<atlas_bytes<<",\"working_bytes\":"<<total_words*bytes_per_word<<",\"free_before_bytes\":"<<free_before<<",\"free_after_bytes\":"<<free_after<<",\n"
          <<"\"elapsed_host_ns\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count()<<",\"sample_digest\":"<<digest(sample)<<",\"sample_lanes\":"<<sample_words*32<<",\"sample_verified\":"<<(o.verify?"true":"false")<<",\n"
          <<"\"exported_first_shard_lanes\":"<<Wide(first.words)*32<<",\"trace_io_in_timing\":"<<(trace.enabled()?"true":"false")<<",\"setup_in_timing\":false,\"source_physics_validated\":false\n}";
        emit(report.str(),o.json);return 0;
    }catch(const std::exception& e){std::cerr<<"tom_cuda: "<<e.what()<<'\n';return 1;}
}
