"""Command-line entry points. Comparisons live in benchmarks/, not the kernel."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import platform
import sys


def emit(data,path=None):
    text=json.dumps(data,indent=2,ensure_ascii=False)
    if path:
        p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text+'\n',encoding='utf-8')
    print(text)


def parser():
    p=argparse.ArgumentParser(prog='axis0',description='Tom Klootwijk / Axis 0 Operator-SDF-T kernel / profile R')
    sub=p.add_subparsers(dest='command',required=True)
    d=sub.add_parser('demo',help='Run the four-step source example')
    d.add_argument('--backend',choices=['exact','numpy','native','cuda'],default='exact')
    d.add_argument('--precision',choices=['float32','float64'],default='float64');d.add_argument('--json')
    r=sub.add_parser('run',help='Run one supplied triple of bit words')
    r.add_argument('--q',required=True);r.add_argument('--j',required=True);r.add_argument('--h',required=True)
    r.add_argument('--backend',choices=['exact','numpy','native','cuda'],default='exact')
    r.add_argument('--precision',choices=['float32','float64'],default='float64');r.add_argument('--json')
    b=sub.add_parser('batch',help='Run step-major bit arrays from an NPZ file')
    b.add_argument('input');b.add_argument('output');b.add_argument('--backend',choices=['numpy','native','cuda'],default='numpy')
    b.add_argument('--precision',choices=['float32','float64'],default='float64')
    b.add_argument('--chunk-steps',type=int,default=128);b.add_argument('--device',type=int,default=0)
    v=sub.add_parser('verify',help='Compare a backend with the exact arithmetic oracle')
    v.add_argument('--backend',choices=['numpy','native','cuda'],default='numpy')
    v.add_argument('--precision',choices=['float32','float64'],default='float64');v.add_argument('--quick',action='store_true');v.add_argument('--json')
    pr=sub.add_parser('precision',help='Measure temporal/radius floating-point resolution')
    pr.add_argument('--backend',choices=['numpy','native','cuda'],default='numpy');pr.add_argument('--steps',type=int,default=1700);pr.add_argument('--json')
    m=sub.add_parser('memory',help='Compute exact base-array VRAM requirements')
    m.add_argument('--steps',type=int,default=256);m.add_argument('--tracks',type=int,default=65536)
    m.add_argument('--precision',choices=['float32','float64'],default='float64')
    o=sub.add_parser('operators',help='List field-readable implemented and unassigned operators')
    sub.add_parser('build-native',help='Build the optional shared-core C++ CPU backend')
    doc=sub.add_parser('doctor',help='Report Python, GPU, CUDA and compiler availability')
    doc.add_argument('--json')
    return p


def main(argv=None):
    p=parser();args=p.parse_args(argv)
    try:
        if args.command in ('demo','run'):
            from .exact import run_exact,validate_inputs
            words=('0110','1010','1011') if args.command=='demo' else (args.q,args.j,args.h)
            if args.backend=='exact':
                data=run_exact(*words).summary()
            else:
                import numpy as np
                from .batch import run_batch
                seq=validate_inputs(*words)
                arrays=tuple(np.array(w,dtype=np.uint8)[:,None] for w in seq)
                data=run_batch(*arrays,backend=args.backend,precision=args.precision).summary()
            emit(data,args.json)
        elif args.command=='batch':
            import numpy as np
            from .batch import run_batch
            with np.load(args.input,allow_pickle=False) as f:
                result=run_batch(f['Q'],f['J'],f['H'],backend=args.backend,precision=args.precision,
                                 chunk_steps=args.chunk_steps,device=args.device)
            out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
            np.savez(out,C=result.c,geometry=result.xyz,state=result.state,
                     precision=np.array(result.precision),backend=np.array(result.backend))
            emit({'output':str(out if str(out).endswith('.npz') else Path(str(out)+'.npz')),
                  'steps':result.shape[0],'tracks':result.shape[1],
                  'counter_rows':['steps','parity','v','first_time_stall','first_radius_stall','first_radius_zero'],
                  'geometry_rows':['u','radius=y','local_T=z']})
        elif args.command=='verify':
            from .verify import verify
            emit(verify(args.backend,args.precision,not args.quick),args.json)
        elif args.command=='precision':
            from .verify import precision_report
            if args.steps<1601:raise ValueError('precision audit needs at least 1601 steps')
            emit(precision_report(args.backend,args.steps),args.json)
        elif args.command=='memory':
            from .batch import memory_bytes
            emit(memory_bytes(args.steps,args.tracks,args.precision))
        elif args.command=='operators':
            from .fields import Axis0
            emit(Axis0().listing())
        elif args.command=='build-native':
            from .native import build_native
            emit(build_native())
        elif args.command=='doctor':
            import shutil
            data={'python':sys.version,'platform':platform.platform(),
                  'g++':shutil.which('g++'),'nvcc':shutil.which('nvcc'),
                  'gpu_status':'not checked'}
            try:
                from .cuda_backend import device_info
                data['gpu']=device_info();data['gpu_status']='available'
            except Exception as e:
                data['gpu_status']='unavailable';data['gpu_error']=str(e)
            emit(data,args.json)
        return 0
    except (ValueError,TypeError,RuntimeError,MemoryError,KeyError,IndexError,OSError) as e:
        print(f'axis0: {type(e).__name__}: {e}',file=sys.stderr)
        return 2

if __name__=='__main__':
    raise SystemExit(main())
