"""Executable correctness evidence, separate from performance comparisons."""
from __future__ import annotations
from itertools import product
import platform
import sys
import time
import numpy as np
from .exact import run_exact,PhiNumber
from .batch import run_batch
from .native import library_path


def verify(backend='numpy',precision='float64',exhaustive=True) -> dict:
    start=time.perf_counter()
    cases=0;transitions=0;maxerr=0.0
    for length in (range(6) if exhaustive else [0,1,4]):
        if exhaustive:
            raw=np.array(list(product((0,1),repeat=length*3)),dtype=np.uint8)
            q=raw[:,:length].T.copy();j=raw[:,length:2*length].T.copy();h=raw[:,2*length:].T.copy()
        else:
            rng=np.random.default_rng(19+length)
            q,j,h=(rng.integers(0,2,(length,25),dtype=np.uint8) for _ in range(3))
        bulk=run_batch(q,j,h,backend=backend,precision=precision,chunk_steps=17)
        for t in range(q.shape[1]):
            exact=run_exact(q[:,t],j[:,t],h[:,t])
            if bulk.word(t)!=exact.output or bulk.address(t)!=exact.state.address:
                raise AssertionError('branch/address mismatch')
            if int(bulk.state[1,t])!=exact.state.parity or int(bulk.state[2,t])!=exact.state.v:
                raise AssertionError('parity/deck-coordinate mismatch')
            if int(bulk.state[0,t])!=length:
                raise AssertionError('halting/entropy mismatch')
            expected=float(exact.state.local_time.decimal())
            err=abs(float(bulk.xyz[2,t])-expected)
            maxerr=max(maxerr,err)
            if err>(3e-6 if precision=='float32' else 3e-14):
                raise AssertionError('geometry differs from exact oracle beyond declared tolerance')
            cases+=1;transitions+=length
    rng=np.random.default_rng(20260918)
    q,j,h=(rng.integers(0,2,(32,100),dtype=np.uint8) for _ in range(3))
    bulk=run_batch(q,j,h,backend=backend,precision=precision,chunk_steps=17)
    for t in range(100):
        e=run_exact(q[:,t],j[:,t],h[:,t])
        if bulk.word(t)!=e.output or bulk.address(t)!=e.state.address or int(bulk.state[1,t])!=e.state.parity:
            raise AssertionError('32-step random check failed')
        err=abs(float(bulk.xyz[2,t])-float(e.state.local_time.decimal()))
        maxerr=max(maxerr,err)
        if err>(3e-6 if precision=='float32' else 3e-14):
            raise AssertionError('32-step time error exceeded tolerance')
        cases+=1;transitions+=32
    long_cases=0
    for length in (65,257,1600):
        q,j,h=(rng.integers(0,2,(length,31),dtype=np.uint8) for _ in range(3))
        bulk=run_batch(q,j,h,backend=backend,precision=precision,chunk_steps=128)
        for t in range(31):
            e=run_exact(q[:,t],j[:,t],h[:,t])
            if bulk.word(t)!=e.output or bulk.address(t)!=e.state.address:
                raise AssertionError('long-path output/address mismatch')
            if int(bulk.state[1,t])!=e.state.parity or int(bulk.state[2,t])!=e.state.v:
                raise AssertionError('long-path parity/deck mismatch')
            if int(bulk.state[0,t])!=length:
                raise AssertionError('long-path entropy mismatch')
            err=abs(float(bulk.xyz[2,t])-float(e.state.local_time.decimal()))
            maxerr=max(maxerr,err)
            if err>(3e-6 if precision=='float32' else 3e-14):
                raise AssertionError('long-path local time error exceeded tolerance')
            cases+=1;long_cases+=1;transitions+=length
    return {'status':'passed','backend':backend,'precision':precision,
            'cases':cases,'transitions':transitions,'max_abs_local_time_error':maxerr,
            'exhaustive_lengths':list(range(6)) if exhaustive else None,
            'random_cases_32_steps':100,'long_cases':long_cases,'long_lengths':[65,257,1600],'elapsed_seconds':time.perf_counter()-start,
            'python':sys.version.split()[0],'numpy':np.__version__,'platform':platform.platform(),
            'gpu_executed':backend=='cuda'}


def precision_report(backend='numpy',steps=1700) -> dict:
    words=np.zeros((steps,1),dtype=np.uint8)
    report={}
    for p in ('float32','float64'):
        r=run_batch(words,words,words,backend=backend,precision=p)
        report[p]={'first_time_stall':int(r.state[3,0]),
                   'first_radius_stall':int(r.state[4,0]),'first_radius_zero':int(r.state[5,0]),
                   'terminal_radius':float(r.xyz[1,0]),'terminal_lifted_time':float(r.xyz[2,0]),
                   'steps':steps,'symbolic_now_remains_distinct':r.read_now(1600)['now_key']!=r.read_now(1601)['now_key']}
    return {'backend':backend,'results':report,'stopping_effect':'none; diagnostics never halt the run'}
