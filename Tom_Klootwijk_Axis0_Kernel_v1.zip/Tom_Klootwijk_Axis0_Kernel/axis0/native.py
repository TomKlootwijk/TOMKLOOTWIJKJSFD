"""Optional shared-core C++ CPU backend. A compiler is needed only to build it."""
from __future__ import annotations
import ctypes as ct
from pathlib import Path
import os
import platform
import shutil
import subprocess
from .batch import NumpySession, BatchResult

ROOT=Path(__file__).resolve().parent

def library_path() -> Path:
    if os.environ.get("AXIS0_NATIVE_LIBRARY"):
        return Path(os.environ["AXIS0_NATIVE_LIBRARY"])
    ext=".dll" if os.name=="nt" else (".dylib" if platform.system()=="Darwin" else ".so")
    return ROOT/"_native"/("axis0_cpu"+ext)


def build_native() -> dict:
    compiler=shutil.which("g++") or shutil.which("clang++")
    if compiler is None:
        raise RuntimeError("No g++/clang++ found. Use the numpy backend, or install a C++17 compiler for this optional backend.")
    target=library_path();target.parent.mkdir(parents=True,exist_ok=True)
    cmd=[compiler,"-std=c++17","-O3","-ffp-contract=off","-shared"]
    if os.name!="nt":
        cmd += ["-fPIC"]
    cmd += [str(ROOT/"kernels/native.cpp"),"-o",str(target)]
    process=subprocess.run(cmd,capture_output=True,text=True)
    if process.returncode:
        raise RuntimeError(f"Native build failed:\n{process.stderr}")
    return {"library":str(target),"command":cmd,"stderr":process.stderr}

class NativeSession(NumpySession):
    def __init__(self,q,j,h,precision="float64",chunk_steps=128,**kwargs):
        super().__init__(q,j,h,precision)
        if not isinstance(chunk_steps,int) or chunk_steps<=0:
            raise ValueError("chunk_steps must be positive")
        self.chunk_steps=chunk_steps
        path=library_path()
        if not path.exists():
            raise RuntimeError("Native backend not built. Run: python -m axis0 build-native")
        self.lib=ct.CDLL(str(path))
        self.fn=getattr(self.lib,"axis0_host_f32" if precision=="float32" else "axis0_host_f64")
        self.fn.argtypes=[ct.c_void_p]*6+[ct.c_ulonglong]*3
        self.fn.restype=None

    def run(self):
        pointers=[a.ctypes.data for a in (self.q,self.j,self.h,self.c,self.xyz,self.state)]
        for start in range(0,self.steps,self.chunk_steps):
            self.fn(*pointers,self.tracks,start,min(start+self.chunk_steps,self.steps))

    def download(self):
        return BatchResult(self.c.copy(),self.xyz.copy(),self.state.copy(),"native",self.precision)
