"""Dense batch ABI: input/output bits uint8 [steps,tracks], step-major.

The byte path is the exact logical address representation, without a depth-63
truncation. Numerical geometry is an explicitly approximate projection; an
exact Now key is the pair (profile R, integer step), not float equality.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

INVPHI = 0.6180339887498948482045868343656381177203
COUNTERS = ("steps", "parity", "v", "first_time_stall", "first_radius_stall", "first_radius_zero")


def validate_batch(q, j, h):
    arrays=[]
    for name,value in zip(("Q","J","H"),(q,j,h)):
        a=np.asarray(value)
        if a.ndim != 2:
            raise ValueError(f"{name} must have shape [steps, tracks]")
        if a.dtype.kind not in "bui" or np.any((a!=0)&(a!=1)):
            raise ValueError(f"{name} must be a boolean/integer bit array")
        arrays.append(np.ascontiguousarray(a,dtype=np.uint8))
    if not arrays[0].shape == arrays[1].shape == arrays[2].shape:
        raise ValueError("Q, J, H shapes must match")
    return tuple(arrays)


def state_arrays(tracks: int, precision: str):
    if precision not in ("float32", "float64"):
        raise ValueError("precision must be float32 or float64")
    xyz=np.zeros((3,tracks),dtype=precision);xyz[1]=1
    state=np.zeros((6,tracks),dtype=np.uint64)
    return xyz,state


def memory_bytes(steps: int, tracks: int, precision: str="float64") -> dict:
    if steps<0 or tracks<0 or precision not in ("float32","float64"):
        raise ValueError("nonnegative dimensions and float32/float64 precision are required")
    real_bytes=4 if precision=="float32" else 8
    base=tracks*(4*steps+3*real_bytes+6*8)
    return {"device_arrays_bytes":base,"host_arrays_bytes":base,
            "device_mib":base/2**20,
            "formula":"tracks * (4*steps + 3*sizeof(real) + 6*8)",
            "excluded":"CUDA context, allocator pools, JIT cache, driver/display use, transient validation copies"}

@dataclass
class BatchResult:
    c: np.ndarray
    xyz: np.ndarray
    state: np.ndarray
    backend: str
    precision: str

    @property
    def shape(self):
        return self.c.shape

    def word(self, track: int=0) -> str:
        if not 0<=track<self.c.shape[1]:
            raise IndexError("track is outside this batch")
        return (self.c[:,track]+48).astype(np.uint8).tobytes().decode("ascii")

    def packed_path(self, track: int=0) -> bytes:
        """Big-endian packed bits, final byte right-padded with zeros; retain length."""
        if not 0<=track<self.c.shape[1]:
            raise IndexError("track is outside this batch")
        return np.packbits(self.c[:,track],bitorder="big").tobytes()

    def address(self, track: int=0) -> int:
        word=self.word(track)
        return int("1"+word,2)

    def read_now(self, step: int, track: int=0) -> dict:
        if not isinstance(step,int) or not 0<=step<=self.shape[0]:
            raise ValueError("Now step is outside this run")
        # Full numeric history is not stored. The emitted word and exact event
        # identity are sufficient for the defined ASCII readout.
        word=self.word(track)[:step]
        return {"now_key":{"profile":"R","step":step},"word":word,
                "address_hex":hex(int("1"+word,2)),
                "exact_time":"sum(phi**(-k), k=1..step)",
                "selection":"exact symbolic level; not floating-point equality"}

    def summary(self, track: int=0) -> dict:
        word=self.word(track); p=int(self.state[1,track]);z=float(self.xyz[2,track])
        result={"backend":self.backend,"precision":self.precision,
                "steps":self.shape[0],"tracks":self.shape[1],"track":track,
                "output_ascii":word,"output_hex":word.encode().hex(),
                "address_hex":hex(self.address(track)),"u":float(self.xyz[0,track]),
                "radius_approx":float(self.xyz[1,track]),"local_T_approx":z,
                "lifted_T_approx":-z if p else z,"entropy":int(self.state[0,track]),
                "log_phi_radius":-int(self.state[0,track]),
                "now_key":{"profile":"R","step":self.shape[0]},
                "exact_radius":"phi**(-step)",
                "exact_lifted_time":"(1-phi**(-step))/(phi-1)"}
        result.update({name:int(self.state[i,track]) for i,name in enumerate(COUNTERS)})
        return result

class NumpySession:
    """Prepared buffers; reset/run/download also support honest benchmarks."""
    def __init__(self,q,j,h,precision="float64",**kwargs):
        self.q,self.j,self.h=validate_batch(q,j,h)
        self.steps,self.tracks=self.q.shape
        self.precision=precision
        self.xyz,self.state=state_arrays(self.tracks,precision)
        self.c=np.empty_like(self.q)
        self.invphi=np.dtype(precision).type(INVPHI)

    def reset(self):
        self.xyz.fill(0);self.xyz[1].fill(1);self.state.fill(0)

    def run(self):
        for n in range(self.steps):
            p=self.state[1].copy()
            oldlift=np.where(p!=0,-self.xyz[2],self.xyz[2])
            newr=self.xyz[1]*self.invphi
            advance=np.where(p!=0,-newr,newr)
            moved=self.xyz[2]+advance
            newz=np.where(self.h[n]!=0,-moved,moved)
            newp=p ^ self.h[n].astype(np.uint64)
            newlift=np.where(newp!=0,-newz,newz)
            for row,mask in ((3,newlift==oldlift),(4,newr==self.xyz[1]),(5,newr==0)):
                select=(self.state[row]==0)&mask
                self.state[row,select]=n+1
            self.xyz[0]=np.where(self.h[n]!=0,-self.xyz[0],self.xyz[0])
            self.xyz[1]=newr;self.xyz[2]=newz
            self.state[0]=n+1;self.state[1]=newp;self.state[2]+=self.h[n]
            np.bitwise_xor(self.q[n],self.j[n],out=self.c[n])

    def synchronize(self):
        pass

    def download(self):
        return BatchResult(self.c.copy(),self.xyz.copy(),self.state.copy(),"numpy",self.precision)


def prepare(q,j,h,*,backend="numpy",precision="float64",chunk_steps=128,device=0):
    if backend=="numpy":
        return NumpySession(q,j,h,precision)
    if backend=="native":
        from .native import NativeSession
        return NativeSession(q,j,h,precision,chunk_steps=chunk_steps)
    if backend=="cuda":
        from .cuda_backend import CudaSession
        return CudaSession(q,j,h,precision,chunk_steps=chunk_steps,device=device)
    raise ValueError("backend must be numpy, native or cuda; no silent backend fallback")


def run_batch(q,j,h,*,backend="numpy",precision="float64",chunk_steps=128,device=0):
    session=prepare(q,j,h,backend=backend,precision=precision,chunk_steps=chunk_steps,device=device)
    session.run();session.synchronize()
    return session.download()
