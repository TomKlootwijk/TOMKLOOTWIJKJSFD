"""The quotient chart in specification v2, not a 3-D Klein mesh approximation."""
from __future__ import annotations
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class KleinPoint:
    u: float
    v: float
    y: float
    z: float
    parity: int = 0

    def __post_init__(self):
        if self.parity not in (0, 1):
            raise ValueError("parity must be 0 or 1")

    @property
    def sdf(self) -> float:
        return self.z

    @property
    def distance_to_zero_section(self) -> float:
        return abs(self.z)

    @property
    def lifted_time(self) -> float:
        return -self.z if self.parity else self.z

    def deck_a(self, winding: int = 1) -> KleinPoint:
        if not isinstance(winding, int):
            raise TypeError("winding must be an integer")
        return KleinPoint(self.u + winding, self.v, self.y, self.z, self.parity)

    def deck_b(self, winding: int = 1) -> KleinPoint:
        if not isinstance(winding, int):
            raise TypeError("winding must be an integer")
        odd = winding & 1
        return KleinPoint(-self.u if odd else self.u, self.v + winding,
                          self.y, -self.z if odd else self.z, self.parity ^ odd)

    def canonical_lift(self) -> KleinPoint:
        point = self.deck_b() if self.parity else self
        return KleinPoint(point.u % 1.0, point.v % 2.0, point.y, point.z, 0)


def circle_sdf(x: float, y: float, radius: float = 1.0) -> float:
    if radius <= 0:
        raise ValueError("radius must be positive")
    return math.hypot(x, y) - radius


def sphere_sdf(x: float, y: float, z: float, radius: float = 1.0) -> float:
    if radius <= 0:
        raise ValueError("radius must be positive")
    return math.sqrt(x*x + y*y + z*z) - radius


def local_jacobian(parity: int, h: int):
    if parity not in (0, 1) or h not in (0, 1):
        raise ValueError("parity and h must be bits")
    invphi = (math.sqrt(5.0)-1.0)/2.0
    e = -1.0 if h else 1.0
    return ((e,0.,0.,0.), (0.,1.,0.,0.), (0.,0.,invphi,0.),
            (0.,0.,e*(-1.0 if parity else 1.0)*invphi,e))
