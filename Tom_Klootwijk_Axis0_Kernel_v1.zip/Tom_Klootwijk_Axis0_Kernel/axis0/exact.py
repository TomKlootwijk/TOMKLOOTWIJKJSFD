"""Exact reference profile R. No floating-point values control its execution.

phi**2 = phi + 1. PhiNumber(a,b) represents a+b*phi exactly, using
arbitrary-precision Python integers. The recurrence is the one in spec v2,
sections 15-18, not a replacement by an XOR-only shortcut.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, localcontext
from fractions import Fraction
from typing import Iterable

@dataclass(frozen=True)
class PhiNumber:
    a: int = 0
    b: int = 0

    def __add__(self, other: PhiNumber) -> PhiNumber:
        if not isinstance(other, PhiNumber):
            return NotImplemented
        return PhiNumber(self.a + other.a, self.b + other.b)

    def __neg__(self) -> PhiNumber:
        return PhiNumber(-self.a, -self.b)

    def __sub__(self, other: PhiNumber) -> PhiNumber:
        return self + (-other)

    def times_phi(self) -> PhiNumber:
        return PhiNumber(self.b, self.a + self.b)

    def divided_by_phi(self) -> PhiNumber:
        return PhiNumber(self.b - self.a, self.a)

    def signed(self, parity: int) -> PhiNumber:
        return -self if parity else self

    def decimal(self, digits: int = 30) -> Decimal:
        """Evaluate with extra precision for cancellation in a+b*phi.

        For these integer coefficients, 2*coefficient_digits is sufficient
        to retain small residuals of conjugate algebraic expressions.
        This affects presentation only, never equality or event selection.
        """
        if digits < 1:
            raise ValueError("digits must be positive")
        bits = max(abs(self.a).bit_length(), abs(self.b).bit_length(), 1)
        coefficient_digits = int(bits * 0.30103) + 2
        with localcontext() as ctx:
            ctx.prec = max(digits + 20, 2 * coefficient_digits + digits + 20)
            phi = (Decimal(1) + Decimal(5).sqrt()) / Decimal(2)
            value = Decimal(self.a) + Decimal(self.b) * phi
            ctx.prec = digits
            return +value

    def to_dict(self, digits: int = 24) -> dict:
        def integer_text(v: int) -> str:
            # Python can limit decimal conversion of enormous integers.
            return str(v) if v.bit_length() < 12000 else hex(v)
        return {"a": integer_text(self.a), "b": integer_text(self.b),
                "basis": "a + b*phi", "decimal": str(self.decimal(digits))}

ZERO = PhiNumber()
ONE = PhiNumber(1, 0)


def bits(value: str | Iterable[int], name: str = "input") -> tuple[int, ...]:
    if isinstance(value, str):
        if any(c not in "01" for c in value):
            raise ValueError(f"{name} must contain only 0 and 1; spaces are not bits")
        return tuple(int(c) for c in value)
    result = []
    for item in value:
        # Reject 0.5 instead of silently truncating it to 0.
        if item not in (0, 1):
            raise ValueError(f"{name} must contain only 0 and 1")
        result.append(int(item))
    return tuple(result)


def validate_inputs(q, j, h) -> tuple[tuple[int, ...], tuple[int, ...], tuple[int, ...]]:
    qq, jj, hh = bits(q, "Q"), bits(j, "J"), bits(h, "H")
    if not len(qq) == len(jj) == len(hh):
        raise ValueError("Q, J and H must have equal lengths")
    return qq, jj, hh

@dataclass(frozen=True)
class ExactState:
    n: int = 0
    address: int = 1
    parity: int = 0
    u: int = 0
    v: int = 0
    radius: PhiNumber = ONE
    local_time: PhiNumber = ZERO

    @property
    def lifted_time(self) -> PhiNumber:
        return self.local_time.signed(self.parity)

    @property
    def entropy(self) -> int:
        return self.n

    @property
    def word(self) -> str:
        return bin(self.address)[3:]  # remove 0b and the leading root bit

    def summary(self) -> dict:
        return {"step": self.n, "entropy": self.entropy, "word": self.word,
                "address_hex": hex(self.address), "address_binary": bin(self.address),
                "parity": self.parity, "u": self.u, "v": self.v,
                "radius": self.radius.to_dict(), "local_T": self.local_time.to_dict(),
                "lifted_T": self.lifted_time.to_dict(), "log_phi_radius": -self.n,
                "now_key": {"profile": "R", "step": self.n},
                "numeric_semantics": "exact Q(phi)"}


def psi_step(state: ExactState, q: int, j: int, h: int) -> ExactState:
    if any(b not in (0, 1) for b in (q, j, h)):
        raise ValueError("q, j, h must be bits")
    c = q ^ j
    r = state.radius.divided_by_phi()
    z = (state.local_time + r.signed(state.parity)).signed(h)
    return ExactState(state.n + 1, (state.address << 1) | c,
                      state.parity ^ h, -state.u if h else state.u,
                      state.v + h, r, z)

@dataclass(frozen=True)
class ExactResult:
    state: ExactState
    q: tuple[int, ...]
    j: tuple[int, ...]
    h: tuple[int, ...]
    trace: tuple[ExactState, ...] | None

    @property
    def output(self) -> str:
        return self.state.word

    def read_now(self, step: int | None = None) -> ExactState:
        """Select the unique exact Now event by its symbolic time index.

        T_hat(n)=sum(phi**(-k), k=1..n) is strictly increasing mathematically.
        The index therefore identifies an exact time level, even after a
        floating-point display has stopped distinguishing adjacent levels.
        """
        n = self.state.n if step is None else step
        if not isinstance(n, int) or not 0 <= n <= self.state.n:
            raise ValueError("Now step is outside the evaluated prefix")
        if self.trace is not None:
            return self.trace[n]
        if n == self.state.n:
            return self.state
        state = ExactState()
        for i in range(n):
            state = psi_step(state, self.q[i], self.j[i], self.h[i])
        return state

    def cantor_interval(self) -> tuple[Fraction, Fraction]:
        numerator = 0
        for c in self.output:
            numerator = 3 * numerator + 2 * int(c)
        denominator = 3 ** self.state.n
        return Fraction(numerator, denominator), Fraction(numerator + 1, denominator)

    def summary(self) -> dict:
        data = self.state.summary()
        data.update(output_ascii=self.output, output_hex=self.output.encode("ascii").hex(),
                    halt={"condition": "entropy == input length", "length": self.state.n},
                    inputs={"Q": ''.join(map(str,self.q)), "J": ''.join(map(str,self.j)),
                            "H": ''.join(map(str,self.h))})
        if self.state.n <= 4096:
            lo, hi = self.cantor_interval()
            data["cantor_interval"] = [str(lo), str(hi)]
        return data


def run_exact(q, j, h, *, trace: bool = False) -> ExactResult:
    qq, jj, hh = validate_inputs(q, j, h)
    state = ExactState()
    history = [state] if trace else None
    for qb, jb, hb in zip(qq, jj, hh):
        state = psi_step(state, qb, jb, hb)
        if history is not None:
            history.append(state)
    return ExactResult(state, qq, jj, hh, tuple(history) if history is not None else None)
