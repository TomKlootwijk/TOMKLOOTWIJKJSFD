"""CUDA/NVRTC backend. Compilation and launch errors are reported, never hidden.

CUDA 12.8+ is required for a Blackwell/sm_120 native target. CuPy selects the
actual installed device architecture; no desktop RTX model is hard-coded.
"""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import numpy as np
from .batch import validate_batch, state_arrays, memory_bytes, BatchResult

ROOT=Path(__file__).resolve().parent

def cupy_module():
    try:
        import cupy as cp
    except ImportError as e:
        raise RuntimeError('CUDA backend requires CuPy. Run: python -m pip install "cupy-cuda12x[ctk]>=14,<15"') from e
    return cp


def cuda_source() -> str:
    return ((ROOT/"kernels/transition.cuh").read_text(encoding="utf-8")+"\n"+
            (ROOT/"kernels/profile_r.cu").read_text(encoding="utf-8"))


def device_info(device=0) -> dict:
    cp=cupy_module()
    count=cp.cuda.runtime.getDeviceCount()
    if not 0<=device<count:
        raise RuntimeError(f"requested device {device}, but CUDA reported {count} devices")
    with cp.cuda.Device(device):
        props=cp.cuda.runtime.getDeviceProperties(device)
        name=props["name"]
        if isinstance(name,bytes): name=name.decode("utf-8",errors="replace")
        free,total=cp.cuda.runtime.memGetInfo()
        runtime=cp.cuda.runtime.runtimeGetVersion()
        from cupy.cuda import nvrtc
        nvrtc_version=nvrtc.getVersion()
        return {"device":device,"name":name,"compute_capability":[int(props["major"]),int(props["minor"])],
                "memory_free_bytes":free,"memory_total_bytes":total,"cuda_runtime":runtime,
                "cuda_driver":cp.cuda.runtime.driverGetVersion(),"nvrtc":list(nvrtc_version),
                "cupy":cp.__version__}

@lru_cache(maxsize=8)
def kernels(device=0):
    cp=cupy_module(); info=device_info(device)
    if info["compute_capability"][0]>=12 and tuple(info["nvrtc"])<(12,8):
        raise RuntimeError("This Blackwell GPU needs NVRTC/CUDA 12.8 or newer for native compilation; upgrade the CUDA components used by CuPy.")
    with cp.cuda.Device(device):
        mod=cp.RawModule(code=cuda_source(), options=("--std=c++17","--fmad=false","--ftz=false"),backend="nvrtc")
        # get_function triggers actual compilation. No claim of verification
        # is made before compilation + a device comparison have both succeeded.
        return {"float32":mod.get_function("axis0_f32"),"float64":mod.get_function("axis0_f64")}

class CudaSession:
    def __init__(self,q,j,h,precision="float64",chunk_steps=128,device=0):
        qq,jj,hh=validate_batch(q,j,h)
        if precision not in ("float32","float64"):
            raise ValueError("precision must be float32 or float64")
        if not isinstance(chunk_steps,int) or chunk_steps<=0:
            raise ValueError("chunk_steps must be positive")
        self.steps,self.tracks=qq.shape
        self.precision=precision;self.chunk_steps=chunk_steps;self.device=device
        self.cp=cp=cupy_module()
        with cp.cuda.Device(device):
            self.fn=kernels(device)[precision]
            free,total=cp.cuda.runtime.memGetInfo()
            needed=memory_bytes(self.steps,self.tracks,precision)["device_arrays_bytes"]
            if needed>free:
                raise MemoryError(f"Arrays need {needed:,} bytes; CUDA reports {free:,} free. Reduce the batch or run independent track tiles; input depth is not truncated.")
            self.q=cp.asarray(qq);self.j=cp.asarray(jj);self.h=cp.asarray(hh)
            self.c=cp.empty_like(self.q)
            xyz,state=state_arrays(self.tracks,precision)
            self.xyz=cp.asarray(xyz);self.state=cp.asarray(state)

    def reset(self):
        with self.cp.cuda.Device(self.device):
            self.xyz.fill(0);self.xyz[1].fill(1);self.state.fill(0)

    def run(self):
        if self.tracks==0:
            return
        with self.cp.cuda.Device(self.device):
            threads=256
            grid=((self.tracks+threads-1)//threads,)
            for start in range(0,self.steps,self.chunk_steps):
                self.fn(grid,(threads,),(self.q,self.j,self.h,self.c,self.xyz,self.state,
                         np.uint64(self.tracks),np.uint64(start),np.uint64(min(start+self.chunk_steps,self.steps))))

    def synchronize(self):
        with self.cp.cuda.Device(self.device):
            self.cp.cuda.get_current_stream().synchronize()

    def download(self):
        with self.cp.cuda.Device(self.device):
            return BatchResult(self.cp.asnumpy(self.c),self.cp.asnumpy(self.xyz),self.cp.asnumpy(self.state),"cuda",self.precision)
