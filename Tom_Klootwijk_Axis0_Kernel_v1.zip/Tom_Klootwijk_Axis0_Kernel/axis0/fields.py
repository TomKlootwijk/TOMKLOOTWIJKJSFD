"""Field-readable execution descriptors for the implemented profile.

A descriptor plus an exact local SDF is an operator-field object. The reader
below provides the instruction interpretation; distance alone is not an ISA.
The CUDA program is a compiled lowering of these profile-R instructions.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
from .exact import ExactState, run_exact, validate_inputs, psi_step
from .geometry import KleinPoint, circle_sdf, sphere_sdf

class UnassignedOperator(NotImplementedError):
    pass

@dataclass(frozen=True)
class Field:
    kind: str
    payload: Any
    carrier: str = "E4 = (R3/<A,B>) x R; local d=z"

    def sdf(self, point: KleinPoint) -> float:
        return point.sdf

    def time(self, point: KleinPoint) -> float:
        return self.sdf(point)

@dataclass(frozen=True)
class SeedPayload:
    state: ExactState
    q: tuple[int, ...]
    j: tuple[int, ...]
    h: tuple[int, ...]

@dataclass(frozen=True)
class OperatorField(Field):
    def __init__(self, name: str, status: str = "implemented"):
        object.__setattr__(self, "kind", "operator")
        object.__setattr__(self, "payload", {"name": name, "status": status})
        object.__setattr__(self, "carrier", "E4 = (R3/<A,B>) x R; local d=z")

class Axis0:
    def __init__(self):
        self.operators: dict[str, OperatorField] = {}
        self._readers: dict[str, Callable] = {}
        self._install()

    def register(self, name: str, reader: Callable | None):
        self.operators[name] = OperatorField(name, "implemented" if reader else "unassigned")
        if reader is not None:
            self._readers[name] = reader

    def apply(self, name: str, *values: Field) -> Field:
        if name not in self.operators:
            raise KeyError(f"operator {name!r} is outside this declared registry")
        if name not in self._readers:
            raise UnassignedOperator(f"{name}: the source supplies no evaluation law")
        if not all(isinstance(x, Field) for x in values):
            raise TypeError("Axis 0 application takes Field operands")
        result = self._readers[name](*values)
        if not isinstance(result, Field):
            raise TypeError("operator reader must return a Field")
        return result

    def _install(self):
        def seed(inputs):
            q,j,h=validate_inputs(*inputs.payload)
            return Field("state", SeedPayload(ExactState(),q,j,h))
        def psi(value):
            p=value.payload; n=p.state.n
            if n >= len(p.q):
                raise StopIteration("the entropy/input-length predicate is already terminal")
            return Field("state", SeedPayload(psi_step(p.state,p.q[n],p.j[n],p.h[n]),p.q,p.j,p.h))
        self.register("Seed", seed)
        self.register("PSI", psi)
        self.register("Time", lambda v: Field("Q(phi)",v.payload.state.local_time))
        self.register("Entropy", lambda v: Field("integer",v.payload.state.n))
        self.register("Halt", lambda v: Field("bit",int(v.payload.state.n == len(v.payload.q))))
        self.register("Now", lambda v: Field("event",v.payload.state))
        self.register("ReadNow", lambda v: Field("ASCII bits",v.payload.word))
        self.register("RunR", lambda v: Field("result",run_exact(*v.payload)))
        self.register("Quote", lambda v: Field("quotation",v))
        self.register("Read", lambda v: v.payload)
        self.register("Eval", lambda op,*args: self.apply(op.payload["name"],*args))
        self.register("Circle", lambda v: Field("distance",circle_sdf(*v.payload)))
        self.register("Sphere", lambda v: Field("distance",sphere_sdf(*v.payload)))
        for name in ["men T room", "Cone", "Apex", "Legenda", "SideView", "T_circle",
                     "+_PSI", "+_source", "AT", "Kindred", "UU", "B floppy P",
                     "ZeroOrder", "Replicate", "UniversalProgram"]:
            self.register(name,None)

    def listing(self) -> list[dict]:
        return [dict(op.payload,carrier=op.carrier) for op in self.operators.values()]
