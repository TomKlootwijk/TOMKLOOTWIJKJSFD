// Optional CPU executor of the identical transition.cuh, no CUDA dependency.
#include "transition.cuh"
#if defined(_WIN32)
#define AX0_API __declspec(dllexport)
#else
#define AX0_API __attribute__((visibility("default")))
#endif
#define AX0_HOST(NAME,REAL) \
extern "C" AX0_API void NAME( \
    const unsigned char* q, const unsigned char* j, const unsigned char* h, \
    unsigned char* c, REAL* xyz, ax0_u64* state, \
    ax0_u64 tracks, ax0_u64 start, ax0_u64 stop) { \
    for(ax0_u64 t=0;t<tracks;++t) { \
        auto s=axis0_load(xyz,state,t,tracks); \
        for(ax0_u64 n=start;n<stop;++n) { \
            const ax0_u64 k=n*tracks+t; \
            c[k]=axis0_step(s,q[k],j[k],h[k]); \
        } \
        axis0_store(xyz,state,t,tracks,s); \
    } \
}
AX0_HOST(axis0_host_f32,float)
AX0_HOST(axis0_host_f64,double)
