// NVRTC source. transition.cuh is concatenated by the loader.
// One CUDA lane per independent trajectory, coalesced step-major Q/J/H/C.
// start/stop are launch partitions, NOT semantic termination thresholds.
#define AX0_KERNEL(NAME,REAL) \
extern "C" __global__ void NAME( \
    const unsigned char* q, const unsigned char* j, const unsigned char* h, \
    unsigned char* c, REAL* xyz, ax0_u64* state, \
    ax0_u64 tracks, ax0_u64 start, ax0_u64 stop) { \
    const ax0_u64 t=(ax0_u64)blockIdx.x*blockDim.x+threadIdx.x; \
    if(t>=tracks) return; \
    auto s=axis0_load(xyz,state,t,tracks); \
    for(ax0_u64 n=start;n<stop;++n) { \
        const ax0_u64 k=n*tracks+t; \
        c[k]=axis0_step(s,q[k],j[k],h[k]); \
    } \
    axis0_store(xyz,state,t,tracks,s); \
}
AX0_KERNEL(axis0_f32,float)
AX0_KERNEL(axis0_f64,double)
