// Profile R transition shared by CUDA and the optional native CPU backend.
// Formalization: Tom Klootwijk / NL200678942 / 10-07-1990.
#ifndef AXIS0_TRANSITION_CUH
#define AXIS0_TRANSITION_CUH
#if defined(__CUDACC__) || defined(__CUDACC_RTC__)
#define AX0_HD __host__ __device__ __forceinline__
#else
#define AX0_HD inline
#endif
using ax0_u64 = unsigned long long;
static_assert(sizeof(ax0_u64)==8, "Axis 0 requires a 64-bit counter type");

template<class Real> struct Ax0State {
    Real u, r, z;
    ax0_u64 n, p, v, first_time_stall, first_radius_stall, first_radius_zero;
};

template<class Real>
AX0_HD unsigned char axis0_step(Ax0State<Real>& s, unsigned char q,
                                unsigned char j, unsigned char h) {
    const Real invphi = (Real)0.6180339887498948482045868343656381177203;
    const Real old_lift = s.p ? -s.z : s.z;
    const Real next_r = s.r * invphi;
    const Real advance = s.p ? -next_r : next_r;
    const Real moved_z = s.z + advance;
    const Real next_z = h ? -moved_z : moved_z;
    const ax0_u64 next_p = s.p ^ (ax0_u64)h;
    const Real next_lift = next_p ? -next_z : next_z;
    const ax0_u64 next_n = s.n + 1;
    if (!s.first_time_stall && next_lift == old_lift) s.first_time_stall=next_n;
    if (!s.first_radius_stall && next_r == s.r) s.first_radius_stall=next_n;
    if (!s.first_radius_zero && next_r == (Real)0) s.first_radius_zero=next_n;
    s.u = h ? -s.u : s.u;
    s.r=next_r; s.z=next_z; s.p=next_p; s.v+=(ax0_u64)h; s.n=next_n;
    return q ^ j;
}

template<class Real>
AX0_HD Ax0State<Real> axis0_load(const Real* xyz, const ax0_u64* state,
                               ax0_u64 track, ax0_u64 tracks) {
    Ax0State<Real> s;
    s.u=xyz[track]; s.r=xyz[tracks+track]; s.z=xyz[2*tracks+track];
    s.n=state[track]; s.p=state[tracks+track]; s.v=state[2*tracks+track];
    s.first_time_stall=state[3*tracks+track];
    s.first_radius_stall=state[4*tracks+track];
    s.first_radius_zero=state[5*tracks+track];
    return s;
}

template<class Real>
AX0_HD void axis0_store(Real* xyz, ax0_u64* state, ax0_u64 track,
                       ax0_u64 tracks, const Ax0State<Real>& s) {
    xyz[track]=s.u; xyz[tracks+track]=s.r; xyz[2*tracks+track]=s.z;
    state[track]=s.n; state[tracks+track]=s.p; state[2*tracks+track]=s.v;
    state[3*tracks+track]=s.first_time_stall;
    state[4*tracks+track]=s.first_radius_stall;
    state[5*tracks+track]=s.first_radius_zero;
}
#endif
