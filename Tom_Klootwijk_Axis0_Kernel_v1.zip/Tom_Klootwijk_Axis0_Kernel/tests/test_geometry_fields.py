import unittest
from axis0.geometry import KleinPoint,circle_sdf,sphere_sdf,local_jacobian
from axis0.fields import Axis0,Field,UnassignedOperator

class GeometryAndFieldTests(unittest.TestCase):
    def test_deck_group(self):
        x=KleinPoint(.25,.5,2.,3.,0)
        self.assertEqual(x.deck_b().deck_b(),KleinPoint(.25,2.5,2.,3.,0))
        # B A B^{-1} = A^{-1}.
        self.assertEqual(x.deck_b(-1).deck_a().deck_b(),x.deck_a(-1))
        for k in range(-5,6):
            y=x.deck_b(k)
            self.assertEqual(y.lifted_time,x.lifted_time)
            self.assertEqual(y.distance_to_zero_section,x.distance_to_zero_section)
            self.assertEqual(y.canonical_lift(),x.canonical_lift())

    def test_sdfs(self):
        self.assertEqual(circle_sdf(3,4,2),3)
        self.assertEqual(sphere_sdf(0,0,0,2),-2)
        self.assertEqual(KleinPoint(2,3,4,-5,1).sdf,-5)

    def test_operator_closure(self):
        domain=Axis0();inputs=Field('input',('0110','1010','1011'))
        seed=domain.apply('Seed',inputs)
        self.assertEqual(domain.apply('Time',seed).payload.a,0)
        state=seed
        while not domain.apply('Halt',state).payload:
            state=domain.apply('PSI',state)
        now=domain.apply('Now',state)
        decoded=domain.apply('ReadNow',now)
        self.assertIsInstance(decoded,Field)
        self.assertEqual(decoded.payload,'1100')
        self.assertEqual(domain.apply('Entropy',state).payload,4)
        with self.assertRaises(StopIteration):domain.apply('PSI',state)

    def test_quotation_and_self_evaluation(self):
        domain=Axis0();op=domain.operators['RunR']
        self.assertIs(domain.apply('Read',domain.apply('Quote',op)),op)
        result=domain.apply('Eval',op,Field('input',('0110','1010','1011')))
        self.assertEqual(result.payload.output,'1100')
        self.assertEqual(op.sdf(KleinPoint(0,0,0,2)),2)

    def test_unassigned_names_not_guessed(self):
        d=Axis0()
        for name in ('B floppy P','UniversalProgram','+_PSI','T_circle'):
            with self.assertRaises(UnassignedOperator):d.apply(name)
        with self.assertRaises(KeyError):d.apply('not-declared')

    def test_matrix_sign(self):
        j=local_jacobian(1,1)
        self.assertEqual(j[0][0],-1)
        self.assertEqual(j[1][1],1)
        self.assertEqual(j[3][3],-1)
        self.assertGreater(j[3][2],0)
