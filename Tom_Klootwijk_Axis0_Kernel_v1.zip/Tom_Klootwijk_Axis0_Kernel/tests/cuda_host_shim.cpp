// Host-only checking of the literal CUDA kernel body, NOT device execution.
// This validates indexing, bounds and chunk semantics, not GPU compiler/driver.
#include "../axis0/kernels/transition.cuh"
struct Axis0FakeDim { ax0_u64 x; };
static Axis0FakeDim blockIdx,blockDim,threadIdx;
#define __global__
#include "../axis0/kernels/profile_r.cu"
#undef __global__
#if defined(_WIN32)
#define AX0_EXPORT __declspec(dllexport)
#else
#define AX0_EXPORT __attribute__((visibility("default")))
#endif
#define AX0_SHIM(NAME,REAL,KERNEL) \
extern "C" AX0_EXPORT void NAME(const unsigned char* q,const unsigned char* j, \
 const unsigned char* h,unsigned char* c,REAL* xyz,ax0_u64* state, \
 ax0_u64 tracks,ax0_u64 start,ax0_u64 stop) { \
 blockDim.x=256; \
 for(ax0_u64 t=0;t<((tracks+255)/256)*256;++t){ \
    blockIdx.x=t/256;threadIdx.x=t%256; \
    KERNEL(q,j,h,c,xyz,state,tracks,start,stop); \
 } }
AX0_SHIM(axis0_shim_f32,float,axis0_f32)
AX0_SHIM(axis0_shim_f64,double,axis0_f64)
