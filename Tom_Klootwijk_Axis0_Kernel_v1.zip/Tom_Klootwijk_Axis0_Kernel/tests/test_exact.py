import unittest
from decimal import Decimal
from fractions import Fraction
from axis0.exact import PhiNumber, ExactState, psi_step, run_exact

class ExactTests(unittest.TestCase):
    def test_phi_arithmetic(self):
        self.assertEqual(PhiNumber(0,1).times_phi(),PhiNumber(1,1))
        self.assertEqual(PhiNumber(1,0).divided_by_phi(),PhiNumber(-1,1))
        for a in range(-7,8):
            for b in range(-7,8):
                x=PhiNumber(a,b)
                self.assertEqual(x.divided_by_phi().times_phi(),x)

    def test_reference(self):
        r=run_exact('0110','1010','1011',trace=True)
        self.assertEqual(r.output,'1100')
        self.assertEqual(r.state.address,28)
        self.assertEqual(r.state.parity,1)
        self.assertEqual(r.state.v,3)
        self.assertEqual(r.state.radius,PhiNumber(5,-3))
        self.assertEqual(r.state.local_time,PhiNumber(-3,1))
        self.assertEqual(r.state.lifted_time,PhiNumber(3,-1))
        self.assertEqual(r.cantor_interval(),(Fraction(8,9),Fraction(73,81)))
        self.assertEqual([s.address for s in r.trace],[1,3,7,14,28])
        self.assertEqual([s.parity for s in r.trace],[0,1,1,0,1])
        self.assertEqual(r.summary()['output_hex'],'31313030')

    def test_now_without_trace(self):
        r=run_exact('0110','1010','1011')
        self.assertEqual(r.read_now(2).word,'11')
        self.assertEqual(r.read_now(0),ExactState())
        with self.assertRaises(ValueError):r.read_now(5)

    def test_empty(self):
        r=run_exact('','','')
        self.assertEqual(r.output,'')
        self.assertEqual(r.state.address,1)
        self.assertEqual(r.state.radius,PhiNumber(1,0))
        self.assertEqual(r.state.local_time,PhiNumber())
        self.assertEqual(r.cantor_interval(),(Fraction(0),Fraction(1)))

    def test_no_address_truncation(self):
        r=run_exact('0'*1000,'0'*1000,'1'*1000)
        self.assertEqual(r.state.address,1<<1000)
        self.assertEqual(r.state.address.bit_length(),1001)
        self.assertEqual(r.state.parity,0)
        self.assertEqual(r.state.entropy,1000)
        self.assertGreater(r.state.radius.decimal(),Decimal(0))
        self.assertLess(r.state.radius.decimal(),Decimal('1e-200'))

    def test_validation(self):
        for args in [('01','1','00'),('02','00','00'),('0 ','00','00'),([0.5],[0],[0])]:
            with self.assertRaises(ValueError):run_exact(*args)
        with self.assertRaises(ValueError):psi_step(ExactState(),0,0,3)

    def test_h_does_not_change_output(self):
        a=run_exact('1010','0110','0000')
        b=run_exact('1010','0110','1111')
        self.assertEqual(a.output,b.output)
        self.assertEqual(a.state.lifted_time,b.state.lifted_time)

    def test_closed_form_invariant(self):
        r=run_exact('0101'*20,'1010'*20,'0111'*20,trace=True)
        for s in r.trace:
            # phi*(1-r) = geometric sum, using phi-1 = 1/phi.
            self.assertEqual(s.lifted_time,(PhiNumber(1,0)-s.radius).times_phi())
            self.assertEqual(s.entropy,s.n)
