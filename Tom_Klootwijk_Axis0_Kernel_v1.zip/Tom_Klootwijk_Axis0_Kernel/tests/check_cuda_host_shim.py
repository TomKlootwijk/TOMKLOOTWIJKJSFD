"""Compile and check the literal CUDA body using host-emulated launch indices.
This is NOT NVRTC compilation or execution on a GPU. Requires g++/clang++.
"""
from pathlib import Path
import ctypes as ct
import json
import os
import shutil
import subprocess
import sys
import tempfile
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from axis0.batch import NumpySession
root=Path(__file__).resolve().parents[1]
compiler=shutil.which('g++') or shutil.which('clang++')
if not compiler: raise SystemExit('g++/clang++ required for the optional host shim check')
with tempfile.TemporaryDirectory() as temp:
    path=Path(temp)/('shim.dll' if os.name=='nt' else 'shim.so')
    command=[compiler,'-std=c++17','-O3','-ffp-contract=off','-shared']
    if os.name!='nt':command+=['-fPIC']
    command += [str(root/'tests/cuda_host_shim.cpp'),'-o',str(path)]
    subprocess.run(command,check=True,capture_output=True)
    lib=ct.CDLL(str(path));rng=np.random.default_rng(20260918)
    batches=tracks_total=0
    for precision in ('float32','float64'):
        fn=getattr(lib,'axis0_shim_f32' if precision=='float32' else 'axis0_shim_f64')
        fn.argtypes=[ct.c_void_p]*6+[ct.c_ulonglong]*3;fn.restype=None
        for length,tracks in ((0,0),(0,1),(1,1),(4,257),(65,31),(129,513),(1600,17)):
            data=tuple(rng.integers(0,2,(length,tracks),dtype=np.uint8) for _ in range(3))
            ref=NumpySession(*data,precision);ref.run()
            test=NumpySession(*data,precision)
            pointers=[a.ctypes.data for a in (test.q,test.j,test.h,test.c,test.xyz,test.state)]
            for start in range(0,length,17):
                fn(*pointers,tracks,start,min(start+17,length))
            for a,b in ((ref.c,test.c),(ref.xyz,test.xyz),(ref.state,test.state)):
                np.testing.assert_array_equal(a,b)
            batches+=1;tracks_total+=tracks
    report={'status':'passed','batches':batches,'trajectories_across_batches':tracks_total,
            'float_precisions':['float32','float64'],
            'validation_kind':'literal CUDA source compiled as host C++ with emulated launch indices',
            'nvrtc_compiled':False,'gpu_executed':False,'compiler':compiler,
            'checks':['output bits','state counters','floating geometry','out-of-bounds lane guards','17-step chunk continuation']}
    print(json.dumps(report,indent=2))
    (root/'results/cuda_host_shim.json').write_text(json.dumps(report,indent=2)+'\n')
