import unittest
import numpy as np
from axis0.exact import run_exact
from axis0.batch import run_batch,memory_bytes
from axis0.native import library_path

class BatchTests(unittest.TestCase):
    def make(self,length=20,tracks=31):
        rng=np.random.default_rng(1337)
        return tuple(rng.integers(0,2,size=(length,tracks),dtype=np.uint8) for _ in range(3))

    def test_reference(self):
        a=tuple(np.array(list(map(int,s)),dtype=np.uint8)[:,None] for s in ('0110','1010','1011'))
        for precision in ('float32','float64'):
            r=run_batch(*a,precision=precision)
            self.assertEqual(r.word(),'1100')
            self.assertEqual(r.address(),28)
            self.assertEqual(r.summary()['parity'],1)
            self.assertAlmostEqual(r.summary()['lifted_T_approx'],1.381966011250105,places=6)
            self.assertEqual(r.read_now(2)['word'],'11')
            self.assertEqual(r.packed_path(),b'\xc0')

    def test_random_exact(self):
        q,j,h=self.make()
        r=run_batch(q,j,h)
        for t in range(q.shape[1]):
            exact=run_exact(q[:,t],j[:,t],h[:,t])
            self.assertEqual(r.word(t),exact.output)
            self.assertEqual(r.address(t),exact.state.address)
            self.assertEqual(r.state[1,t],exact.state.parity)
            self.assertAlmostEqual(r.xyz[2,t],float(exact.state.local_time.decimal()),places=13)

    def test_empty_dimensions(self):
        for shape in ((0,1),(5,0),(0,0)):
            arr=np.empty(shape,dtype=np.uint8)
            r=run_batch(arr,arr,arr)
            self.assertEqual(r.shape,shape)
        r=run_batch(*[np.empty((0,1),dtype=np.uint8)]*3)
        self.assertEqual(r.word(),'')
        self.assertEqual(r.address(),1)

    def test_validation(self):
        a=np.zeros((3,4),np.uint8)
        with self.assertRaises(ValueError):run_batch(a,a,[[0]])
        with self.assertRaises(ValueError):run_batch(a,a,a.astype(float))
        a[0,0]=2
        with self.assertRaises(ValueError):run_batch(a,a,a)
        with self.assertRaises(ValueError):run_batch(*self.make(),backend='automatic')

    def test_long_path_and_time_collision(self):
        q,j,h=self.make(200,2)
        r=run_batch(q,j,h,precision='float32')
        self.assertEqual(r.address().bit_length(),201)
        self.assertGreater(int(r.state[3,0]),0)
        self.assertNotEqual(r.read_now(100)['now_key'],r.read_now(101)['now_key'])
        self.assertEqual(r.read_now(200)['word'],r.word())

    def test_memory_accounting(self):
        self.assertEqual(memory_bytes(256,65536)['device_arrays_bytes'],65536*(1024+72))
        self.assertEqual(memory_bytes(4,1,'float32')['device_arrays_bytes'],76)

    @unittest.skipUnless(library_path().exists(),'optional native backend not built')
    def test_native_shared_core(self):
        for precision in ('float32','float64'):
            for length in (0,1,4,63,64,65,128,129,320,1600):
                args=self.make(length,7)
                a=run_batch(*args,precision=precision)
                b=run_batch(*args,backend='native',precision=precision,chunk_steps=17)
                np.testing.assert_array_equal(a.c,b.c)
                np.testing.assert_array_equal(a.xyz,b.xyz)
                np.testing.assert_array_equal(a.state,b.state)
