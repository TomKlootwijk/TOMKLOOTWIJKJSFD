# Delivery and attribution

The custom source code in this package is provided to Tom Klootwijk for use, modification and redistribution. The formalization attribution is recorded in `identity.json`. No verified legal meaning or credential type is assigned to the supplied personal identifier.

The two PDFs under `source_material/` are copies of the files supplied in this conversation. They are retained for traceability. They are not represented as external research validating the kernel.

Python, NumPy, CuPy, NVIDIA CUDA components and any C++ compiler are separate third-party dependencies distributed under their own licenses. Their binaries are not included here. The setup scripts fetch dependencies only when explicitly run. The kernel contains no network or telemetry code and does not use personal identifiers as random seeds or credentials.
