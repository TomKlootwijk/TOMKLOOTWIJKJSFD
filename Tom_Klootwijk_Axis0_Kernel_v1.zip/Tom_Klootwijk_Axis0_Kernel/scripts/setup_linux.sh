#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
if [[ "${1:-cpu}" == "cuda" ]]; then
  .venv/bin/python -m pip install -e '.[cuda12]'
  .venv/bin/python -m axis0 doctor
  .venv/bin/python -m axis0 verify --backend cuda --json results/local_cuda_verify.json
else
  .venv/bin/python -m pip install -e .
  .venv/bin/python -m unittest discover -s tests -v
fi
