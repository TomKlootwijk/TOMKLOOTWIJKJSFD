$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Push-Location $Root
try {
    $Py = Join-Path $Root ".venv\Scripts\python.exe"
    if (-not (Test-Path $Py)) { throw "Create the virtual environment first; see README.md." }
    & $Py -m axis0 doctor --json results\laptop_environment.json
    foreach ($Precision in @("float64", "float32")) {
        & $Py -m axis0 verify --backend cuda --precision $Precision --json "results\laptop_verify_$Precision.json"
        if ($LASTEXITCODE -ne 0) { throw "CUDA $Precision verification failed" }
    }
    & $Py -m axis0 precision --backend cuda --json results\laptop_precision.json
    if ($LASTEXITCODE -ne 0) { throw "CUDA precision audit failed" }
    & $Py benchmarks\benchmark.py --backend cuda --json results\laptop_benchmark.json
    if ($LASTEXITCODE -ne 0) { throw "CUDA benchmark failed" }
    Write-Host "Saved actual device results to the results folder."
} finally { Pop-Location }
