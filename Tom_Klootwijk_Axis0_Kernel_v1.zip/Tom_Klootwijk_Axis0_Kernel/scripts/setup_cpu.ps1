param([string]$Python = "python")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Push-Location $Root
try {
    if (-not (Test-Path ".venv\Scripts\python.exe")) {
        & $Python -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw "Could not create venv. Install Python 3.10+ or use the manual commands in README.md." }
    }
    $Py = Join-Path $Root ".venv\Scripts\python.exe"
    & $Py -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed" }
    & $Py -m pip install -e .
    if ($LASTEXITCODE -ne 0) { throw "CPU dependency installation failed" }
    & $Py -m axis0 demo
    if ($LASTEXITCODE -ne 0) { throw "Exact demo failed" }
    & $Py -m unittest discover -s tests -v
    if ($LASTEXITCODE -ne 0) { throw "CPU tests failed" }
} finally { Pop-Location }
