param([string]$Python = "python")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot "setup_cpu.ps1") -Python $Python
Push-Location $Root
try {
    $Py = Join-Path $Root ".venv\Scripts\python.exe"
    & $Py -m pip install -e ".[cuda12]"
    if ($LASTEXITCODE -ne 0) { throw "CUDA dependency installation failed" }
    & $Py -m axis0 doctor --json results\laptop_environment.json
    & $Py -m axis0 verify --backend cuda --json results\laptop_verify_f64.json
    if ($LASTEXITCODE -ne 0) { throw "Actual CUDA validation did not pass. See the diagnostic above and docs/CUDA_SETUP.md." }
    Write-Host "CUDA device validation passed. Run scripts/check_laptop.ps1 for the full measurement set."
} finally { Pop-Location }
