from pathlib import Path
import hashlib
import sys
root=Path(__file__).resolve().parents[1]
errors=[];checked=0
for line in (root/'SHA256SUMS').read_text().splitlines():
    want,name=line.split('  ',1)
    p=root/name
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=want:
        errors.append(name)
    checked+=1
if errors:
    print('Mismatched or missing:',*errors,sep='\n');sys.exit(1)
print(f'{checked} distributed file hashes match')
