# Numerical representation and ABI

## Exact CPU reference

`PhiNumber(a,b)` means `a + b*phi`, with exact Python integer coefficients. Dividing by phi maps `(a,b)` to `(b-a,a)`. Negation changes both signs. Equality is coefficient equality; it never uses an epsilon. Decimal display adds working precision to handle cancellation. Large exact runs require increasing host memory and integer-arithmetic time.

The geometry is exactly `T=z`; the tracked readout is `T_hat=(-1)^p*T`. The event key is an integer index of the strictly increasing exact geometric sum. This index supplements, rather than changes, the specified temporal field.

## Batch arrays

All Q/J/H entries must be integer bits 0 or 1. Arrays are C-contiguous, step-major, shape `(L,B)`. The GPU stores

| Buffer | Type and shape | Meaning |
|---|---|---|
| Q, J, H | uint8 `(L,B)` each | finite LUT inputs |
| C | uint8 `(L,B)` | exact executed branch bits |
| geometry | float32 or float64 `(3,B)` | u, y/r, z/T |
| state | uint64 `(6,B)` | n, parity, v, first T stall, first r stall, first r zero |

The explicit device-array budget is `B*(4*L+3*sizeof(real)+6*8)` bytes. For L=256, B=65536, float64, this is 71,827,456 bytes = 68.5 MiB. It is not the total process/driver VRAM reservation.

The CUDA function signature is documented directly in `profile_r.cu`. Float32 and float64 entry points share `transition.cuh`. Bits and counters remain integer. Local v is an integer count of B-generator applications. Floating u has the specified sign transport; its seed is zero.

## Floating-point behavior is observable, not hidden

The C++/CUDA ratio is the correctly rounded literal for 1/phi in the selected precision. The floating implementation multiplies by that ratio. No fast-math mode is requested, fused multiply-add contraction is disabled, and CUDA flushing of subnormals is not requested. Exact CPU reference arithmetic is separate.

Measured on the delivery CPU with the actual shared transition:

| Event | float32 | float64 |
|---|---:|---:|
| first identical consecutive rounded T_hat values | step 35 | step 77 |
| first unchanged rounded radius | step 215 | step 1547 |
| first exactly zero rounded radius through step 1700 | not observed | not observed |

The radius becomes stuck at the smallest subnormal under this tested gradual-underflow behavior; it need not become zero. Hardware/compiler execution must be audited separately. `axis0 precision --backend cuda` measures the same events on the laptop.

The integer step still advances. Entropy/input completion still uses the integer input length. Distinct exact Now keys stay distinct even when two rendered time numbers coincide. Flags do not halt execution, clamp values or substitute zero. A zero diagnostic counter means “the event was not observed.”

## Chunking and memory

The default 128-step launch partition keeps a long path from requiring one monolithic display-GPU kernel. The same state buffers continue across launches. Changing the launch partition leaves the transition order of each trajectory unchanged. No input suffix is discarded.

A dataset larger than available VRAM can be split into independent track tiles at the application level. The API exposes ordinary step-major arrays; the delivered high-level `run_batch` allocates one requested batch and does not silently tile or truncate it. Host memory must also hold inputs and downloaded output. Out-of-memory is an explicit error.

The fixed-width counters are uint64 and the dimensions are bounded by representable array allocations; no finite machine is treated as storing infinite branches. The exact reference's address uses arbitrary-size integers. The GPU's complete path uses allocated byte arrays, not a finite-width rolling address.

## Prepared-session use

`prepare()` creates buffers, `run()` executes the entire input, and `download()` returns copies. Call `reset()` before rerunning the same prepared session. These sessions are intended for explicit benchmark reuse; `run_batch()` creates a fresh initialized session automatically. Do not call `run()` twice without reset and interpret it as a continuation with new inputs.
