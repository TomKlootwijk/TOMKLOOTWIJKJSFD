# CUDA setup for the supplied laptop target

Target as supplied: **GeForce RTX 5070 Ti Laptop GPU, 12 GB VRAM**.

## Dependency route

Use Python 3.10 or newer. In a dedicated virtual environment, install this package with the `cuda12` extra. This requests CuPy 14.x for CUDA 12 plus its CUDA component wheels:

```text
python -m pip install -e ".[cuda12]"
```

The device must have a compatible NVIDIA driver. CUDA/NVRTC 12.8 or newer is required here for native compilation on compute capability 12.x. The loader checks NVRTC's version and queries the actual GPU. It does not assume that the GPU is the desktop 5070 Ti, and does not use the desktop's memory capacity in its allocator.

The Python loader concatenates `transition.cuh` and `profile_r.cu`, then asks CuPy RawModule/NVRTC to compile the CUDA functions for the detected device. No Visual Studio C++ toolchain or separate native CPU build is required by that CUDA path. An optional C++ CPU backend is a separate component.

The bundled sources were not device-compiled or GPU-executed in the delivery environment. Use:

```text
python -m axis0 doctor
python -m axis0 verify --backend cuda --precision float64 --json results/laptop_verify_f64.json
python -m axis0 verify --backend cuda --precision float32 --json results/laptop_verify_f32.json
python -m axis0 precision --backend cuda --json results/laptop_precision.json
python benchmarks/benchmark.py --backend cuda --json results/laptop_benchmark.json
```

The verification's 37,642 test cases include all Q/J/H combinations of lengths 0 through 5, 100 reproducibly generated 32-step cases, and 93 longer cases at lengths 65, 257 and 1600. The backend name and whether a GPU was executed are recorded in the result.

## Interpreting failures

A missing CuPy import means the CUDA extra was not installed into the Python environment used by the command. `doctor` prints that environment's Python version.

A missing CUDA device/driver is not a CPU pass. Check that the laptop is exposing the NVIDIA GPU and that its NVIDIA driver is installed. The setup scripts do not change the system driver.

A compiler report mentioning an unsupported target or older NVRTC requires checking which CUDA runtime CuPy actually selected. `doctor` prints runtime, driver, NVRTC and device information. Multiple CUDA installations can cause the wrong toolkit to be selected; consult the CuPy installation guide below.

A device-memory error means the requested arrays do not fit currently free memory. Reduce the independent trajectory count, or partition the input by columns. A 65,536-by-256 float64 batch has 68.5 MiB of explicit device arrays; this excludes context, caches and other GPU users.

## Primary references (accessed 18 September 2026)

These references informed compatibility/setup only; they did not supply the formalization's equations.

1. NVIDIA, GeForce RTX 50 Series Laptop specifications: https://www.nvidia.com/en-us/geforce/laptops/50-series/ . The RTX 5070 Ti Laptop column lists 12 GB GDDR7, 5,888 CUDA cores and 672 GB/s memory bandwidth. These specifications are not measured throughput for this kernel.
2. NVIDIA, CUDA GPU compute capabilities: https://developer.nvidia.com/cuda/gpus . RTX 5070 Ti is listed under compute capability 12.0. The loader still queries the actual installed device.
3. NVIDIA, Blackwell compatibility guide: https://docs.nvidia.com/cuda/blackwell-compatibility-guide/index.html . Native architecture targets and PTX compatibility depend on toolkit/driver combinations.
4. CuPy, installation documentation: https://docs.cupy.dev/en/stable/install.html . Explains CUDA 12/13 wheel variants, `[ctk]`, supported Python versions, and the continuing driver requirement.
5. CuPy, RawModule API: https://docs.cupy.dev/en/stable/reference/generated/cupy.RawModule.html . Documents runtime compilation of raw CUDA modules.

GPU peak AI TOPS, advertised memory bandwidth and game frame rates are not converted into an invented Axis 0 speed estimate.

6. NVIDIA, NVRTC 12.8 guide: https://docs.nvidia.com/cuda/archive/12.8.0/nvrtc/index.html . Documents supported compiler architecture options and the runtime-compilation API.
