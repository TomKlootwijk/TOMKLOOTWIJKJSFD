# How the comparisons were made

The benchmark and baseline code was authored after freezing the implementation. `results/core_freeze.json` hashes every delivered core Python/C++/CUDA source file. Every benchmark run checks those hashes before measurement. The baselines do not influence the implemented transition.

## Workload

One prepared batch has 65,536 independent trajectories, each 256 steps long, with reproducibly generated Q/J/H integer bits (seed 20260918). This is 16,777,216 branch transitions. The reported primary precision is float64.

There are three untimed warmup runs and seven timed prepared runs. Prepared runs exclude initialization/reset, allocation, input generation, verification and result extraction. They include the actual full per-trajectory recurrence. CPU times use a high-resolution monotonic wall clock. CUDA measurements, when run on the laptop, also report elapsed CUDA-event time across the selected launches. The elapsed event interval can include inter-launch gaps; it is not a claimed device peak.

Warm-cache end-to-end timing has three samples and includes input validation, allocations, execution, and output copies/download. GPU timing also includes transfers in that category. It excludes random input generation and disk I/O. Cold preparation is reported separately; it is not a complete first-run latency.

All individual samples, software versions, backend name and environment information are retained in JSON. A server CPU result is never relabeled as a laptop GPU result.

## Baseline A: conventional elementwise XOR

`np.bitwise_xor(Q,J,out=C)` produces the exact same emitted branch bits. It does not produce the geometric state, parity, entropy or numerical-diagnostic fields. Comparing against it answers the narrower question: how much additional work does the explicit model do beyond obtaining its final bit string?

On a GPU, the analogous `cupy.bitwise_xor` baseline is timed on resident device inputs. It is still an output-only comparison.

## Baseline B: factored, identical terminal-state calculation

The completed profile inspection shows that radius and lifted time depend on depth, not Q/J/H. The final v coordinate is the count of H bits, parity is that count modulo two, and the output is Q XOR J. A conventional calculation can therefore share one common clock recurrence across every trajectory, reduce H, and assign the corresponding signs and metadata.

`FactoredTerminal` performs that calculation, including the clock loop during each measured call. No precomputed clock cost is hidden in its setup. Its C, geometry and state arrays are compared to the complete kernel output. The comparison includes the numeric precision diagnostics and is exact for the tested floating-point arithmetic. It does not claim to execute each per-trajectory transition or to reproduce an unassigned general interpreter.

This baseline demonstrates redundant work in the specified example. It is included as a separate after-the-fact analysis, not secretly inserted as the implementation of the formalization.

## Scope of the conclusion

Both the full batch kernel and these existing array techniques require reading input proportional to steps*tracks. There is no demonstrated asymptotic advantage, general compression gain, universal computation result, or physical-time experiment. Real-time rendering and neural-network inference are different workloads and receive no fabricated speed comparison.

Primary API references, checked 18 September 2026:

- NumPy bitwise_xor: https://numpy.org/doc/stable/reference/generated/numpy.bitwise_xor.html
- NumPy sum: https://numpy.org/doc/stable/reference/generated/numpy.sum.html

The API references establish the baseline operations; the measured timings come from this package's actual executions, not those pages.
