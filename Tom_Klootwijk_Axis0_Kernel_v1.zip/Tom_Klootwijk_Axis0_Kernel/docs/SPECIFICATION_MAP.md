# Specification-to-code map

Formalization: Tom Klootwijk / NL200678942 / 10-07-1990.

## Basis and provenance

The six-page original and eight-page continuation are included under `source_material/`. The original author's Axis 0 definition is on page 5 of the six-page document. The continuation's input/seed/grounding/readout diagram and SDF-to-T diagram are on page 7; Present, entropy, Now and temporal-Klein wording are on page 8.

The explicit operational equations implemented here are reference profile R from the enhanced v2.0 formal specification in the preceding conversation, especially sections 15–18. That earlier generated PDF was not mounted in this build environment; its equations were transcribed from the conversation, and are reproduced below. Its availability is not implied by either of the included PDF files.

The source PDFs contain accompanying explanatory claims as well as author statements. The kernel does not treat the accompanying assertions of universality, entropy-guaranteed halting or physical causality as measured facts.

## Exact profile R

Let `phi=(1+sqrt(5))/2`, `Q,J,H` be equal-length bit words of length L, and start with

```text
n=0, address=1, word="", parity=0
u=0, v=0, y=radius=1, z=local_T=0
entropy=0, lifted_T=(-1)**parity * z = 0
```

For each supplied row n, execute

```text
c = Q[n] XOR J[n]
r_next = r / phi
u_next = (-1)**H[n] * u
v_next = v + H[n]
y_next = r_next
z_next = (-1)**H[n] * (z + (-1)**parity * r_next)
parity_next = parity XOR H[n]
address_next = (address << 1) | c
word_next = word + bit(c)
n_next = n + 1
entropy_next = n_next
```

The recurrence is evaluated in `exact.psi_step`, `batch.NumpySession.run`, and the shared `kernels/transition.cuh`. The CUDA wrapper maps one lane to one trajectory; it does not replace the recurrence with the simpler post-hoc baseline.

The terminal predicate is `n==L`. In this profile, entropy means `log2(|{0,1}^n|)=n`, a prefix-capacity counter. It is not a measured Shannon entropy of a deterministic input, nor a physical entropy functional. Jitter does not secretly call a random generator; J is supplied explicitly.

## Geometry and SDF = T

```text
A(u,v,y,z) = (u+1,v,y,z)
B(u,v,y,z) = (-u,v+1,y,-z)
```

For the parity-tracked lift, B also changes parity by XOR 1. The local signed distance and local time are both z. Distance magnitude is abs(z), and the lifted scalar is `(-1)**parity*z`. The B maps are implemented in `geometry.KleinPoint` and in the selected profile's actual transitions; the carrier is not just a Klein-bottle label on a generic node.

`geometry.KleinPoint.canonical_lift()` provides a representative with parity 0 and u modulo 1, v modulo 2. `local_jacobian()` supplies the assigned fixed-branch 4-by-4 matrix. Circle and sphere SDF helpers exist as separately declared geometric constructors. No cone/pyramid parameters are invented.

## Now and output

In exact arithmetic, `lifted_T(n)=sum(phi**(-k),k=1..n)` is strictly increasing. The terminal event belongs to the slice at `lifted_T(L)`. The reader returns the branch word as ASCII.

The exact CPU implementation can retain or reconstruct states at any evaluated prefix. Batched implementations retain output prefixes plus the terminal geometric/counter state; they do not allocate every intermediate floating-point state. A prefix Now request returns its exact time identity and bit payload. Requesting a complete geometric history requires exact replay or an application-level trace recorder.

## Log-polar LUT and addresses

Along this selected trace, the tangential pair (y,u) has radius r=y>0 and angle 0. The base-phi log radius is `-n`. The finite LUT row `(-n,0)` is exactly the row of Q/J/H arrays. Accessing it by n avoids taking log of an underflowed numerical radius. This is the specialized profile-R LUT, not a generalized spatial-search library.

The GPU retains C as a byte-per-bit path. `BatchResult.address()` reconstructs the leading-root-bit integer, so there is no silent unsigned-64 address rollover. `packed_path()` provides conventional packed storage; its last byte is right-padded and the bit length must be retained. Exact `cantor_interval()` constructs the ternary interval for a branch prefix.

## Field language and status

`fields.Axis0` gives every implemented operator an `OperatorField` descriptor with an evaluable local SDF and a field-readable instruction name. Its reader functions return `Field` values, maintaining closure for the exposed API. Quote/Read/Eval allow the declared runtime operators to be represented and invoked through that registry.

The instruction decoder is an assigned software realization. It is not a proof that distance geometry alone encodes arbitrary programs. The GPU is a compiled lowering of profile R, not a general interpreter of all possible field descriptions. Opaque names and the replication/universality contracts remain explicitly unassigned.
