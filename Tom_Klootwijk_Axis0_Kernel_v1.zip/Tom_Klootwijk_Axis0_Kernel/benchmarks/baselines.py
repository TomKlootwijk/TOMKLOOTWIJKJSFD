"""After-the-fact comparison code. The core never imports this module.

XOR-only matches only the emitted bits. FactoredTerminal matches every
returned terminal-state array for profile R; it shares its common temporal
recurrence across trajectories instead of executing it once per trajectory.
Neither is a replacement inserted into the delivered formalization kernel.
"""
import numpy as np
from axis0.batch import state_arrays, BatchResult, INVPHI

class XorOnly:
    def __init__(self,q,j):
        self.q=q;self.j=j;self.out=np.empty_like(q)
    def run(self):
        np.bitwise_xor(self.q,self.j,out=self.out)

class FactoredTerminal:
    def __init__(self,q,j,h,precision):
        self.q=q;self.j=j;self.h=h;self.precision=precision
        self.steps,self.tracks=q.shape
        self.c=np.empty_like(q);self.xyz,self.state=state_arrays(self.tracks,precision)

    def run(self):
        # Compute the clock each measured call (not hidden in setup).
        real=np.dtype(self.precision).type
        r=real(1);lift=real(0);ratio=real(INVPHI)
        time_stall=radius_stall=radius_zero=0
        for n in range(1,self.steps+1):
            nr=r*ratio;nl=lift+nr
            if not time_stall and nl==lift:time_stall=n
            if not radius_stall and nr==r:radius_stall=n
            if not radius_zero and nr==0:radius_zero=n
            r=nr;lift=nl
        np.bitwise_xor(self.q,self.j,out=self.c)
        np.sum(self.h,axis=0,dtype=np.uint64,out=self.state[2])
        np.bitwise_and(self.state[2],np.uint64(1),out=self.state[1])
        self.state[0].fill(self.steps)
        self.state[3].fill(time_stall);self.state[4].fill(radius_stall);self.state[5].fill(radius_zero)
        self.xyz[0]=np.where(self.state[1]!=0,real(-0.0),real(0.0))
        self.xyz[1].fill(r)
        self.xyz[2]=np.where(self.state[1]!=0,-lift,lift)

    def result(self):
        return BatchResult(self.c,self.xyz,self.state,'factored_terminal_baseline',self.precision)
