"""Exercise the independent, after-the-fact full-terminal-state baseline."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from axis0.batch import run_batch
from baselines import FactoredTerminal
rng=np.random.default_rng(20260918)
batches=0
for precision in ('float32','float64'):
    for length in (0,1,4,35,36,64,77,78,256,1600):
        q,j,h=(rng.integers(0,2,(length,17),dtype=np.uint8) for _ in range(3))
        full=run_batch(q,j,h,backend='native',precision=precision)
        simple=FactoredTerminal(q,j,h,precision);simple.run()
        for a,b in ((full.c,simple.c),(full.xyz,simple.xyz),(full.state,simple.state)):
            np.testing.assert_array_equal(a,b)
        batches+=1
print(f'{batches} independent full-terminal-state comparison batches passed')
