"""Reproducible after-the-fact benchmarks with explicit timed regions.

Examples:
  python benchmarks/benchmark.py --backend numpy --json results/local_numpy.json
  python benchmarks/benchmark.py --backend native --json results/local_native.json
  python benchmarks/benchmark.py --backend cuda --json results/laptop_cuda.json
"""
from __future__ import annotations
from pathlib import Path
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
import platform
import statistics
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from axis0.batch import prepare,run_batch,memory_bytes
from axis0.exact import run_exact
from baselines import XorOnly,FactoredTerminal
ROOT=Path(__file__).resolve().parents[1]


def stats(values):
    return {'median_ms':statistics.median(values),'min_ms':min(values),'max_ms':max(values),
            'samples_ms':values}


def cpu_model():
    try:
        for line in Path('/proc/cpuinfo').read_text().splitlines():
            if line.startswith('model name'):return line.split(':',1)[1].strip()
    except OSError:pass
    return platform.processor() or os.environ.get('PROCESSOR_IDENTIFIER','unknown')


def check_freeze():
    saved=json.loads((ROOT/'results/core_freeze.json').read_text())
    for name,want in saved['files'].items():
        actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        if actual!=want:raise RuntimeError(f'Frozen core file changed: {name}')
    return saved['frozen_at_utc']


def measure_cpu(fn,repeats):
    for _ in range(3):fn()
    times=[]
    for _ in range(repeats):
        t=time.perf_counter_ns();fn();times.append((time.perf_counter_ns()-t)/1e6)
    return stats(times)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--backend',choices=['numpy','native','cuda'],default='numpy')
    p.add_argument('--precision',choices=['float32','float64'],default='float64')
    p.add_argument('--steps',type=int,default=256);p.add_argument('--tracks',type=int,default=65536)
    p.add_argument('--repeats',type=int,default=7);p.add_argument('--seed',type=int,default=20260918)
    p.add_argument('--chunk-steps',type=int,default=128);p.add_argument('--device',type=int,default=0)
    p.add_argument('--json',default='results/benchmark_local.json')
    args=p.parse_args()
    if min(args.steps,args.tracks,args.repeats,args.chunk_steps)<=0:p.error('dimensions, repeats, chunk size must be positive')
    frozen=check_freeze()
    rng=np.random.default_rng(args.seed)
    q,j,h=(rng.integers(0,2,(args.steps,args.tracks),dtype=np.uint8) for _ in range(3))
    kwargs=dict(backend=args.backend,precision=args.precision,chunk_steps=args.chunk_steps,device=args.device)
    t=time.perf_counter();session=prepare(q,j,h,**kwargs);session.synchronize();cold=(time.perf_counter()-t)*1000
    for _ in range(3):session.reset();session.run();session.synchronize()
    wall=[];device=[]
    for _ in range(args.repeats):
        session.reset();session.synchronize()
        if args.backend=='cuda':
            cp=session.cp
            with cp.cuda.Device(args.device):
                start=cp.cuda.Event();end=cp.cuda.Event()
                start.record();t=time.perf_counter_ns();session.run();end.record();end.synchronize()
                wall.append((time.perf_counter_ns()-t)/1e6)
                device.append(float(cp.cuda.get_elapsed_time(start,end)))
        else:
            t=time.perf_counter_ns();session.run();wall.append((time.perf_counter_ns()-t)/1e6)
    result=session.download()
    # No extraction, equality testing or allocation is included in the prepared-run timings.
    for t in range(min(8,args.tracks)):
        exact=run_exact(q[:,t],j[:,t],h[:,t])
        if result.word(t)!=exact.output:raise AssertionError('timed run output failed exact comparison')
    e2e=[]
    for _ in range(3):
        t=time.perf_counter_ns();check=run_batch(q,j,h,**kwargs)
        e2e.append((time.perf_counter_ns()-t)/1e6)
        if not np.array_equal(result.c,check.c):raise AssertionError('end-to-end output mismatch')
        del check
    report={'generated_at_utc':datetime.now(timezone.utc).isoformat(),'core_frozen_at_utc':frozen,
        'configuration':vars(args),'environment':{'cpu':cpu_model(),'cpu_count':os.cpu_count(),
        'platform':platform.platform(),'python':sys.version.split()[0],'numpy':np.__version__},
        'cold_prepare_ms':cold,'full_prepared_run_wall':stats(wall),
        'end_to_end_warm_cache':stats(e2e),'memory':memory_bytes(args.steps,args.tracks,args.precision),
        'timing_scope':{'prepared':'Buffers resident; initialization/reset excluded; all per-track recurrence steps included.',
        'end_to_end':'Input validation, allocations, transfers (CUDA), run, synchronization, output download/copies. JIT is already warm. Input generation and NPZ I/O excluded.',
        'cold_prepare':'Validation/allocation/upload/JIT as applicable; not a full first run.'},
        'gpu_executed':args.backend=='cuda','terminal_output_exact_checked_tracks':min(8,args.tracks)}
    if args.backend=='cuda':
        from axis0.cuda_backend import device_info
        report['environment']['gpu']=device_info(args.device)
        report['full_cuda_event_elapsed']=stats(device)
        with cp.cuda.Device(args.device):
            out=cp.empty_like(session.c)
            for _ in range(3):cp.bitwise_xor(session.q,session.j,out=out)
            cp.cuda.get_current_stream().synchronize()
            timings=[]
            for _ in range(args.repeats):
                start=cp.cuda.Event();end=cp.cuda.Event();start.record()
                cp.bitwise_xor(session.q,session.j,out=out)
                end.record();end.synchronize()
                timings.append(float(cp.cuda.get_elapsed_time(start,end)))
            np.testing.assert_array_equal(cp.asnumpy(out),result.c)
        report['xor_only_baseline_cuda_event']=stats(timings)
        report['full_over_xor_output_only_ratio']=statistics.median(device)/statistics.median(timings)
        report['comparison_note']='XOR baseline emits identical bits but omits geometry, parity, entropy and diagnostic metadata; not full-state equivalence.'
        median=statistics.median(device)
    else:
        xor=XorOnly(q,j)
        report['xor_only_baseline_wall']=measure_cpu(xor.run,args.repeats)
        np.testing.assert_array_equal(xor.out,result.c)
        factored=FactoredTerminal(q,j,h,args.precision)
        report['factored_terminal_baseline_wall']=measure_cpu(factored.run,args.repeats)
        for a,b in ((result.c,factored.c),(result.xyz,factored.xyz),(result.state,factored.state)):
            np.testing.assert_array_equal(a,b)
        report['factored_terminal_all_arrays_equal']=True
        full=statistics.median(wall)
        report['full_over_xor_output_only_ratio']=full/report['xor_only_baseline_wall']['median_ms']
        report['full_over_factored_same_terminal_ratio']=full/report['factored_terminal_baseline_wall']['median_ms']
        report['comparison_note']='XOR matches output bits only. Factored conventional calculation matches every returned terminal-state array, including numerical diagnostics, but does not execute every trajectory recurrence separately.'
        median=full
    report['full_branch_transitions_per_second']=args.steps*args.tracks/(median/1000)
    report['full_trajectories_per_second']=args.tracks/(median/1000)
    report['note']='These are measurements on the reported machine, not forecasts for a different GPU/laptop. No gaming, AI TOPS or universal-computation equivalence is inferred.'
    target=Path(args.json);target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
