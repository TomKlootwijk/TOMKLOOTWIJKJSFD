"""Generate inputs; a seed is recorded for reproducibility, never inferred from IDs."""
import argparse
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser()
p.add_argument('--steps',type=int,default=256);p.add_argument('--tracks',type=int,default=65536)
p.add_argument('--seed',type=int,default=20260918);p.add_argument('--output',default='inputs.npz')
a=p.parse_args()
if a.steps<0 or a.tracks<0:p.error('dimensions must be nonnegative')
rng=np.random.default_rng(a.seed)
q,j,h=(rng.integers(0,2,(a.steps,a.tracks),dtype=np.uint8) for _ in range(3))
np.savez(a.output,Q=q,J=j,H=h,seed=np.array(a.seed))
print(f'Saved {a.tracks:,} trajectories of {a.steps:,} steps to {a.output}')
