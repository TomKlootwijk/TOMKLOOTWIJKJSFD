from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from axis0 import run_exact
from axis0.batch import run_batch

print(run_exact('0110','1010','1011').summary())
q=np.array([[0,1],[1,0],[1,1],[0,0]],dtype=np.uint8)
j=np.zeros_like(q);h=np.ones_like(q)
r=run_batch(q,j,h,backend='numpy') # change explicitly to 'cuda' after GPU verification
print(r.summary(0))
print(r.read_now(2,track=1))
