from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from axis0.fields import Axis0, Field
axis=Axis0()
s=axis.apply('Seed',Field('input',('0110','1010','1011')))
while not axis.apply('Halt',s).payload:
    s=axis.apply('PSI',s)
now=axis.apply('Now',s)
print(axis.apply('ReadNow',now).payload)
# Expected: 1100
