# Axis 0 — Operator–SDF–T computational kernel

**Tom Klootwijk · NL200678942 · 10-07-1990**  
Kernel version **1.0.0** · formal specification **v2.0 / reference profile R**

This package executes the defined seed → PSI → entropy/input-completion → Now → ASCII-output sequence. It includes an exact Python reference, a NumPy CPU backend, an optional compiled C++ CPU backend, and actual CUDA source for batched execution through CuPy/NVRTC. This is a computational kernel/runtime, not a bootable operating-system kernel.

The core was frozen before the comparison programs were authored. `results/core_freeze.json` records the source hashes. `benchmarks/` is separate and is never imported into the kernel.

## First run: no GPU or extra dependency needed

Open a terminal **in this extracted folder**:

```text
python -m axis0 demo
```

The exact demo uses only Python's standard library. It returns `1100`, address `0b11100` (28), parity 1, entropy 4, radius `5 - 3*phi`, local time `phi - 3`, and lifted time `3 - phi`.

Python 3.10 or newer is required. Python 3.12 is a suitable installation choice for the supplied Windows setup commands. On Windows, substitute `py -3.12` for `python` when appropriate.

## Windows: your RTX 5070 Ti Laptop GPU

From the extracted folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -e ".[cuda12]"
.\.venv\Scripts\python.exe -m axis0 doctor
.\.venv\Scripts\python.exe -m axis0 demo --backend cuda
.\.venv\Scripts\python.exe -m axis0 verify --backend cuda --json results\laptop_verify_f64.json
.\.venv\Scripts\python.exe benchmarks\benchmark.py --backend cuda --json results\laptop_benchmark.json
```

The optional `scripts/setup_gpu.ps1` automates installation and the device correctness check. It does not install a driver or change system settings. `scripts/check_laptop.ps1` records both precisions, device information, the precision audit, and a benchmark.

NVIDIA lists the RTX 5070 Ti Laptop GPU with 12 GB GDDR7. RTX 5070 Ti is a compute-capability-12.0 / Blackwell family device. The loader queries the actual device, instead of assuming a desktop memory size or selecting a desktop binary. For native Blackwell compilation, use CUDA/NVRTC 12.8 or later and a compatible NVIDIA driver. CuPy's `[ctk]` extra installs the CUDA component packages; an installed GPU driver is still required. See `docs/CUDA_SETUP.md` and its primary-source references.

**Actual delivery validation:** CPU execution and host-side checking of the CUDA body passed. No NVIDIA GPU or NVRTC compiler was available in the build environment, so there is no claim of an executed RTX benchmark or an NVRTC-verified device binary. The commands above perform that missing device validation on your laptop. GPU errors are reported rather than silently replaced by CPU execution.

## Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -e '.[cuda12]'
.venv/bin/python -m axis0 doctor
.venv/bin/python -m axis0 verify --backend cuda
```

For CPU-only installation, install `-e .` without the extra. GPU dependencies are downloaded during setup; the ZIP does not bundle CUDA libraries, a driver, or a Python interpreter.

## What goes in and comes out

Input is **three equal-length bit streams**, not an arbitrary English prompt:

- `Q`: nominal left/right choices.
- `J`: the explicitly supplied one-bit jitter at each step.
- `H`: the explicitly supplied orientation character of the selected port.

The kernel executes `c = q XOR j`, the exact logical tree-address update, the orientation/parity update, the lowercase-phi radius recurrence, the signed local temporal advance, the entropy counter and the declared final readout.

```text
python -m axis0 run --q 0110 --j 1010 --h 1011 --backend exact
python -m axis0 run --q 0110 --j 1010 --h 1011 --backend numpy
```

For batches, NPZ inputs contain integer/boolean arrays `Q`, `J`, `H` of shape **[steps, tracks]**. Each track is independent. Rows implement profile R's finite log-polar lookup row `(-n, 0)`.

```text
python examples/make_batch.py --steps 256 --tracks 65536 --output inputs.npz
python -m axis0 batch inputs.npz outputs.npz --backend cuda
```

Output NPZ fields are `C`, `geometry`, `state`, `precision`, `backend`. Geometry rows are `u, radius=y, local_T=z`. State rows are `steps, parity, v, first_time_stall, first_radius_stall, first_radius_zero`. A diagnostic value of zero means "not observed." Input NPZs are loaded with `allow_pickle=False`.

The 65,536-by-256 float64 example needs **68.5 MiB for the explicitly allocated device arrays**, excluding the CUDA context, allocator cache and display/driver use. It has 16,777,216 branch transitions. No dense four-dimensional voxel grid is allocated.

## Exact versus fast geometry

`exact` preserves values as arbitrary-size integer coefficients `a + b*phi`, with `phi**2 = phi + 1`. The CPU/GPU batch backends use explicit float32 or float64 geometry, but retain exact bits, integer parity and counters, and an exact symbolic Now key `(profile R, step)`.

Floating-point time values eventually become equal at adjacent steps. They are **not** used as event identities or stopping tests. Depth is not silently clipped to 63 bits: output paths are retained as byte arrays and reconstructed as arbitrary-size host integers. The fixed-width batch counters are uint64; the batch's finite array dimensions must be representable.

`--chunk-steps 128` partitions a long run into launches. It does not change the input-completion stopping rule or discard later steps. It can be lowered for a display-attached GPU without changing semantics.

## Tests and reproducible measurements

```text
python -m unittest discover -s tests -v
python -m axis0 verify --backend numpy
python -m axis0 build-native
python -m axis0 verify --backend native
python tests/check_cuda_host_shim.py
python benchmarks/benchmark.py --backend native --json results/local_native.json
python -m axis0 precision --backend native
```

The native backend is optional and requires g++ or clang++ for a local C++17 build. Its machine-specific library is not included in this source distribution. CPU NumPy and CUDA/NVRTC do not require that C++ build.

Read `docs/METRICS_ELI5.md` for measured performance, exact-output comparisons, numerical behavior and what the implementation actually establishes. All raw timing samples and verification reports are in `results/`.

## Specification boundaries

The executable implementation is **profile R and its field-readable interfaces**, not a claim that every source term has acquired a new, invented meaning. `python -m axis0 operators` lists the implemented fields and retained unassigned terms. In particular, B floppy P, the source-specific plus, the circled T, a universal interpreter and kernel self-replication have no supplied executable rule. Invoking an unassigned operation reports it as unassigned.

The code uses the explicit quotient chart `d=z` and its deck transformations, not a visual 3-D Klein-bottle mesh presented as an exact global SDF. The field reader assigns instruction meanings to marked field objects. The current public bit readout is precisely `Q XOR J`; the geometric state supplies additional bookkeeping and a testable model, not demonstrated physical time or additional algorithmic problem-solving power.

## Package map

`axis0/` contains the kernel and APIs; `axis0/kernels/` contains CUDA and shared C++; `tests/` contains correctness checks; `examples/` contains executable examples; `scripts/` contains setup/device-check helpers; `benchmarks/` contains independent comparisons; `docs/` contains source mapping, ABI and numerical details; `source_material/` contains the two supplied PDFs; `results/` contains the actual delivery evidence. `SHA256SUMS` covers the distributed files.
